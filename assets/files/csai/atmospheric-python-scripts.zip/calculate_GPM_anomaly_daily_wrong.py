# -*- coding: utf-8 -*-
"""
Created on Fri Jul 18 11:22:32 2025

@author: Dell
"""

import numpy as np
import netCDF4 as nc
import os
from datetime import datetime, timedelta
import gc
import warnings
import time

warnings.filterwarnings('ignore')  # 忽略一些不影响计算的警告

# 配置路径
input_dir = "E:/GPM_daily_20090101_20231231"
output_dir = "E:/GPM_anomaly_daily"
os.makedirs(output_dir, exist_ok=True)
output_file = os.path.join(output_dir, "GPM_anomaly_daily_20230101_20230331.nc")

# 时间参数
start_date = datetime(2023, 1, 1)
end_date = datetime(2023, 3, 31)
climatology_years = list(range(2009, 2024))  # 2009-2023年气候态数据

# 1. 构建时间索引映射（每年365天）
def get_time_index(dt):
    """计算日期在一年中的时间索引(0-364)"""
    doy = (dt - datetime(dt.year, 1, 1)).days
    if dt.month > 2 and (dt.year % 4 == 0 and (dt.year % 100 != 0 or dt.year % 400 == 0)):
        doy -= 1
    return doy

# 2. 直接计算谐波系数（高效内存版本）
def calculate_harmonics():
    print("直接计算谐波系数...")
    T = 365  # 一年中的天数（整数）
    
    # 预先计算基函数
    t = np.arange(T)
    basis_functions = np.array([
        np.ones(T),
        np.cos(2 * np.pi * t / T),
        np.sin(2 * np.pi * t / T),
        np.cos(4 * np.pi * t / T),
        np.sin(4 * np.pi * t / T),
        np.cos(6 * np.pi * t / T),
        np.sin(6 * np.pi * t / T)
    ], dtype=np.float32)
    
    # 计算最小二乘矩阵
    X = basis_functions.T
    XTX = X.T @ X
    XTX_inv = np.linalg.inv(XTX)
    
    # 初始化谐波系数数组
    harmonics = np.zeros((7, 1800, 3600), dtype=np.float32)
    
    # 使用更大的块大小，减少循环次数
    block_size = 100  # 每次处理100个经度点
    num_blocks = (3600 + block_size - 1) // block_size
    
    # 准备时间点映射
    time_point_map = {}
    for t_idx in range(T):
        base_date = datetime(2000, 1, 1)  # 使用参考年份
        dt = base_date + timedelta(days=t_idx)
        time_point_map[t_idx] = (dt.month, dt.day)
    
    # 顺序处理经度块
    for block_idx in range(num_blocks):
        lon_start = block_idx * block_size
        lon_end = min(lon_start + block_size, 3600)
        num_lons = lon_end - lon_start
        
        print(f"处理经度块: {lon_start}-{lon_end} ({num_lons}个经度点)")
        start_time = time.time()
        
        # 初始化累加器
        XTy_accum = np.zeros((7, 1800, num_lons), dtype=np.float32)
        count_accum = np.zeros(T, dtype=np.int32)
        
        # 处理所有时间点
        for t_idx in range(T):
            month, day = time_point_map[t_idx]
            
            # 初始化当前时间点的累加器
            time_sum = np.zeros((1800, num_lons), dtype=np.float32)
            time_count = 0
            
            # 处理所有年份
            for year in climatology_years:
                # 跳过闰年的2月29日
                if month == 2 and day == 29 and (year % 4 != 0 or (year % 100 == 0 and year % 400 != 0)):
                    continue
                    
                try:
                    # 构建文件名
                    dt = datetime(year, month, day)
                    filename = f"GPM_daily_{dt.strftime('%Y%m%d')}.nc"
                    filepath = os.path.join(input_dir, filename)
                    
                    # 读取数据
                    if os.path.exists(filepath):
                        with nc.Dataset(filepath, 'r') as ds:
                            precip = ds['precipitation'][:]
                            precip = np.nan_to_num(precip, nan=0.0)
                            time_sum += precip[:, :, 0].T
                            time_count += 1
                except Exception as e:
                    print(f"  读取文件 {filename} 时出错: {str(e)}")
            
            # 计算当前时间点的平均值
            if time_count > 0:
                time_avg = time_sum / time_count
                count_accum[t_idx] = time_count
                
                # 累加到XTy
                for i in range(7):
                    XTy_accum[i] += basis_functions[i, t_idx] * time_avg
        
        # 计算谐波系数
        XTy_2d = XTy_accum.reshape(7, -1)
        coeffs = XTX_inv @ XTy_2d
        coeffs = coeffs.reshape(7, 1800, num_lons)
        
        # 保存系数
        harmonics[:, :, lon_start:lon_end] = coeffs
        
        # 显示处理时间
        elapsed = time.time() - start_time
        print(f"  经度块处理完成，耗时: {elapsed:.2f}秒")
        
        # 释放内存
        del XTy_accum, coeffs, time_sum
        gc.collect()
    
    return harmonics

# 3. 计算2023年异常值
def calculate_anomalies(harmonics):
    print("计算2023年异常值...")
    # 预计算时间值
    time_values = []
    current_date = start_date
    while current_date <= end_date:
        t_idx = get_time_index(current_date)
        time_values.append((current_date, t_idx))
        current_date += timedelta(days=1)
    
    # 创建输出文件
    with nc.Dataset(output_file, 'w', format='NETCDF4') as out_ds:
        # 创建维度
        out_ds.createDimension('time', len(time_values))
        out_ds.createDimension('lat', 1800)
        out_ds.createDimension('lon', 3600)
        
        # 创建时间变量
        time_var = out_ds.createVariable('time', 'f8', ('time',))
        time_var.units = 'days since 2023-01-01 00:00:00'
        time_var.calendar = 'standard'
        
        # 创建经纬度变量
        lon_var = out_ds.createVariable('lon', 'f4', ('lon',))
        lat_var = out_ds.createVariable('lat', 'f4', ('lat',))
        
        # 生成经纬度数组
        lon_values = np.linspace(0.05, 359.95, 3600)
        lat_values = np.linspace(89.95, -89.95, 1800)
        
        lon_var[:] = lon_values
        lat_var[:] = lat_values
        
        # 创建异常变量
        precip_var = out_ds.createVariable('precipitation_anomaly', 'f4', ('time', 'lat', 'lon'),
                                          fill_value=-9999.9, zlib=True)
        precip_var.units = 'mm'
        precip_var.long_name = 'Daily precipitation anomaly'
        
        # 预计算基函数值
        T = 365
        base_functions = np.zeros((len(time_values), 7), dtype=np.float32)
        for i, (_, t_idx) in enumerate(time_values):
            base_functions[i] = [
                1,
                np.cos(2 * np.pi * t_idx / T),
                np.sin(2 * np.pi * t_idx / T),
                np.cos(4 * np.pi * t_idx / T),
                np.sin(4 * np.pi * t_idx / T),
                np.cos(6 * np.pi * t_idx / T),
                np.sin(6 * np.pi * t_idx / T)
            ]
        
        # 逐时间步处理
        days_list = []
        for i, (dt, _) in enumerate(time_values):
            start_time = time.time()
            print(f"处理时间: {dt.strftime('%Y-%m-%d')}")
            
            # 构建文件名
            filename = f"GPM_daily_{dt.strftime('%Y%m%d')}.nc"
            filepath = os.path.join(input_dir, filename)
            
            # 读取原始降水
            if not os.path.exists(filepath):
                print(f"  文件不存在: {filename}")
                precip = np.zeros((3600, 1800), dtype=np.float32).T
            else:
                try:
                    with nc.Dataset(filepath, 'r') as ds:
                        precip = ds['precipitation'][:]
                        precip = np.nan_to_num(precip, nan=0.0)
                        precip = precip[:, :, 0].T  # 转置为(lat, lon)
                except Exception as e:
                    print(f"  读取文件 {filename} 时出错: {str(e)}")
                    precip = np.zeros((1800, 3600), dtype=np.float32)
            
            # 计算气候预测值
            clim_pred = np.zeros((1800, 3600), dtype=np.float32)
            for j in range(7):
                clim_pred += base_functions[i, j] * harmonics[j]
            
            # 计算异常值
            anomaly = precip - clim_pred
            
            # 写入异常值
            precip_var[i, :, :] = anomaly
            
            # 记录时间
            days_list.append((dt - datetime(2023, 1, 1)).days)
            
            # 显示处理时间
            elapsed = time.time() - start_time
            print(f"  处理完成，耗时: {elapsed:.2f}秒")
        
        # 写入时间变量
        time_var[:] = days_list
        
        # 添加全局属性
        out_ds.title = "GPM IMERG Daily Precipitation Anomaly"
        out_ds.history = f"Created {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        out_ds.source = "Processed from GPM IMERG daily data"
        out_ds.reference = "Methodology based on Latos et al. 2023 (doi:10.1038/s41467-023-36498-w)"

# 主函数
def main():
    start_time = time.time()
    
    # 计算谐波系数
    harmonics = calculate_harmonics()
    
    # 保存谐波系数以便调试
    np.save(os.path.join(output_dir, "harmonics_daily.npy"), harmonics)
    print("谐波系数已保存到文件")
    
    # 计算异常值
    calculate_anomalies(harmonics)
    
    total_time = time.time() - start_time
    print(f"处理完成！总耗时: {total_time/3600:.2f}小时")

if __name__ == "__main__":
    main()