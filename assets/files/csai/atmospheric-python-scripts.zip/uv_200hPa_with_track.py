# -*- coding: utf-8 -*-
"""
Created on Thu Mar 13 00:58:36 2025

@author: Dell
"""

import xarray as xr
import matplotlib.pyplot as plt
import os
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from datetime import datetime, timezone
import numpy as np
import warnings
from cartopy.io import DownloadWarning
import pandas as pd  # 导入 pandas 库

# 禁用cartopy的下载警告
warnings.filterwarnings("ignore", category=DownloadWarning)

# 读取流场数据
uv_file_path = "D:\\MATLAB\\Freddy\\Initial_phase_environmental_field.nc"
ds = xr.open_dataset(uv_file_path)

# 读取热带气旋Freddy的路径数据
track_file_path = 'D:/MATLAB/Freddy/IBTrACS.SI.v04r01.nc'
track_data = xr.open_dataset(track_file_path)

# 找到FREDDY热带气旋的数据
freddy_sid = b'2023036S12117'  # FREDDY的sid
freddy_data = track_data.sel(storm=(track_data['sid'] == freddy_sid))

# 检查是否找到FREDDY的数据
if freddy_data.sizes['storm'] == 0:
    raise ValueError(f"未找到sid为 {freddy_sid} 的热带气旋数据。")

# 获取FREDDY的时间和经纬度数据
times = freddy_data['time'].values
lats = freddy_data['lat'].values
lons = freddy_data['lon'].values

# 过滤掉无效的时间和数据
valid_indices = ~np.isnat(times) & ~np.isnan(lats) & ~np.isnan(lons)
times = times[valid_indices]
lats = lats[valid_indices]
lons = lons[valid_indices]

# 将时间转换为datetime对象（时区感知）
times = [datetime.fromtimestamp(t.astype('O')/1e9, tz=timezone.utc) for t in times]

# 设置绘图范围
lat_range = (0, -40)  # 数据筛选范围：从赤道到南纬40°
lon_range = (25, 130)
time_range = ('2023-02-01', '2023-03-31')

# 筛选流场数据
ds = ds.sel(latitude=slice(*lat_range), longitude=slice(*lon_range), valid_time=slice(*time_range))

# 创建保存图像的文件夹
os.makedirs("C:\\Users\\Dell\\Desktop\\uv_200hPa_with_track", exist_ok=True)

# 格式化时间戳为合法的文件名
def format_filename(time):
    return time.dt.strftime("%Y-%m-%d_%H-%M-%S").values

# 设置降采样间隔
stride = 8  # 每隔8个点取一个数据点

# 设置箭头缩放比例（更大的值会使箭头更短）
arrow_scale = 300  # 增大 scale 值以使箭头更短

# 绘制200hPa风场，并叠加Freddy路径
for time in ds.valid_time:
    # 将流场时间转换为时区感知的datetime对象
    current_time = pd.to_datetime(time.values).replace(tzinfo=timezone.utc)
    
    # 筛选当前时间的流场数据
    u_200 = ds.u.sel(pressure_level=200, valid_time=time)
    v_200 = ds.v.sel(pressure_level=200, valid_time=time)
    
    # 创建地图
    fig = plt.figure(figsize=(12, 8))
    ax = plt.axes(projection=ccrs.PlateCarree())
    
    # 添加地图背景
    ax.set_facecolor('white')  # 设置背景为白色
    ax.add_feature(cfeature.LAND, edgecolor='black')  # 添加陆地边界
    ax.add_feature(cfeature.OCEAN, edgecolor='black')  # 添加海洋边界
    ax.add_feature(cfeature.COASTLINE, linewidth=0.5)  # 添加海岸线
    ax.add_feature(cfeature.BORDERS, linestyle=':', linewidth=0.5)  # 添加国界线
    
    # 降采样数据
    lon_subset = ds.longitude.values[::stride]
    lat_subset = ds.latitude.values[::stride]
    u_200_subset = u_200.values[::stride, ::stride]
    v_200_subset = v_200.values[::stride, ::stride]
    
    # 绘制200hPa风场
    Q_200 = ax.quiver(lon_subset, lat_subset, u_200_subset, v_200_subset, scale=arrow_scale, width=0.001, color='blue')
    ax.quiverkey(Q_200, X=0.9, Y=1.05, U=10, label='10 m/s', labelpos='E', color='blue')
    
    # 添加经纬网
    gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=0.5, color='gray', alpha=0.5)
    gl.top_labels = False
    gl.right_labels = False
    
    # 设置标题
    ax.set_title(f"200hPa Wind Field with Freddy Track at {current_time.strftime('%Y-%m-%d %H:%M:%S')}")
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_xlim(lon_range)  # 经度范围不变
    ax.set_ylim((-40, 0))  # 翻转纬度轴，从上到下表示从赤道到南纬40°
    
    # 绘制Freddy路径（如果存在）
    if current_time >= datetime(2023, 2, 4, tzinfo=timezone.utc) and current_time <= datetime(2023, 3, 14, tzinfo=timezone.utc):
        # 找到当前时间之前的路径点
        path_indices = [i for i, t in enumerate(times) if t <= current_time]
        if path_indices:
            ax.plot(lons[path_indices], lats[path_indices], color='red', marker='o', markersize=4, transform=ccrs.PlateCarree())
    
    # 格式化文件名并保存
    filename = format_filename(time)
    plt.savefig(f"C:\\Users\\Dell\\Desktop\\uv_200hPa_with_track\\{filename}.png", dpi=300, bbox_inches='tight')
    plt.close()

# 关闭数据集
ds.close()
track_data.close()