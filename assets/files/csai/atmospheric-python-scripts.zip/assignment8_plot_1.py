import numpy as np
import matplotlib.pyplot as plt

# 读取数据
file_path = r'C:\Users\Chen Yong\Desktop\Temperature_distribution.txt'

# 读取文件并跳过第一行的文字描述
data = np.loadtxt(file_path, skiprows=1)

# 绘制5000秒后的温度分布
plt.figure(figsize=(8, 6))
plt.plot(np.linspace(0, 1, len(data)), data, label="Temperature Distribution at 5000 seconds", color='b')

# 设置图形标签
plt.title("Temperature Distribution After 5000 Seconds")
plt.xlabel("Position (m)")
plt.ylabel("Temperature (°C)")
plt.legend()

# 显示图形
plt.grid(True)
plt.show()
