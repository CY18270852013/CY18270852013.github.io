# -*- coding: utf-8 -*-
"""
Created on Sun Mar 30 23:29:15 2025

@author: Chen Yong
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pandas.plotting import scatter_matrix
import scipy.stats as stats
import statsmodels.api as sm

x1 = np.array([32.300, 31.100, 32.300, 31.400, 32.500, \
               31.300, 30.600, 32.300, 31.600, 32.800, 32.900, \
               32.400, 32.300, 32.000, 30.800, 31.500, 32.000, \
               31.000, 31.800, 31.900, 31.200, 32.400, 33.600, \
               31.900, 31.900, 31.900, 32.800, 33.300, 32.300, 30.700] )
x2 = np.array([10.100, 9.700, 9.400, 8.100, 9.900, 9.100, \
               10.800, 9.800, 7.100, 10.100, 10.000, 9.500, \
               10.500, 9.700, 9.000, 10.600, 8.600, 9.800, \
               9.400, 10.000, 7.700, 10.300, 9.600, 10.300, \
               8.100, 8.100, 10.900, 10.400, 9.600, 9.900])
x3 = np.array([32.600, 31.500, 31.100, 32.100, 32.500, 30.800, \
               32.300, 31.600, 30.000, 32.800, 31.900, 31.000, \
               31.300, 31.900, 30.700, 32.700, 29.900, 29.900, \
               29.400, 33.700, 31.100, 32.500, 31.800, 31.400, \
               32.400, 28.800, 31.500, 31.000, 32.000, 31.300])
y = np.array([-2.700, -5.900, -3.400, -4.700, -3.800, -5.300, -5.000, \
              -4.300, -5.700, -3.600, -3.100, -3.900, -3.000, -4.900, \
              -5.700, -4.800, -5.600, -6.400, -5.600, -4.200, -4.900, \
              -4.100, -4.200, -3.300, -3.700, -7.600, -3.500, -4.200, \
              -4.500, -4.800])
X = np.array([x1, x2, x3]).T
XY = np.array([x1, x2, x3, y]).T

df = pd.DataFrame( XY, columns=['x1', 'x2', 'x3', 'y'])

pgrid = sns.pairplot(df, diag_kind="kde",  kind="reg")
pgrid.fig.set_size_inches(9,9)

corr = df.corr().values
for i, j in zip(*plt.np.triu_indices_from(pgrid.axes, k=1)):
    pgrid.axes[i, j].annotate("r = %.3f" %corr[i,j], (0.8, 0.9), xycoords='axes fraction', ha='center', va='center')
plt.tight_layout()
#plt.savefig('scatter_matrix.png', dpi=200)

X1 = np.column_stack((np.ones((30,1)), X)  )

xinv = np.linalg.inv(np.matmul(X1.T, X1))
b = np.matmul(xinv, np.matmul(X1.T, y ))
print('b = ', b)

y_hat = np.matmul(X1,b)

plt.figure(figsize=(9.4, 4.5))
plt.subplot(121)
plt.plot( y, y_hat, 'o')
plt.xlabel('y')
plt.ylabel('y_hat')
plt.axis([-10, 0, -10, 0])
plt.plot(np.arange(-10, 0), np.arange(-10, 0), 'k', linewidth=0.7)

plt.subplot(122)
plt.plot(np.arange(1951,1981), y, label='y')
plt.plot(np.arange(1951,1981), y_hat, label='y_hat')
plt.legend()
plt.xlabel('Time (years)')
plt.ylabel('Mean temperature in January(°C)')
 
plt.tight_layout()
# plt.savefig('Rain_Yangzi.png')

R2 = np.sum( (y_hat - y_hat.mean())**2)/ np.sum( (y - y.mean())**2)
R  = np.sqrt(R2)
print('R*2 = ', R2)
print('R = ', R)
print('r_y_y_hat = ', np.corrcoef(y, y_hat)[0, 1])

n = 30
p = 3
Ra2 = 1- (n-1)/(n-p-1)*(1-R2)
Ra = np.sqrt(Ra2)
print('Ra = ', Ra)
print('Ra*2 = ', Ra2)

print('r1 = ', np.corrcoef(y, x1)[0,1])
print('r2 = ', np.corrcoef(y, x2)[0,1])
print('r3 = ', np.corrcoef(y, x3)[0,1])

U = np.sum((y_hat-y_hat.mean())**2)
Syy = np.sum((y-y.mean())**2)
error = y - y_hat
Q = np.sum( (error)**2 )
print('Syy = ', Syy, 'U = ', U, 'Q = ', Q, 'U+Q = ', U + Q)

F = (np.sum( (y_hat - y_hat.mean())**2 )/3)/ (np.sum( (error)**2 )/(30-3-1))
print('F = ', F)
F_alpha = stats.f.ppf([0.95], p, n-p-1)[0]
print('F_alpha = ', F_alpha)

for i in range(1,4):
    #Fi = b[i]**2*(1/xinv[i,i])/ (Q/(44-3-1))
    ti = b[i]/np.sqrt(xinv[i,i]*Q/(30-3-1)  )
    print('b'+str(i), '  t=', ti)
t_alpha = stats.t.ppf([0.025, 0.975], n-p-1)
print('t_alpha = ', t_alpha)



















