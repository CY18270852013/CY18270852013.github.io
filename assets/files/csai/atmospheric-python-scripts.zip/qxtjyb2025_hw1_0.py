# -*- coding: utf-8 -*-
"""
Created on Tue Feb 25 08:14:38 2025

@author: Chen Yong
"""

import netCDF4 as nc
import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER

file_path = r'C:\Users\Chen Yong\Desktop\气象统计预报上机作业\CN05.1_Pre_1961_2022_monthly_025x025.nc'
ds = xr.open_dataset(file_path)

pre = ds['pre'] # 降雨量数据，维度为 (time, lat, lon)
lat = ds['lat'][:] # 纬度数据的全部
lon = ds['lon'][:] # 经度数据的全部
year = pre['time.year'] # 年份信息

annual_pre = pre.groupby(year).sum(dim = 'time')
annual_mean = annual_pre.mean(dim = 'year')
annual_var = annual_pre.var(dim = 'year')

ds.close()

def plot_spatial_distribution(data, title, label, cmap = 'Blues'): # 这里的参数是什么意思？
    proj = ccrs.PlateCarree() # 数据的坐标参考系
    fig = plt.figure(figsize = (10, 6))
    ax = fig.add_subplot(1, 1, 1, projection = proj)
    ax.set_extent([73, 135, 15, 55], crs = proj)
    ax.add_feature(cfeature.COASTLINE, linewidth = 0.8) # 这里coastline必须要大写吗？
    ax.add_feature(cfeature.BORDERS, linestyle = ':', linewidth = 0.8) # 这里borders必须要大写吗？
    ax.add_feature(cfeature.STATES, linestyle = '--', linewidth = 0.5)
    contour = ax.contourf(lon, lat, data, transform = proj, cmap = cmap, levels = 20) # 这里的各个参数又是什么意思？
    cbar = plt.colorbar(contour, ax = ax, orientation = 'horizontal', pad = 0.1, shrink = 0.8) # 这里的各个参数又是什么意思？
    cbar.set_label(label)
    ax.set_title(title)
    
    # 添加网格线
    gl = ax.gridlines(crs = proj, draw_labels = True, linewidth = 1, color = 'gray', alpha = 0.5, linestyle = '--')
    gl.top_labels = False
    gl.right_labels = False
    gl.xformatter = LONGITUDE_FORMATTER
    gl.yformatter = LATITUDE_FORMATTER

    # 添加南海小图   
    ax_inset = fig.add_axes([0.63, 0.32, 0.2, 0.2], projection = proj)
    ax_inset.set_extent([105, 125, 0, 25], crs = proj)
    ax_inset.add_feature(cfeature.COASTLINE, linewidth = 0.6)
    ax_inset.add_feature(cfeature.BORDERS, linestyle = ':', linewidth = 0.6)
    ax_inset.contourf(lon, lat, data, transform = proj, cmap = cmap, levels = 20)
    
    plt.show()
   
plot_spatial_distribution(annual_mean, 'Annual Mean Precipitation (1961-2022)', 'Annual Mean Precipitation (mm)', cmap='Blues')
plot_spatial_distribution(annual_var, 'Annual Precipitation Variance (1961-2022)', 'Annual Precipitation Variance (mm²)', cmap='Reds')
                          