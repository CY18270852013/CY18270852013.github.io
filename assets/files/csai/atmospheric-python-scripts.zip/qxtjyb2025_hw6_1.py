import numpy as np
import xarray as xr
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from eofs.standard import Eof
from scipy import linalg
import pandas as pd
from matplotlib.colors import BoundaryNorm
import os
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
import cartopy

# Varimax旋转函数
def varimax(Phi, gamma=1.0, q=20, tol=1e-6):
    """
    参数:
        Phi: 载荷矩阵 (变量数 × 因子数)
        gamma: 旋转参数 (1.0为Varimax, 0.0为Quartimax)
        q: 最大迭代次数
        tol: 收敛容忍度
        
    返回:
        rot_loadings: 旋转后的载荷矩阵
        rot_mat: 旋转矩阵
    """
    p, k = Phi.shape
    R = np.eye(k)
    d = 0
    
    # 标准化载荷矩阵 (Kaiser标准化)
    Lambda = Phi / np.sqrt(np.sum(Phi**2, axis=0))
    
    for i in range(q):
        d_old = d
        # 计算目标函数梯度
        Lambda_rot = np.dot(Lambda, R)
        
        term1 = np.dot(Lambda.T, Lambda_rot**3)
        term2 = np.dot(Lambda.T, np.dot(Lambda_rot, np.diag(np.sum(Lambda_rot**2, axis=0) / p * gamma)))
        grad = term1 - term2
        
        # 使用SVD求解旋转矩阵
        u, s, vh = np.linalg.svd(grad)
        R = np.dot(u, vh)
        d = np.sum(s)
        
        # 检查收敛
        if d_old != 0 and d/d_old < 1 + tol:
            break
    
    # 应用旋转
    rot_loadings = np.dot(Phi, R)
    return rot_loadings, R

# 设置绘图
plt.rcParams.update({
    'font.size': 12,
    'axes.titlesize': 14,
    'axes.labelsize': 12,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'figure.figsize': (15, 14)
})

# 读取数据
file_path = r'C:\Users\Chen Yong\Desktop\气象统计预报上机作业\221830211_陈勇_作业六\CN05.1_Pre_1961_2022_monthly_025x025.nc'
ds = xr.open_dataset(file_path)

# 提取降水数据
precip = ds['pre']

# 计算气候态月平均
clim_monthly_mean = precip.groupby('time.month').mean('time')

# 计算距平（不进行标准化）
precip_anomaly = precip.groupby('time.month') - clim_monthly_mean

# 处理NaN值
precip_anomaly = precip_anomaly.where(np.isfinite(precip_anomaly), 0)

# 数据重塑为二维数组 (时间, 空间)
precip_stacked = precip_anomaly.stack(space=('lat', 'lon'))
precip_2d = precip_stacked.transpose('time', 'space').values

# EOF分析
solver = Eof(precip_2d)
n_modes = 10  # 选择前10个模态进行旋转

# 获取EOF和PC
eofs = solver.eofs(neofs=n_modes, eofscaling=0)  # 无缩放
pcs = solver.pcs(npcs=n_modes, pcscaling=0)
eigenvalues = solver.eigenvalues(neigs=n_modes)
variance_fraction = solver.varianceFraction(neigs=n_modes)

# 计算载荷矩阵
loadings = eofs * np.sqrt(eigenvalues)[:, np.newaxis]
loadings_2d = loadings.reshape(n_modes, -1).T  # 转换为(空间点, 模态)

# Varimax旋转
# 使用修复的Varimax函数
rotated_loadings, rotation_matrix = varimax(loadings_2d)

# 计算旋转EOF(REOF)
reofs = rotated_loadings.T.reshape((n_modes,) + precip_anomaly.shape[1:])  # 重塑为原始空间形状

# 计算旋转主成分(RPC)
rpc = pcs @ rotation_matrix.T

# 正确计算方法：总方差 = 数据矩阵所有元素的平方和 (因为距平数据均值为0)
total_variance = np.sum(precip_2d**2)

# 计算每个旋转模态的方差贡献
rotated_variance = []
for i in range(n_modes):
    # 计算该模态解释的方差 = RPC的平方和
    explained_variance = np.sum(rpc[:, i]**2)
    # 计算方差贡献率
    var_frac = explained_variance / total_variance
    rotated_variance.append(var_frac)

rotated_variance = np.array(rotated_variance)

# 创建中国区域地图投影
proj = ccrs.PlateCarree()

# 创建图形
fig = plt.figure(figsize=(15, 14))

# 设置统一的颜色等级和颜色映射
vmin, vmax = -1.0, 1.0
levels = np.linspace(vmin, vmax, 21)  # 20个间隔，21个边界
cmap = plt.cm.RdBu_r  # 使用红蓝配色
norm = BoundaryNorm(levels, ncolors=cmap.N, clip=True)

# 显示前4个REOF模态
n_show = min(4, n_modes)  # 确保不超过可用模态数
for i in range(n_show):
    # REOF空间模态
    ax = fig.add_subplot(n_show, 2, 2*i+1, projection=proj)
    ax.set_extent([70, 140, 15, 55], crs=proj)
    
    # 绘制REOF空间模态 - 使用统一的颜色等级
    contour = ax.contourf(
        precip_anomaly.lon, 
        precip_anomaly.lat, 
        reofs[i],
        levels=levels,
        cmap=cmap,
        norm=norm,
        transform=proj,
        extend='both'
    )
    
    # 添加等值线
    contour_lines = ax.contour(
        precip_anomaly.lon, 
        precip_anomaly.lat, 
        reofs[i],
        levels=levels[::2],  # 每2个级别画一条线
        colors='k',
        linewidths=0.5,
        transform=proj
    )
    plt.clabel(contour_lines, inline=True, fontsize=8, fmt='%1.1f')
    
    # 添加地理特征
    ax.add_feature(cfeature.COASTLINE, linewidth=0.8)
    ax.add_feature(cfeature.BORDERS, linestyle=':', linewidth=0.8)
    ax.add_feature(cfeature.LAKES, alpha=0.5)
    ax.add_feature(cfeature.RIVERS, linewidth=0.5)
    
    # 设置网格和刻度
    ax.set_xticks(np.arange(70, 141, 10))
    ax.set_yticks(np.arange(15, 56, 10))
    ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%d°E'))
    ax.yaxis.set_major_formatter(mticker.FormatStrFormatter('%d°N'))
    ax.grid(True, linestyle='--', alpha=0.5)
    
    # 添加标题
    ax.set_title(f'REOF Mode {i+1} (Variance: {rotated_variance[i]*100:.1f}%)', fontsize=12)
    
    # 添加南海小图
    # 创建插入的小图坐标系
    ax_inset = inset_axes(
        ax, 
        width="30%",  # 宽度为主图的30%
        height="30%",  # 高度为主图的30%
        loc='lower right',  # 放在右下角
        bbox_to_anchor=(0.05, 0.01, 0.99, 0.99),  # 位置微调
        bbox_transform=ax.transAxes,
        axes_class=cartopy.mpl.geoaxes.GeoAxes,
        axes_kwargs=dict(map_projection=proj)
    )
    
    # 设置南海小图的范围
    ax_inset.set_extent([105, 125, 3, 25], crs=proj)  # 南海区域
    
    # 绘制相同的REOF模态数据
    ax_inset.contourf(
        precip_anomaly.lon, 
        precip_anomaly.lat, 
        reofs[i],
        levels=levels,
        cmap=cmap,
        norm=norm,
        transform=proj,
        extend='both'
    )
    
    # 添加地理特征
    ax_inset.add_feature(cfeature.COASTLINE, linewidth=0.8)
    ax_inset.add_feature(cfeature.BORDERS, linestyle=':', linewidth=0.8)
    
    # 添加小图边框
    ax_inset.spines['geo'].set_edgecolor('black')
    ax_inset.spines['geo'].set_linewidth(1.0)
    
    # 添加矩形框指示位置
    rect = plt.Rectangle(
        (105, 3), 20, 22, 
        fill=False, 
        edgecolor='red', 
        linewidth=1.0,
        transform=proj
    )
    # ax.add_patch(rect)  #指示框
    
    # RPC时间序列 - 柱状图
    ax_ts = fig.add_subplot(n_show, 2, 2*i+2)
    
    # 创建年度RPC数据
    # 将RPC数据转换为DataArray以便按年分组
    rpc_da = xr.DataArray(
        rpc[:, i],
        dims=['time'],
        coords={'time': precip_anomaly.time}
    )
    
    # 按年分组取平均
    rpc_annual = rpc_da.groupby('time.year').mean('time')
    
    # 获取年份和值
    years = rpc_annual.year.values
    values = rpc_annual.values
    
    # 设置柱状图颜色 - 正值为红色，负值为蓝色
    bar_colors = np.where(values > 0, '#d62728', '#1f77b4')
    
    # 绘制柱状图
    ax_ts.bar(years, values, 
             width=0.8, 
             color=bar_colors,
             edgecolor='none')
    
    # 添加零线
    ax_ts.axhline(0, color='k', linestyle='-', alpha=0.7)
    
    # 标签设置
    ax_ts.set_title(f'Rotated PC {i+1} Time Series (Annual Mean)', fontsize=12)
    ax_ts.set_xlabel('Year')
    ax_ts.set_ylabel('Normalized Units')
    ax_ts.grid(axis='y', alpha=0.3)
    
    # 设置x轴刻度 - 每10年显示一个刻度
    ax_ts.set_xticks(np.arange(min(years), max(years)+1, 10))
    ax_ts.set_xlim(min(years)-0.5, max(years)+0.5)
    
    # 自动调整y轴范围
    y_abs_max = np.max(np.abs(values)) * 1.2
    ax_ts.set_ylim(-y_abs_max, y_abs_max)

# 给所有子图添加统一的颜色条
cax = fig.add_axes([0.1, 0.05, 0.5, 0.02])  # [左, 下, 宽, 高]
cbar = plt.colorbar(contour, cax=cax, orientation='horizontal')
cbar.set_label('REOF Loading', fontsize=12)
cbar.set_ticks(levels[::4])  # 每4个级别显示一个刻度，避免太密集

# 添加整体标题
plt.suptitle('Rotated EOF Analysis of Precipitation over China (1961-2022)', 
             fontsize=16, y=0.98)

# 调整布局
plt.tight_layout(rect=[0, 0.05, 1, 0.98])  # 为底部颜色条留出空间

# 保存结果
output_path = r'C:\Users\Chen Yong\Desktop\气象统计预报上机作业\221830211_陈勇_作业六\REOF_Precipitation_Analysis_Anomaly.png'
plt.savefig(output_path, dpi=1000, bbox_inches='tight')

plt.show()

# 输出结果统计信息
print(f"总解释方差: {np.sum(variance_fraction[:n_modes])*100:.1f}%")
print(f"旋转后各模态解释方差:")
for i in range(n_show):
    print(f"  Mode {i+1}: {rotated_variance[i]*100:.1f}%")
    

# 确保输出目录存在
output_dir = r'C:\Users\Chen Yong\Desktop\气象统计预报上机作业\221830211_陈勇_作业六'
os.makedirs(output_dir, exist_ok=True)

# 创建REOF的xarray DataArray
reof_da = xr.DataArray(
    reofs,
    dims=('mode', 'lat', 'lon'),
    coords={
        'mode': np.arange(1, n_modes+1),
        'lat': precip_anomaly.lat,
        'lon': precip_anomaly.lon
    },
    name='reof'
)

# 创建RPC的xarray DataArray
rpc_da = xr.DataArray(
    rpc,
    dims=('time', 'mode'),
    coords={
        'time': precip_anomaly.time,
        'mode': np.arange(1, n_modes+1)
    },
    name='rpc'
)

# 创建包含方差贡献的DataArray
variance_da = xr.DataArray(
    rotated_variance,
    dims=('mode'),
    coords={'mode': np.arange(1, n_modes+1)},
    name='variance'
)

# 创建数据集并保存
reof_ds = xr.Dataset({
    'reof': reof_da,
    'rpc': rpc_da,
    'variance': variance_da
})

reof_ds.attrs['description'] = 'Rotated EOF results for precipitation over China (anomaly only)'
reof_ds.attrs['method'] = 'Varimax rotation'
reof_ds.attrs['n_modes'] = n_modes
reof_ds.attrs['total_variance'] = total_variance  # 保存总方差

# 使用更安全的文件路径
output_nc_path = os.path.join(output_dir, 'REOF_Precipitation_Results_Anomaly.nc')


# 保存文件
reof_ds.to_netcdf(output_nc_path)