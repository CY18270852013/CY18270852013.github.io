import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime, timedelta
import os

# 设置全局字体
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 12

# 1. 定义分析区域和时间范围
freddy_box = {
    'lon_min': 110,
    'lon_max': 120,
    'lat_min': -20,
    'lat_max': -10
}
start_date = datetime(2023, 2, 1)
end_date = datetime(2023, 3, 15)

# 2. 加载数据函数 - 修复区域选择问题
def load_and_process_data(file_path, var_name):
    """加载数据并处理为区域平均时间序列"""
    print(f"\n处理数据: {os.path.basename(file_path)}")
    
    # 打开数据集
    ds = xr.open_dataset(file_path)
    
    # 确保纬度按升序排列（南到北）
    if ds.lat[0] > ds.lat[-1]:
        ds = ds.sortby('lat')
    
    # 打印数据集信息
    print(f"  数据集维度: {dict(ds.dims)}")
    print(f"  时间范围: {ds.time.min().values} 至 {ds.time.max().values}")
    print(f"  纬度范围: {ds.lat.min().values:.2f} 至 {ds.lat.max().values:.2f}")
    print(f"  经度范围: {ds.lon.min().values:.2f} 至 {ds.lon.max().values:.2f}")
    
    # 确保时间坐标正确
    if not np.issubdtype(ds.time.dtype, np.datetime64):
        print("  转换时间坐标...")
        ds = xr.decode_cf(ds)
    
    # 选择目标区域 - 使用条件选择而非slice
    print(f"  选择区域: lon={freddy_box['lon_min']}-{freddy_box['lon_max']}E, lat={freddy_box['lat_min']}-{freddy_box['lat_max']}S")
    
    # 创建经纬度选择条件
    lon_condition = (ds.lon >= freddy_box['lon_min']) & (ds.lon <= freddy_box['lon_max'])
    lat_condition = (ds.lat >= freddy_box['lat_min']) & (ds.lat <= freddy_box['lat_max'])
    
    # 应用选择条件
    ds_region = ds.where(lon_condition & lat_condition, drop=True)
    
    # 检查区域选择后的数据
    if len(ds_region.lat) == 0 or len(ds_region.lon) == 0:
        print(f"  警告: 没有找到匹配的网格点! 纬度: {ds_region.lat.values}")
        print(f"        经度: {ds_region.lon.values}")
        print("  尝试重新计算选择条件...")
        # 寻找最接近的纬度点
        target_lat = (freddy_box['lat_min'] + freddy_box['lat_max']) / 2
        closest_lat_idx = np.abs(ds.lat.values - target_lat).argmin()
        print(f"  最接近的纬度点: {ds.lat[closest_lat_idx].values:.2f}")
        # 使用最接近的纬度点
        lat_condition = (ds.lat == ds.lat[closest_lat_idx])
        ds_region = ds.where(lon_condition & lat_condition, drop=True)
    
    print(f"  选择后时间点数量: {len(ds_region.time)}")
    print(f"  选择后网格点数量: {len(ds_region.lat)} x {len(ds_region.lon)}")
    
    # 空间平均 (忽略NaN值)
    print("  计算空间平均...")
    if 'lat' in ds_region.dims and 'lon' in ds_region.dims:
        ds_avg = ds_region.mean(dim=['lat', 'lon'], skipna=True)
    else:
        ds_avg = ds_region
    
    # 检查结果数据
    data_values = ds_avg[var_name].values
    num_nan = np.isnan(data_values).sum()
    print(f"  结果数据点数量: {len(data_values)}")
    
    if num_nan < len(data_values):
        print(f"  NaN值数量: {num_nan} ({num_nan/len(data_values)*100:.1f}%)")
        print(f"  最小值: {np.nanmin(data_values):.2f}, 最大值: {np.nanmax(data_values):.2f}")
    else:
        print("  警告: 所有数据点均为NaN!")
    
    # 关闭数据集
    ds.close()
    
    return ds_avg[var_name]

# 3. 加载所有数据
print("\n开始加载数据...")
# 原始降水异常
precip_anom = load_and_process_data(
    'E:/GPM_anomaly_6hours_accumulated/GPM_anomaly_20230101_20230331.nc',
    'precipitation_anomaly'
)

# 各波动分量
mjo_anom = load_and_process_data(
    'E:/GPM_anomaly_6hours_accumulated/GPM_anomaly_for_MJO_20230101_20230331.nc',
    'mjo'
)

kelvin_anom = load_and_process_data(
    'E:/GPM_anomaly_6hours_accumulated/GPM_anomaly_for_Kelvin_20230101_20230331.nc',
    'kelvin'
)

mrg_anom = load_and_process_data(
    'E:/GPM_anomaly_6hours_accumulated/GPM_anomaly_for_MRG_20230101_20230331.nc',
    'mrg'
)

er_anom = load_and_process_data(
    'E:/GPM_anomaly_6hours_accumulated/GPM_anomaly_for_ER_20230101_20230331.nc',
    'er'
)

# 4. 计算波动总和
print("\n计算波动总和...")
waves_sum = mjo_anom + kelvin_anom + er_anom + mrg_anom

# 5. 创建时间序列图
print("\n创建时间序列图...")
fig, ax = plt.subplots(figsize=(14, 7), dpi=300)

# 设置时间坐标
time = precip_anom.time.values

# 绘制各分量
ax.plot(time, precip_anom, color='green', linewidth=2, label='Total Anomaly')
ax.plot(time, kelvin_anom, color='blue', linewidth=1.5, label='Kelvin Wave')
ax.plot(time, er_anom, color='red', linewidth=1.5, label='ER Wave')
ax.plot(time, mjo_anom, color='black', linewidth=1.5, label='MJO')
ax.plot(time, mrg_anom, color='gray', linewidth=1.5, label='MRG Wave')
ax.plot(time, waves_sum, color='purple', linewidth=2.5, linestyle='-', label='Sum of Waves')

# 设置坐标轴和标题
ax.set_title('Precipitation Anomalies and Wave Contributions in Freddy Genesis Region (10°S-20°S, 110°E-120°E)', 
             fontsize=14, pad=12)
ax.set_xlim([datetime(2023, 2, 1), datetime(2023, 3, 15)])
ax.set_xlabel('Date', fontsize=12)
ax.set_ylim(-2.3, 1.5)
ax.set_ylabel('Precipitation Anomaly (mm)', fontsize=12)

# 设置时间轴格式
ax.xaxis.set_major_locator(mdates.DayLocator(interval=2))
ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d'))
ax.tick_params(axis='x', rotation=45)  # 旋转日期标签避免重叠
ax.tick_params(axis='both', which='major', labelsize=10)

# 设置纵轴范围 - 安全处理NaN值
def safe_nan_extremes(data, factor=1.2):
    """安全计算数据范围，处理NaN值"""
    valid_data = data[~np.isnan(data)]
    if len(valid_data) == 0:
        print("警告: 数据全为NaN，使用默认范围[-10, 10]")
        return -10, 10
    
    data_min = -2.3
    data_max = 1.5
    range_padding = max(0.1 * (data_max - data_min), 0.5)  # 确保有最小填充
    
    return data_min, data_max

# 计算纵轴范围
ymin1, ymax1 = safe_nan_extremes(precip_anom.values)
ymin2, ymax2 = safe_nan_extremes(waves_sum.values)
ymin = min(ymin1, ymin2)
ymax = max(ymax1, ymax2)

# 设置纵轴范围
ax.set_ylim(ymin, ymax)

# 添加网格和零线
ax.grid(True, linestyle='--', alpha=0.3)
ax.axhline(y=0, color='k', linestyle='-', alpha=0.5)

# 添加图例
ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.15), 
          ncol=6, fontsize=11, framealpha=0.9)

# 添加Freddy生成时间标注
genesis_date = datetime(2023, 2, 6)  # 请根据实际气旋时间修改
ax.axvline(x=genesis_date, color='magenta', linestyle='--', alpha=0.8)
ax.text(genesis_date, ymax*0.9, 'Freddy Genesis', 
        color='magenta', fontsize=11, ha='center')

# 优化布局
plt.tight_layout()

# 6. 保存结果
output_file = 'D:\Freddy_ChenYong\Plot_ChenYong\Figure5_Freddy_Genesis_Box\precipitation_Freddy_Genesis_Box_2.png'
plt.savefig(output_file, bbox_inches='tight', dpi=500)
print(f"\n图像已保存至: {output_file}")

plt.show()

print("\n处理完成!")