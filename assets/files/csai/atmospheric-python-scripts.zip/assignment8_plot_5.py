import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# 文件路径
file_path = r'C:\Users\Chen Yong\Desktop\result3.txt'

# 初始化
cases = []
current_case = None
current_trajectory = []

# 读取文件
with open(file_path, 'r') as f:
    for line in f:
        if "Case:" in line:
            if current_case:
                current_case["trajectory"] = np.array(current_trajectory)
                cases.append(current_case)
            parts = line.split()
            case_number = int(parts[1])
            b = float(parts[3].strip('b='))
            s = float(parts[5].strip('s='))
            r = float(parts[7].strip('r='))
            initial = [float(parts[9]), float(parts[10]), float(parts[11])]
            current_case = {"case_number": case_number, "b": b, "s": s, "r": r, "initial": initial}
            current_trajectory = []
        elif line.strip():
            current_trajectory.append(list(map(float, line.strip().split())))

if current_case:
    current_case["trajectory"] = np.array(current_trajectory)
    cases.append(current_case)

# 绘制三维轨迹
fig = plt.figure(figsize=(15, 10))
ax = fig.add_subplot(111, projection='3d')
for case in cases:
    traj = case["trajectory"]
    ax.plot(traj[:, 0], traj[:, 1], traj[:, 2], label=f"Case {case['case_number']}: b={case['b']}, s={case['s']}, r={case['r']}")

# 图形美化
ax.set_title("3D Trajectories of Lorenz System (Euler Method)")
ax.set_xlabel("x")
ax.set_ylabel("y")
ax.set_zlabel("z")
ax.legend(loc="best", fontsize=8)
plt.show()
