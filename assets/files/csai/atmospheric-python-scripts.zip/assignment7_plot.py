import matplotlib.pyplot as plt
import numpy as np

# 读取数据文件
file_path = r'C:\Users\Chen Yong\Desktop\results.txt'

# 定义容器来存储数据
h_values = []
romberg_errors = []
legendre_errors = []

# 读取文件内容
with open(file_path, 'r') as f:
    for line in f:
        # 只读取包含 'h' 的行
        if line.startswith("h ="):
            # 提取h值、Romberg误差和Gauss-Legendre误差
            parts = line.split()
            h_values.append(float(parts[1]))  # h 值
            romberg_errors.append(float(parts[5]))  # Romberg误差
            legendre_errors.append(float(parts[8]))  # Gauss-Legendre误差

# 转换为 numpy 数组，以便绘图
h_values = np.array(h_values)
romberg_errors = np.array(romberg_errors)
legendre_errors = np.array(legendre_errors)

# 处理零或负误差值：用一个非常小的正数替代零或负误差值
# 替换误差为零或负值的地方为一个很小的正数
romberg_errors = np.where(romberg_errors <= 0, 1e-10, romberg_errors)
legendre_errors = np.where(legendre_errors <= 0, 1e-10, legendre_errors)

# 绘制误差随h变化的折线图
plt.figure(figsize=(10, 6))

# 绘制 Romberg 求积法误差的折线图
plt.plot(h_values, romberg_errors, label='Romberg Error', color='blue', marker='o')

# 绘制 Gauss-Legendre 求积法误差的折线图
plt.plot(h_values, legendre_errors, label='Gauss-Legendre Error', color='red', marker='x')

# 设置图表标题和标签
plt.title('The error varies with step size (h).', fontsize=14)
plt.xlabel('Step length h', fontsize=12)
plt.ylabel('Error', fontsize=12)

# 使用线性坐标轴绘制图形（避免对数坐标轴的错误）
# plt.xscale('log')  # 可以取消这行，使用默认的线性坐标轴
# plt.yscale('log')  # 可以取消这行，使用默认的线性坐标轴

# 添加图例
plt.legend()

# 显示图形
plt.grid(True)
plt.show()
