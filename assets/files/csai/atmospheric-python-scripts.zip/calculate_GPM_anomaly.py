import numpy as np
import netCDF4 as nc
import os
from datetime import datetime, timedelta
import gc
import warnings
import time

warnings.filterwarnings('ignore')  # 忽略一些不影响计算的警告

# 配置路径
input_dir = "E:/GPM_6hourly_20090101_20231231"
output_dir = "E:/GPM_anomaly"
os.makedirs(output_dir, exist_ok=True)
output_file = os.path.join(output_dir, "GPM_anomaly_20230101_20230331.nc")

# 时间参数
start_date = datetime(2023, 1, 1)
end_date = datetime(2023, 3, 31)
climatology_years = list(range(2009, 2024))  # 2009-2023年气候态数据

# 1. 构建时间索引映射（每年1460个6小时时间点）
def get_time_index(dt):
    """计算日期时间在一年中的时间索引(0-1459)，忽略闰日"""
    # 计算年日(0-based) 1月1日=0, 12月31日=364
    doy = (dt - datetime(dt.year, 1, 1)).days
    # 调整闰年：3月1日之后日期减1天（跳过2月29日）
    if dt.month > 2 and (dt.year % 4 == 0 and (dt.year % 100 != 0 or dt.year % 400 == 0)):
        doy -= 1
    
    # 计算时间片索引(00:00=0, 06:00=1, 12:00=2, 18:00=3)
    time_slice = dt.hour // 6
    return doy * 4 + time_slice

# 2. 直接计算谐波系数（高效内存版本）
def calculate_harmonics():
    print("直接计算谐波系数...")
    T = 1460  # 一年中的时间点数（整数）
    
    # 预先计算基函数
    t = np.arange(T)
    basis_functions = np.array([
        np.ones(T),
        np.cos(2 * np.pi * t / T),
        np.sin(2 * np.pi * t / T),
        np.cos(4 * np.pi * t / T),
        np.sin(4 * np.pi * t / T),
        np.cos(6 * np.pi * t / T),
        np.sin(6 * np.pi * t / T)
    ], dtype=np.float32)  # 使用float32减少内存
    
    # 计算最小二乘矩阵
    X = basis_functions.T
    XTX = X.T @ X
    XTX_inv = np.linalg.inv(XTX)
    
    # 初始化谐波系数数组
    harmonics = np.zeros((7, 1800, 3600), dtype=np.float32)
    
    # 使用更大的块大小，减少循环次数
    block_size = 100  # 每次处理100个经度点
    num_blocks = (3600 + block_size - 1) // block_size
    
    # 准备时间点映射
    time_point_map = {}
    for t_idx in range(T):
        base_date = datetime(2000, 1, 1)  # 使用参考年份
        days = t_idx // 4
        hours = (t_idx % 4) * 6
        dt = base_date + timedelta(days=days, hours=hours)
        time_point_map[t_idx] = (dt.month, dt.day, dt.hour)
    
    # 顺序处理经度块
    for block_idx in range(num_blocks):
        lon_start = block_idx * block_size
        lon_end = min(lon_start + block_size, 3600)
        num_lons = lon_end - lon_start
        
        print(f"处理经度块: {lon_start}-{lon_end} ({num_lons}个经度点)")
        start_time = time.time()
        
        # 初始化累加器
        XTy_accum = np.zeros((7, 1800, num_lons), dtype=np.float32)
        count_accum = np.zeros(T, dtype=np.int32)
        
        # 处理所有时间点
        for t_idx in range(T):
            month, day, hour = time_point_map[t_idx]
            
            # 初始化当前时间点的累加器
            time_sum = np.zeros((1800, num_lons), dtype=np.float32)
            time_count = 0
            
            # 处理所有年份
            for year in climatology_years:
                # 跳过闰年的2月29日
                if month == 2 and day == 29 and (year % 4 != 0 or (year % 100 == 0 and year % 400 != 0)):
                    continue
                    
                try:
                    # 构建文件名
                    dt = datetime(year, month, day, hour)
                    start_str = dt.strftime("%Y%m%d%H%M%S")
                    end_date_6hr = dt + timedelta(hours=6) - timedelta(seconds=1)
                    end_str = end_date_6hr.strftime("%Y%m%d%H%M%S")
                    filename = f"GPM_6hourly_{start_str}_{end_str}.nc"
                    filepath = os.path.join(input_dir, filename)
                    
                    # 读取数据
                    if os.path.exists(filepath):
                        with nc.Dataset(filepath, 'r') as ds:
                            # 只读取当前经度块
                            precip = ds['precipitation'][0, :, lon_start:lon_end]
                            time_sum += precip
                            time_count += 1
                except Exception as e:
                    print(f"  读取文件 {filename} 时出错: {str(e)}")
            
            # 计算当前时间点的平均值
            if time_count > 0:
                time_avg = time_sum / time_count
                count_accum[t_idx] = time_count
                
                # 累加到XTy
                for i in range(7):
                    XTy_accum[i] += basis_functions[i, t_idx] * time_avg
        
        # 计算谐波系数
        XTy_2d = XTy_accum.reshape(7, -1)
        coeffs = XTX_inv @ XTy_2d
        coeffs = coeffs.reshape(7, 1800, num_lons)
        
        # 保存系数
        harmonics[:, :, lon_start:lon_end] = coeffs
        
        # 显示处理时间
        elapsed = time.time() - start_time
        print(f"  经度块处理完成，耗时: {elapsed:.2f}秒")
        
        # 释放内存
        del XTy_accum, coeffs, time_sum
        gc.collect()
    
    return harmonics

# 3. 计算2023年异常值
def calculate_anomalies(harmonics):
    print("计算2023年异常值...")
    # 预计算时间值
    time_values = []
    current_date = start_date
    while current_date <= end_date:
        if current_date.month == 2 and current_date.day == 29:
            current_date += timedelta(days=1)
            continue
        t_idx = get_time_index(current_date)
        time_values.append((current_date, t_idx))
        current_date += timedelta(hours=6)
    
    # 创建输出文件
    with nc.Dataset(output_file, 'w', format='NETCDF4') as out_ds:
        # 创建维度
        out_ds.createDimension('time', len(time_values))
        out_ds.createDimension('lat', 1800)
        out_ds.createDimension('lon', 3600)
        
        # 创建时间变量
        time_var = out_ds.createVariable('time', 'f8', ('time',))
        time_var.units = 'hours since 2023-01-01 00:00:00'
        time_var.calendar = 'standard'
        
        # 创建经纬度变量（从示例文件获取）
        with nc.Dataset(os.path.join(input_dir, "GPM_6hourly_20090101000000_20090101055959.nc"), 'r') as src:
            lon = src['lon'][:]
            lat = src['lat'][:]
        
        lon_var = out_ds.createVariable('lon', 'f4', ('lon',))
        lon_var[:] = lon
        lat_var = out_ds.createVariable('lat', 'f4', ('lat',))
        lat_var[:] = lat
        
        # 创建异常变量
        precip_var = out_ds.createVariable('precipitation_anomaly', 'f4', ('time', 'lat', 'lon'),
                                          fill_value=-9999.9, zlib=True)
        precip_var.units = 'mm'
        precip_var.long_name = '6-hour precipitation anomaly'
        
        # 预计算基函数值
        T = 1460
        base_functions = np.zeros((len(time_values), 7), dtype=np.float32)
        for i, (_, t_idx) in enumerate(time_values):
            base_functions[i] = [
                1,
                np.cos(2 * np.pi * t_idx / T),
                np.sin(2 * np.pi * t_idx / T),
                np.cos(4 * np.pi * t_idx / T),
                np.sin(4 * np.pi * t_idx / T),
                np.cos(6 * np.pi * t_idx / T),
                np.sin(6 * np.pi * t_idx / T)
            ]
        
        # 逐时间步处理
        hours_list = []
        for i, (dt, _) in enumerate(time_values):
            start_time = time.time()
            print(f"处理时间: {dt.strftime('%Y-%m-%d %H:%M:%S')}")
            
            # 构建文件名
            start_str = dt.strftime("%Y%m%d%H%M%S")
            end_date_6hr = dt + timedelta(hours=6) - timedelta(seconds=1)
            end_str = end_date_6hr.strftime("%Y%m%d%H%M%S")
            filename = f"GPM_6hourly_{start_str}_{end_str}.nc"
            filepath = os.path.join(input_dir, filename)
            
            # 读取原始降水
            if not os.path.exists(filepath):
                print(f"  文件不存在: {filename}")
                # 创建空数据
                precip = np.zeros((1800, 3600), dtype=np.float32)
            else:
                with nc.Dataset(filepath, 'r') as ds:
                    precip = ds['precipitation'][0, :, :].astype(np.float32)
            
            # 计算气候预测值
            clim_pred = np.zeros((1800, 3600), dtype=np.float32)
            for j in range(7):
                clim_pred += base_functions[i, j] * harmonics[j]
            
            # 计算异常值
            anomaly = precip - clim_pred
            
            # 写入异常值
            precip_var[i, :, :] = anomaly
            
            # 记录时间
            hours_list.append((dt - datetime(2023, 1, 1)).total_seconds() / 3600)
            
            # 显示处理时间
            elapsed = time.time() - start_time
            print(f"  处理完成，耗时: {elapsed:.2f}秒")
        
        # 写入时间变量
        time_var[:] = hours_list
        
        # 添加全局属性
        out_ds.title = "GPM IMERG 6-Hourly Precipitation Anomaly"
        out_ds.history = f"Created {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        out_ds.source = "Processed from GPM IMERG data"
        out_ds.reference = "Methodology based on Latos et al. 2023 (doi:10.1038/s41467-023-36498-w)"

# 主函数
def main():
    start_time = time.time()
    
    # 计算谐波系数
    harmonics = calculate_harmonics()
    
    # 保存谐波系数以便调试
    np.save(os.path.join(output_dir, "harmonics.npy"), harmonics)
    print("谐波系数已保存到文件")
    
    # 计算异常值
    calculate_anomalies(harmonics)
    
    total_time = time.time() - start_time
    print(f"处理完成！总耗时: {total_time/3600:.2f}小时")

if __name__ == "__main__":
    main()