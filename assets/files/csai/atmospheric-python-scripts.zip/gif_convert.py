# -*- coding: utf-8 -*-
"""
Created on Sun Oct 13 20:34:15 2024

@author: Dell
"""

from PIL import Image
import os

# 图片文件夹路径和输出动图路径
image_folder = r'C:\Users\Dell\Desktop\w_mjo_500hPa_with_track'
output_gif = r'C:\Users\Dell\Desktop\w_mjo_500hPa_with_track\output.gif'

# 获取图片文件列表，严格按文件名顺序排序
image_files = sorted([f for f in os.listdir(image_folder) if f.endswith('.png')], key=lambda x: int(x.split('.')[0]))

# 检查图片列表是否为空
if not image_files:
    print("未找到PNG图片。")
else:
    # 打开第一张图片作为动图的初始帧
    first_image = Image.open(os.path.join(image_folder, image_files[0]))
    
    # 打开其他图片帧并创建反向帧
    frames = [Image.open(os.path.join(image_folder, f)) for f in image_files[1:]]
    reverse_frames = frames[::-1]  # 反转顺序的帧

    # 将正序帧和反序帧合并
    all_frames = frames + reverse_frames

    # 保存为GIF格式，包含正反序帧，形成循环播放
    first_image.save(output_gif, save_all=True, append_images=all_frames, optimize=False, duration=1000, loop=0)
    
    print(f"动图制作完成！保存路径：{output_gif}")
