import xarray as xr
import matplotlib.pyplot as plt
import pandas as pd

# 加载数据
file_path = "C:/Users/Chen Yong/Downloads/ERA5 data/ERA5 data/2000-2021_Q_1000-100hPa_monthly.nc"
ds = xr.open_dataset(file_path)

# 将整数型日期转换为datetime格式
ds['date'] = pd.to_datetime(ds['date'].astype(str), format='%Y%m%d')

# 提取比湿数据，并计算年平均
q = ds['q']

# 创建一个包含年份的时间坐标
years = ds['date'].dt.year

# 按年份对每个气压层进行平均
q_1000 = q.sel(pressure_level=1000).groupby(years).mean('date')
q_850 = q.sel(pressure_level=850).groupby(years).mean('date')
q_500 = q.sel(pressure_level=500).groupby(years).mean('date')

# 绘制年平均比湿折线图
plt.figure(figsize=(10, 6))

plt.plot(q_1000['year'], q_1000.mean('latitude').mean('longitude'), label='1000 hPa', color='red', linewidth=2)
plt.plot(q_850['year'], q_850.mean('latitude').mean('longitude'), label='850 hPa', color='green', linewidth=2)
plt.plot(q_500['year'], q_500.mean('latitude').mean('longitude'), label='500 hPa', color='blue', linewidth=2)

# 添加图例和标题
plt.title('Annual Mean Specific Humidity (q) from 2000 to 2021', fontsize=14)
plt.xlabel('Year', fontsize=12)
plt.ylabel('Specific Humidity (kg/kg)', fontsize=12)
plt.legend()

# 显示图形
plt.grid(True)
plt.tight_layout()
plt.show()
