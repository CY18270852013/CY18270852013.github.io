# -*- coding: utf-8 -*-
"""
Created on Wed Jul 16 12:26:16 2025

@author: Dell
"""

import os
import h5py
import numpy as np
from datetime import datetime, timedelta
from netCDF4 import Dataset

# 配置路径
input_dir = r'\\DS1821\Observation\GPM'
output_dir = r'E:\GPM_daily_20090101_20231231'
os.makedirs(output_dir, exist_ok=True)

# 时间范围
start_date = datetime(2023, 9, 3)
end_date = datetime(2023, 9, 3)

# 预计算经纬度网格 (0.1°分辨率)
lons = np.arange(-179.95, 180, 0.1).round(2)
lats = np.arange(89.95, -90, -0.1).round(2)  # 从北到南

# 基准时间 (1980-01-06 UTC)
base_time = datetime(1980, 1, 6)

# 遍历每一天
current_date = start_date
while current_date <= end_date:
    date_str = current_date.strftime("%Y%m%d")
    print(f"Processing date: {date_str}")
    
    # 初始化累积降水数组
    accum_precip = np.zeros((1800, 3600), dtype=np.float32)
    missing_mask = np.zeros((1800, 3600), dtype=bool)
    
    # 初始化文件计数和缺失文件计数
    total_files = 0
    missing_files = 0
    
    # 处理48个时段 (一天48个半小时文件)
    for i in range(48):  # 0到47个半小时时段
        # 计算半小时文件的起始时间
        hours = i // 2
        minutes = 30 * (i % 2)
        time_str = f"{hours:02d}{minutes:02d}00"
        
        # 计算结束时间 (29分59秒后)
        start_time = datetime.strptime(f"{date_str}{time_str}", "%Y%m%d%H%M%S")
        end_time = start_time + timedelta(minutes=29, seconds=59)
        end_time_str = end_time.strftime("%H%M%S")
        
        # 计算分钟偏移量
        total_minutes = hours * 60 + minutes
        minute_offset = f"{total_minutes:04d}"
        
        # 尝试V07A和V07B版本
        base_name = f"3B-HHR.MS.MRG.3IMERG.{date_str}-S{time_str}-E{end_time_str}.{minute_offset}"
        file_found = False
        file_path = None
        
        for version in ["V07A", "V07B"]:
            file_name = f"{base_name}.{version}.HDF5"
            file_path = os.path.join(input_dir, file_name)
            if os.path.exists(file_path):
                file_found = True
                break
        
        if not file_found:
            # 文件缺失，视为该时段降水为0
            print(f"  !! Missing file: {base_name} (Treating as zero precipitation)")
            missing_files += 1
            total_files += 1
            continue  # 继续下一个时段
        
        total_files += 1
        
        try:
            with h5py.File(file_path, 'r') as f:
                # 正确读取并转置数据形状
                precip_data = f['/Grid/precipitation'][:]
                
                # 处理可能的形状问题
                if precip_data.shape == (1, 1800, 3600):
                    precip = precip_data[0, :, :]  # 形状 (1800, 3600)
                elif precip_data.shape == (1, 3600, 1800):
                    precip = precip_data[0, :, :].T  # 转置为 (1800, 3600)
                elif precip_data.shape == (1800, 3600, 1):
                    precip = precip_data[:, :, 0]  # 形状 (1800, 3600)
                elif precip_data.shape == (3600, 1800, 1):
                    precip = precip_data[:, :, 0].T  # 转置为 (1800, 3600)
                else:
                    raise ValueError(f"Unexpected data shape: {precip_data.shape}")
                
                # 处理缺测值并累积
                valid_data = np.where(precip != -9999.9, precip * 0.5, 0)
                accum_precip += valid_data
                
                # 更新缺测掩码
                missing_mask |= (precip == -9999.9)
                
        except Exception as e:
            print(f"  !! Error reading {os.path.basename(file_path)}: {e}")
            # 文件读取错误，视为该时段降水为0
            missing_mask[:, :] = True  # 标记整个时段为缺测
    
    # 应用缺测值
    accum_precip[missing_mask] = -9999.9
    
    # 打印文件统计信息
    print(f"  Processed {total_files} files, {missing_files} missing files")
    
    # 构建输出文件名
    out_file = f"GPM_daily_{date_str}.nc"
    out_path = os.path.join(output_dir, out_file)
    
    # 创建NetCDF文件
    with Dataset(out_path, 'w', format='NETCDF4') as nc:
        # 全局属性
        nc.title = "GPM IMERG Daily Accumulated Precipitation"
        nc.source = "Converted from GPM half-hourly data"
        nc.history = f"Created on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        nc.Conventions = "CF-1.8"
        nc.missing_files = str(missing_files)  # 记录缺失文件数量
        
        # 创建维度
        nc.createDimension('lon', 3600)
        nc.createDimension('lat', 1800)
        nc.createDimension('time', 1)
        
        # 时间变量 (使用当天的00:00:00)
        time_var = nc.createVariable('time', 'i4', ('time',))
        seg_start = datetime.strptime(f"{date_str}000000", "%Y%m%d%H%M%S")
        time_val = int((seg_start - base_time).total_seconds())
        time_var[:] = time_val
        time_var.units = "seconds since 1980-01-06 00:00:00 UTC"
        time_var.long_name = "Time"
        time_var.calendar = "julian"
        time_var.bounds = "time_bnds"
        
        # 时间边界变量 (表示全天范围)
        nc.createDimension('nv', 2)
        time_bnds_var = nc.createVariable('time_bnds', 'i4', ('nv', 'time'))
        time_end = seg_start + timedelta(days=1)
        time_bnds_val = np.array([
            time_val,
            int((time_end - base_time).total_seconds())
        ]).reshape(2, 1)
        time_bnds_var[:] = time_bnds_val
        time_bnds_var.units = "seconds since 1980-01-06 00:00:00 UTC"
        
        # 经度变量
        lon_var = nc.createVariable('lon', 'f4', ('lon',))
        lon_var[:] = lons
        lon_var.units = "degrees_east"
        lon_var.long_name = "Longitude"
        lon_var.standard_name = "longitude"
        lon_var.bounds = "lon_bnds"
        
        # 经度边界
        nc.createDimension('lonv', 2)
        lon_bnds_var = nc.createVariable('lon_bnds', 'f4', ('lonv', 'lon'))
        lon_bnds = np.zeros((2, 3600), dtype=np.float32)
        lon_bnds[0, :] = lons - 0.05
        lon_bnds[1, :] = lons + 0.05
        lon_bnds_var[:] = lon_bnds
        
        # 纬度变量
        lat_var = nc.createVariable('lat', 'f4', ('lat',))
        lat_var[:] = lats
        lat_var.units = "degrees_north"
        lat_var.long_name = "Latitude"
        lat_var.standard_name = "latitude"
        lat_var.bounds = "lat_bnds"
        
        # 纬度边界
        nc.createDimension('latv', 2)
        lat_bnds_var = nc.createVariable('lat_bnds', 'f4', ('latv', 'lat'))
        lat_bnds = np.zeros((2, 1800), dtype=np.float32)
        lat_bnds[0, :] = lats - 0.05
        lat_bnds[1, :] = lats + 0.05
        lat_bnds_var[:] = lat_bnds
        
        # 降水变量
        fill_value = np.float32(-9999.9)
        precip_var = nc.createVariable('precipitation', 'f4', ('time', 'lat', 'lon'),
                                      fill_value=fill_value, zlib=True)
        precip_var[0, :, :] = accum_precip
        precip_var.units = "mm"
        precip_var.long_name = "Daily accumulated precipitation"
        precip_var.missing_value = fill_value
        precip_var.coordinates = "time lat lon"
    
    print(f"  Created: {out_file}")
    
    # 移动到下一天
    current_date += timedelta(days=1)

print("Processing completed!")