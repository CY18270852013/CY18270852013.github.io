# -*- coding: utf-8 -*-
"""
Created on Sun Mar  9 23:06:34 2025

@author: Chen Yong
"""

import numpy as np
import matplotlib.pyplot as plt
import statistics as sta
from scipy.stats import trim_mean

year = [x for x in range(1951, 1997, 1)]
pre = [216, 251, 613, 680, 421, 412, 397, 299, 435, 420, 493, 365, 239, 561, \
       341, 633, 408, 148, 567, 399, 358, 171, 545, 363, 528, 384, 777, 569, \
       417, 241, 469, 250, 237, 465, 421, 437, 362, 513, 236, 337, 350, 253, \
       417, 564, 484, 328]
ari = sum(pre) / len(pre)  #求算术平均值
print('算术平均数是：', ari)
var = sum((x -ari)**2 for x in pre) / len(pre)  #求方差
print('方差是：', var)

#将每年的降水量标准化
pre_standard = [0] * 46
for i in range(len(pre_standard)):
    pre_standard[i] = (pre[i] - ari) / var**0.5
print('标准化后的降水数据为：', pre_standard)

g1 = sum(((x - ari) / var**0.5) ** 3 for x in pre) / len(pre)  #求偏度系数
print('偏度系数是：', g1)
g2 = sum(((x - ari) / var**0.5) ** 4 for x in pre) / len(pre) -3  #求峰度系数
print('峰度系数是：', g2)

median = sta.median(pre)
print('中位数是：', median)
Q1 = np.percentile(pre, 25)
print('下四分位数是：', Q1)
Q3 = np.percentile(pre, 75)
print('上四分位数是：', Q3)
trimmed_mean = trim_mean(pre, proportiontocut = 0)
print('剪裁平均数是：', trimmed_mean)
print('内四分位范围是：', Q3 - Q1)
print('YK指数是：', (Q1 - 2 * ari + Q3) / (Q3 - Q1))

plt.figure(figsize = (12, 6))
plt.bar(year, pre, color = 'blue', alpha = 0.7)
plt.title('Histogram of precipitation from 1951 to 1996', fontsize = 16)
plt.xlabel('year', fontsize = 14)
plt.ylabel('precipitation(mm)', fontsize = 14)
plt.xticks(range(1951, 1997, 5), rotation = 45)
plt.grid(axis = 'y', linestyle = '--', alpha = 0.7)
plt.tight_layout()
plt.show()

