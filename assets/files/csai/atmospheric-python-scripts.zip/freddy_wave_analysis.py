import numpy as np
import xarray as xr
import cartopy.crs as ccrs
import matplotlib.pyplot as plt
import pandas as pd

# ====================
# 1. 智能数据预处理函数
# ====================
def smart_preprocess(ds):
    """
    智能坐标标准化函数
    功能：自动识别常见坐标命名并统一为标准名称
    """
    # 定义标准坐标名称映射
    coord_map = {
        'latitude': ['lat', 'latitude', 'lats'],
        'longitude': ['lon', 'longitude', 'lons'],
        'time': ['time', 'valid_time', 'date_time']
    }
    
    # 自动识别并重命名坐标
    for standard_name, variants in coord_map.items():
        # 检查是否存在需要重命名的坐标
        existing_vars = [var for var in variants if var in ds.coords]
        if existing_vars:
            # 优先使用更常见的名称
            original_name = existing_vars[0]
            if original_name != standard_name:
                ds = ds.rename({original_name: standard_name})
    
    # 确保经度范围统一（-180~180 或 0~360）
    if 'longitude' in ds.coords:
        if ds.longitude.max() > 180:
            ds = ds.assign_coords(longitude=(ds.longitude + 180) % 360 - 180)
            ds = ds.sortby('longitude')
    
    return ds

# ====================
# 2. 数据读取与预处理
# ====================
# 读取TC数据（应用智能预处理）
ibtracs = xr.open_dataset(r"D:\Freddy_ChenYong\Data\IBTrACS.SI.v04r01.nc")
ibtracs = smart_preprocess(ibtracs)
freddy = ibtracs.where(ibtracs.sid == b'2023036S12117', drop=True)

# 读取ERA5小时数据（自动处理valid_time问题）
era5 = xr.open_dataset(
    r"D:\Freddy_ChenYong\Data\ERA5_Initial_phase_environmental_field_hourly.nc",
    decode_times=True  # 确保时间解析
)
era5 = smart_preprocess(era5)
u850 = era5['u'].sel(pressure_level=850, method='nearest')
v850 = era5['v'].sel(pressure_level=850, method='nearest')

# 读取GPM数据（处理高分辨率数据）
gpm_files = [
    f"D:\Freddy_ChenYong\Data\GPM_3IMERGDF_07-20230201_20230331/3B-DAY.MS.MRG.3IMERG.{d.strftime('%Y%m%d')}-S000000-E235959.V07B.nc4" 
    for d in pd.date_range("2023-02-01", "2023-03-31")
]
gpm = xr.open_mfdataset(gpm_files, combine='by_coords', preprocess=smart_preprocess)
gpm = gpm.rename({'precipitation': 'prcp'})  # 简化变量名

# ====================
# 3. 改进的TC信号移除函数
# ====================
def safe_tc_remove(var_anom, tc_data, radius=1000):
    """
    安全版TC信号移除函数
    功能：处理维度对齐问题，增强异常值处理
    """
    # 输入验证
    required_dims = ['time', 'latitude', 'longitude']
    if not all(dim in var_anom.dims for dim in required_dims):
        missing = [dim for dim in required_dims if dim not in var_anom.dims]
        raise ValueError(f"缺失必要维度: {missing}")

    # 创建目标网格
    lon = var_anom.longitude.values
    lat = var_anom.latitude.values
    glon, glat = np.meshgrid(lon, lat)

    # 初始化权重场
    weights = xr.ones_like(var_anom)

    # 遍历TC路径
    for t in range(len(tc_data.time)):
        # 获取TC时空信息
        tc_time = tc_data.time[t].values
        tc_lon = tc_data.longitude[t].values
        tc_lat = tc_data.latitude[t].values

        # 计算距离场（地理空间距离）
        dx = (glon - tc_lon) * np.cos(np.deg2rad(glat)) * 111  # 经度方向距离(km)
        dy = (glat - tc_lat) * 111  # 纬度方向距离(km)
        dist_km = np.sqrt(dx**2 + dy**2)

        # 创建高斯权重场
        bell = np.exp(-(dist_km**2)/(2*(radius**2)))

        # 查找最近时间索引
        time_diff = np.abs(var_anom.time - tc_time)
        if time_diff.min() > np.timedelta64(6, 'h'):  # 时间差超过6小时则跳过
            continue
        time_idx = time_diff.argmin()

        # 应用权重
        weights[time_idx] = weights[time_idx] * (1 - bell)

    return var_anom * weights

# ====================
# 4. 数据对齐与异常计算
# ====================
# 统一时间频率（ERA5小时数据 -> 日数据）
era5_daily = era5.resample(time='1D').mean()

# 将GPM数据插值到ERA5网格（解决分辨率差异）
gpm_regrid = gpm['prcp'].interp(
    longitude=era5_daily.longitude,
    latitude=era5_daily.latitude,
    method='nearest'
)

# 计算气候态异常（处理时间对齐）
gpm_clim = gpm_regrid.groupby('time.dayofyear').mean(dim='time', skipna=False)
gpm_anom = gpm_regrid.groupby('time.dayofyear') - gpm_clim

# ====================
# 5. 执行TC信号移除
# ====================
# 创建公共时间轴（2023-02-01至2023-03-31）
common_time = xr.DataArray(
    pd.date_range("2023-02-01", "2023-03-31"),
    dims=['time'],
    name='time'
)

# 对齐所有数据集时间维度
gpm_anom = gpm_anom.sel(time=common_time, method='nearest')
u850 = u850.sel(time=common_time, method='nearest')
v850 = v850.sel(time=common_time, method='nearest')

# 执行信号移除
print("正在移除TC信号...")
gpm_clean = safe_tc_remove(gpm_anom, freddy, radius=500)
u850_clean = safe_tc_remove(u850, freddy, radius=1000)
v850_clean = safe_tc_remove(v850, freddy, radius=1000)

# ====================
# 6. 可视化与输出
# ====================
def plot_wave_analysis(data_dict, output_path):
    """
    增强版可视化函数
    参数：
        data_dict: 包含多个数据集的字典
        output_path: 输出文件路径
    """
    plt.figure(figsize=(18, 12))
    
    # 创建子图布局
    plot_config = {
        'mjo': {'pos': 1, 'title': 'MJO滤波异常场'},
        'ccerw': {'pos': 2, 'title': '赤道Rossby波异常场'},
        'mrg': {'pos': 3, 'title': '混合Rossby重力波异常场'}
    }
    
    for wave_type, config in plot_config.items():
        ax = plt.subplot(3, 1, config['pos'], projection=ccrs.PlateCarree())
        
        # 设置地图范围
        ax.set_extent([30, 100, -40, 0], crs=ccrs.PlateCarree())
        
        # 绘制降水异常
        data_dict[wave_type]['prcp'].mean(dim='time').plot(
            ax=ax,
            x='longitude', y='latitude',
            cmap='RdBu_r', vmin=-15, vmax=15,
            transform=ccrs.PlateCarree(),
            add_colorbar=False
        )
        
        # 绘制风场箭头
        stride = 6
        q = ax.quiver(
            data_dict[wave_type]['u'].longitude[::stride],
            data_dict[wave_type]['u'].latitude[::stride],
            data_dict[wave_type]['u'].mean(dim='time')[::stride,::stride],
            data_dict[wave_type]['v'].mean(dim='time')[::stride,::stride],
            scale=250,
            color='k',
            transform=ccrs.PlateCarree()
        )
        
        ax.coastlines()
        ax.set_title(config['title'], fontsize=12)
        
        # 添加色标
        if wave_type == 'mjo':
            cbar = plt.colorbar(ax.collections[0], ax=ax, orientation='horizontal', pad=0.05)
            cbar.set_label('降水异常 (mm/day)', fontsize=10)
        
        # 添加矢量比例尺
        plt.quiverkey(q, 0.85, 0.15, 5, '5 m/s', labelpos='E', fontproperties={'size': 10})
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    print(f"结果已保存至：{output_path}")

# 执行绘图（示例配置）
plot_data = {
    'mjo': {'prcp': gpm_clean, 'u': u850_clean, 'v': v850_clean},
    # 注：需要补充其他波动类型的滤波结果
}
plot_wave_analysis(plot_data, 'Freddy_Wave_Analysis.png')