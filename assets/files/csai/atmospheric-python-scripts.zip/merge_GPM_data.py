import xarray as xr
import os
import glob
import numpy as np
import pandas as pd
from natsort import natsorted
from dask.diagnostics import ProgressBar
import dask.array as da
import time
import logging

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger()

# 设置输入和输出路径
input_dir = r"E:\GPM"
output_dir = r"D:\Freddy_ChenYong\Codes_Matlab\New_codes"
output_file = os.path.join(output_dir, "GPM_20230101_20230331_every30min_full_latitude_and_longitude_merged.nc4")

# 获取所有HDF5文件
files_pattern = os.path.join(input_dir, "*.HDF5")
files = glob.glob(files_pattern)

# 使用自然排序确保时间顺序正确
files = natsorted(files)

# 打印文件列表验证
logger.info(f"找到 {len(files)} 个文件准备合并")
if len(files) > 0:
    logger.info(f"第一个文件: {os.path.basename(files[0])}")
    logger.info(f"最后一个文件: {os.path.basename(files[-1])}")

# 检查文件数量
expected_count = 90 * 48  # 90天 * 48个半小时文件
if len(files) != expected_count:
    logger.warning(f"文件数量不匹配! 找到 {len(files)} 个文件，预期 {expected_count} 个文件")
    if not files:
        raise FileNotFoundError("未找到任何文件，请检查路径: " + input_dir)
else:
    logger.info(f"文件数量正确: {len(files)}/{expected_count}")

# 定义要处理的变量
variables = [
    'precipitation',
    'randomError',
    'probabilityLiquidPrecipitation',
    'precipitationQualityIndex',
    'MWprecipitation',
    'MWprecipSource',
    'MWobservationTime',
    'IRprecipitation',
    'IRinfluence',
    'precipitationUncal'
]

# 定义单位映射
units_map = {
    'precipitation': 'mm/hr',
    'randomError': 'mm/hr',
    'probabilityLiquidPrecipitation': 'percent',
    'precipitationQualityIndex': 'dimensionless',
    'MWprecipitation': 'mm/hr',
    'MWprecipSource': 'categorical',
    'MWobservationTime': 'minutes',
    'IRprecipitation': 'mm/hr',
    'IRinfluence': 'dimensionless',
    'precipitationUncal': 'mm/hr'
}

# 定义全局属性
global_attrs = {
    "title": "GPM IMERG Final Precipitation L3 Half-Hourly 0.1 degree x 0.1 degree",
    "institution": "NASA Goddard Space Flight Center",
    "source": "GPM IMERG Version 07A",
    "history": f"Merged on {time.strftime('%Y-%m-%d %H:%M:%S')} using xarray",
    "Conventions": "CF-1.8",
    "time_coverage_start": "2023-01-01T00:00:00Z",
    "time_coverage_end": "2023-03-31T23:59:59Z",
    "geospatial_lat_min": -90.0,
    "geospatial_lat_max": 90.0,
    "geospatial_lon_min": -180.0,
    "geospatial_lon_max": 180.0
}

# 定义编码参数 (注意: _FillValue 在这里设置而不是在属性中)
encoding = {
    'precipitation': {'zlib': True, 'complevel': 5, 'dtype': 'float32', '_FillValue': -9999.9},
    'randomError': {'zlib': True, 'complevel': 5, 'dtype': 'float32', '_FillValue': -9999.9},
    'probabilityLiquidPrecipitation': {'zlib': True, 'complevel': 5, 'dtype': 'int16', '_FillValue': -9999},
    'precipitationQualityIndex': {'zlib': True, 'complevel': 5, 'dtype': 'float32', '_FillValue': -9999.9},
    'MWprecipitation': {'zlib': True, 'complevel': 5, 'dtype': 'float32', '_FillValue': -9999.9},
    'MWprecipSource': {'zlib': True, 'complevel': 5, 'dtype': 'int16', '_FillValue': -9999},
    'MWobservationTime': {'zlib': True, 'complevel': 5, 'dtype': 'int16', '_FillValue': -9999},
    'IRprecipitation': {'zlib': True, 'complevel': 5, 'dtype': 'float32', '_FillValue': -9999.9},
    'IRinfluence': {'zlib': True, 'complevel': 5, 'dtype': 'int16', '_FillValue': -9999},
    'precipitationUncal': {'zlib': True, 'complevel': 5, 'dtype': 'float32', '_FillValue': -9999.9}
}

# 创建时间维度 (2023-01-01 00:00 到 2023-03-31 23:30，每半小时)
start_time = pd.Timestamp("2023-01-01 00:00:00")
end_time = pd.Timestamp("2023-03-31 23:30:00")
time_index = pd.date_range(start=start_time, end=end_time, freq="30min")

# 创建空间网格
lat = np.arange(-89.95, 90.05, 0.1)[:1800]  # 确保正好1800个点
lon = np.arange(-179.95, 180.05, 0.1)[:3600]  # 确保正好3600个点

# 创建空的Dataset模板
ds_template = xr.Dataset(
    coords={
        'time': time_index,
        'lat': lat,
        'lon': lon
    },
    attrs=global_attrs
)

# 添加空数据数组（使用Dask分块）
chunks = {'time': 100, 'lat': 900, 'lon': 1800}  # 分块大小

for var in variables:
    # 根据变量类型确定数据类型
    dtype = encoding[var].get('dtype', 'float32')
    
    # 创建Dask数组
    shape = (len(time_index), len(lat), len(lon))
    data = da.zeros(shape, dtype=dtype, chunks=chunks)
    
    # 添加到Dataset
    ds_template[var] = (('time', 'lat', 'lon'), data)
    
    # 添加属性 (注意: 不再添加 _FillValue 属性)
    ds_template[var].attrs = {
        'long_name': var,
        'units': units_map.get(var, '')
    }

# 保存模板到文件（空文件）
logger.info("创建输出文件模板...")
ds_template.to_netcdf(
    output_file,
    format='NETCDF4',
    engine='netcdf4',
    encoding={var: encoding[var] for var in variables}
)
logger.info(f"输出文件模板已创建: {output_file}")

# 逐个文件处理并写入
logger.info("开始处理并写入数据...")
start_time = time.time()

# 创建进度条
with ProgressBar():
    for i, file in enumerate(files):
        # 每100个文件记录一次进度
        if i % 100 == 0:
            elapsed = time.time() - start_time
            processed_files = max(1, i)  # 避免除以零
            time_per_file = elapsed / processed_files
            remaining_files = len(files) - i
            remaining_time = time_per_file * remaining_files
            logger.info(f"处理进度: {i}/{len(files)} - "
                       f"耗时: {elapsed/60:.1f} min - "
                       f"预计剩余: {remaining_time/60:.1f} min")
        
        try:
            # 从文件名解析时间
            filename = os.path.basename(file)
            parts = filename.split('.')
            date_str = parts[4]
            time_range = parts[5]
            
            # 提取起始时间 (S后面的6位数字)
            start_time_str = time_range.split('-')[1][1:7]  # 格式为 HHMMSS
            
            # 转换为时间索引
            file_time = pd.Timestamp(
                f"{date_str[:4]}-{date_str[4:6]}-{date_str[6:8]} "
                f"{start_time_str[:2]}:{start_time_str[2:4]}:{start_time_str[4:6]}"
            )
            
            # 找到时间索引位置
            time_idx = np.where(time_index == file_time)[0]
            if len(time_idx) == 0:
                logger.warning(f"时间点 {file_time} 不在时间索引中，跳过文件: {filename}")
                continue
            time_idx = time_idx[0]
            
            # 打开HDF5文件
            with xr.open_dataset(file, group='Grid', engine='h5netcdf') as ds:
                # 读取所有变量
                for var in variables:
                    if var in ds:
                        # 获取数据 (lat, lon) 顺序
                        data = ds[var].values
                        
                        # 处理不同的维度顺序
                        if data.ndim == 3:
                            if data.shape == (1, 1800, 3600):  # (time, lat, lon)
                                data = data[0, :, :]
                            elif data.shape == (1800, 3600, 1):  # (lat, lon, time)
                                data = data[:, :, 0]
                            elif data.shape == (3600, 1800, 1):  # (lon, lat, time)
                                data = data[:, :, 0].T  # 转置为 (lat, lon)
                        
                        # 打开输出文件并写入数据
                        with xr.open_dataset(output_file, mode='a') as out_ds:
                            # 确保维度顺序正确
                            if out_ds[var].dims == ('time', 'lat', 'lon'):
                                out_ds[var][time_idx, :, :] = data
                            elif out_ds[var].dims == ('lat', 'lon', 'time'):
                                out_ds[var][:, :, time_idx] = data
                            else:
                                # 如果维度不匹配，尝试自动匹配
                                logger.warning(f"变量 {var} 维度不匹配: {out_ds[var].dims}")
                                out_ds[var][time_idx] = data
                            
                            # 强制写入到磁盘
                            out_ds[var].encoding = {}
            
        except Exception as e:
            logger.error(f"处理文件 {filename} 时出错: {str(e)}")
            # 跳过问题文件继续处理
            continue

# 计算总耗时
total_time = time.time() - start_time
logger.info(f"数据处理完成! 总耗时: {total_time/60:.1f} 分钟")

# 添加最终历史记录
with xr.open_dataset(output_file, mode='a') as final_ds:
    history = f"Completed merging {len(files)} files at {time.strftime('%Y-%m-%d %H:%M:%S')}"
    if 'history' in final_ds.attrs:
        final_ds.attrs['history'] += f"\n{history}"
    else:
        final_ds.attrs['history'] = history

logger.info("\n" + "="*70)
logger.info(f"成功合并 {len(files)} 个文件!")
logger.info(f"输出文件: {output_file}")
try:
    file_size = os.path.getsize(output_file) / (1024 ** 3)  # GB
    logger.info(f"文件大小: {file_size:.2f} GB")
except:
    logger.info("文件大小: 未知")
logger.info("="*70)