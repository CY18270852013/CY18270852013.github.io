# -*- coding: utf-8 -*-
"""
Created on Tue Mar 11 19:07:48 2025

@author: Dell
"""

import h5py
import numpy as np
import matplotlib.pyplot as plt
import os
from datetime import datetime, timedelta, timezone
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import xarray as xr
import warnings
from cartopy.io import DownloadWarning

# 禁用cartopy的下载警告
warnings.filterwarnings("ignore", category=DownloadWarning)

# 文件路径和保存路径
mat_file_path = r"D:\MATLAB\Freddy\w_mjo.mat"  # 垂直速度数据路径
ibtracs_file_path = 'D:/MATLAB/Freddy/IBTrACS.SI.v04r01.nc'  # 热带气旋数据路径
output_dir = r"C:\Users\Dell\Desktop\w_mjo_500hPa_with_track"  # 输出目录

# 确保输出目录存在
os.makedirs(output_dir, exist_ok=True)

# 目标范围
start_date = datetime(2023, 2, 1)
end_date = datetime(2023, 3, 31)
dates = [start_date + timedelta(days=i) for i in range((end_date - start_date).days + 1)]

# 垂直速度数据的参数
pressure_index = 13  # 对应 500 hPa
latitudes = np.linspace(0, -40, 81)  # 纬度范围：0° 到 -40°
longitudes = np.linspace(0, 180, 360)  # 经度范围：0° 到 180°
lon_mask = (longitudes >= 25) & (longitudes <= 130)  # 经度掩膜
lat_mask = (latitudes <= 0) & (latitudes >= -40)  # 纬度掩膜

# 筛选目标范围的数据
lat_indices = np.where(lat_mask)[0]
lon_indices = np.where(lon_mask)[0]

# 加载热带气旋数据
data = xr.open_dataset(ibtracs_file_path)

# 找到FREDDY热带气旋的数据
freddy_sid = b'2023036S12117'  # FREDDY的sid
freddy_data = data.sel(storm=(data['sid'] == freddy_sid))

# 检查是否找到FREDDY的数据
if freddy_data.sizes['storm'] == 0:
    raise ValueError(f"未找到sid为 {freddy_sid} 的热带气旋数据。")

# 获取FREDDY的时间和经纬度数据
times = freddy_data['time'].values
lats = freddy_data['lat'].values
lons = freddy_data['lon'].values

# 过滤掉无效的时间和数据
valid_indices = ~np.isnat(times) & ~np.isnan(lats) & ~np.isnan(lons)
times = times[valid_indices]
lats = lats[valid_indices]
lons = lons[valid_indices]

# 将时间转换为datetime对象
times = [datetime.fromtimestamp(t.astype('O')/1e9, tz=timezone.utc) for t in times]

# 绘图参数
levels = np.linspace(-5, 5, 21)  # 色阶范围
cmap = "coolwarm"  # 色彩映射

# 单位转换参数
rho = 0.736  # 空气密度 (kg/m^3) 在 500 hPa
g = 9.81     # 重力加速度 (m/s^2)

# 按日期循环处理
for i, date in enumerate(dates):
    # 计算当前日期在数据中的索引
    day_index = (date - datetime(2001, 1, 1)).days
    
    # 从 .mat 文件中按需加载当前日期的数据
    with h5py.File(mat_file_path, 'r') as f:
        w_data = f['w_mjo'][day_index, pressure_index, :, :]  # 只加载当前日期的数据
        w_data = np.array(w_data)  # 转换为 numpy 数组
    
    # 单位转换：Pa/s -> 10^-2 m/s
    w_data = -w_data / (rho * g) * 100  # 转换为 10^-2 m/s
    
    # 筛选目标范围的数据
    w_data = w_data[lat_indices[:, None], lon_indices]
    
    # 创建地图
    plt.figure(figsize=(12, 8))
    ax = plt.axes(projection=ccrs.PlateCarree())
    
    # 绘制垂直速度填色图
    contour = ax.contourf(
        longitudes[lon_indices],
        latitudes[lat_indices],
        w_data,
        levels=levels,
        cmap=cmap,
        extend="both",
        transform=ccrs.PlateCarree(),  # 数据的投影
        vmin=-5,  # 固定最小值
        vmax=5    # 固定最大值
    )
    
    # 添加海陆线、国界线
    ax.coastlines(resolution='50m', linewidth=1)
    ax.add_feature(cfeature.BORDERS, linewidth=0.8)
    ax.add_feature(cfeature.LAND, facecolor='lightgray', edgecolor='black', alpha=0.5)
    ax.add_feature(cfeature.LAKES, facecolor='lightblue', edgecolor='black', alpha=0.5)

    # 添加网格和坐标轴标签
    ax.gridlines(draw_labels=True, linewidth=0.5, linestyle='--', alpha=0.7)
    plt.colorbar(contour, ax=ax, orientation='vertical', label="Vertical Velocity (10^-2 m/s)")
    
    # 标题
    plt.title(f"500 hPa Vertical Velocity with Tropical Cyclone FREDDY Path\n{date.strftime('%Y-%m-%d')}", fontsize=14)
    
    # 如果日期在2.4~3.14之间，叠加热带气旋路径
    if date >= datetime(2023, 2, 4) and date <= datetime(2023, 3, 14):
        # 找到当前日期对应的路径点
        path_indices = [j for j, t in enumerate(times) if t.date() == date.date()]
        if path_indices:
            # 绘制路径
            ax.plot(lons[:path_indices[0]+1], lats[:path_indices[0]+1], color='red', marker='o', markersize=4, transform=ccrs.PlateCarree())
    
    # 保存图像
    output_path = os.path.join(output_dir, f"w_500hPa_with_track_{i:02d}.png")
    plt.savefig(output_path, dpi=400, bbox_inches="tight")  # 提高清晰度
    plt.close()

print(f"完成绘图并保存到：{output_dir}")