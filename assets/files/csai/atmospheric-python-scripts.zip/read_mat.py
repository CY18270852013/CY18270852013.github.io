import h5py

# 文件路径
path = r"D:\MATLAB\Freddy\q_mjo.mat"

# 使用h5py打开MATLAB v7.3格式的.mat文件
with h5py.File(path, 'r') as file:
    # 列出.mat文件中的所有变量（顶层键）
    print("MATLAB文件中包含的变量:")
    print(list(file.keys()))