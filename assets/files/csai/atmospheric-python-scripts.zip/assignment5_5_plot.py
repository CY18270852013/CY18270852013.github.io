# -*- coding: utf-8 -*-
"""
Created on Wed Nov 20 21:44:21 2024

@author: Chen Yong
"""

import numpy as np
import matplotlib.pyplot as plt

# 读取误差数据
direct_data = np.loadtxt(r"D:\Users\Chen Yong\AppData\Local\Programs\Microsoft VS Code\Calculation_Mathod_Fortran_codes\direct_method_errors_with_pivoting.dat")

# 提取矩阵阶数和误差
n_direct, error_direct = direct_data[:, 0], direct_data[:, 1]

# 绘制相对误差曲线
plt.figure(figsize=(10, 6))
plt.plot(n_direct, error_direct, label="Direct Method with Pivoting", marker='o', linestyle='-', color='blue')

# 添加标题和标签
plt.title("Relative Error vs Matrix Size (With Pivoting)", fontsize=16)
plt.xlabel("Matrix Size (n)", fontsize=14)
plt.ylabel("Relative Error", fontsize=14)
plt.legend(fontsize=12)
plt.grid(True)

# 显示图形
plt.tight_layout()
plt.show()
