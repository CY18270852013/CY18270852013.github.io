import xarray as xr
import numpy as np
import os
from tqdm import tqdm
import warnings
from datetime import datetime
import logging
import dask
from dask.diagnostics import ProgressBar
from multiprocessing import freeze_support

# 配置简洁日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("vimd_calculation.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger()

# 忽略警告
warnings.filterwarnings('ignore')
dask.config.set(**{'array.slicing.split_large_chunks': True})

# 常量定义
RADIUS_EARTH = 6371000.0  # 地球半径 (m)
GRAVITY = 9.80665         # 重力加速度 (m/s²)
DEG2RAD = np.pi / 180.0   # 度转弧度系数

# 路径设置
input_dir = "E:/ERA5_dv_q_uv_200901_202312_every_6hours"
output_dir = "E:/VIMD_200901_202312_every_6hours_2"
os.makedirs(output_dir, exist_ok=True)

def calculate_vimd_for_month(year_month):
    """计算单个月份的VIMD并保存到文件"""
    year, month = year_month
    yyyymm = f"{year}{month:02d}"
    logger.info(f"Starting processing for {yyyymm}")
    
    try:
        start_time = datetime.now()
        
        # 1. 加载数据
        uv_file = os.path.join(input_dir, f"{yyyymm}_uv.nc")
        q_file = os.path.join(input_dir, f"{yyyymm}_q.nc")
        
        logger.info(f"Loading files: {uv_file} and {q_file}")
        
        # 使用优化的chunk大小
        chunks = {'valid_time': 20, 'pressure_level': 10, 'latitude': 40, 'longitude': 360}
        
        # 使用float32减少内存占用
        ds_uv = xr.open_dataset(uv_file, chunks=chunks, dtype='float32')
        ds_q = xr.open_dataset(q_file, chunks=chunks, dtype='float32')
        
        # 记录数据基本信息
        logger.info(f"Data loaded - UV shape: {ds_uv['u'].shape}, Q shape: {ds_q['q'].shape}")
        
        # 2. 提取变量并确保维度顺序一致
        u = ds_uv['u'].transpose('valid_time', 'pressure_level', 'latitude', 'longitude')
        v = ds_uv['v'].transpose('valid_time', 'pressure_level', 'latitude', 'longitude')
        q = ds_q['q'].transpose('valid_time', 'pressure_level', 'latitude', 'longitude')
        
        # 3. 计算水汽通量
        logger.info("Calculating moisture fluxes")
        qu = q * u
        qv = q * v
        
        # 4. 计算水汽通量散度
        logger.info("Calculating moisture flux divergence")
        
        # 获取经度和纬度间隔（度）
        dlon_deg = float(np.diff(u.longitude).mean())
        dlat_deg = float(np.diff(u.latitude).mean())
        
        # 创建用于距离计算的网格
        lon_rad = np.deg2rad(u.longitude)
        lat_rad = np.deg2rad(u.latitude)
        
        # 计算每个点的东西方向距离（考虑纬度）
        dx_values = RADIUS_EARTH * np.cos(lat_rad) * np.deg2rad(dlon_deg)
        
        # 计算每个点的南北方向距离
        dy_values = RADIUS_EARTH * np.deg2rad(dlat_deg)
        
        # 创建与qu、qv维度完全一致的dx和dy数组
        # 创建二维数组（latitude, longitude）
        dx = xr.DataArray(
            dx_values.values[:, np.newaxis] * np.ones((len(u.latitude), len(u.longitude))),
            dims=['latitude', 'longitude'],
            coords={'latitude': u.latitude, 'longitude': u.longitude}
        )
        
        dy = xr.DataArray(
            dy_values * np.ones((len(u.latitude), len(u.longitude))),
            dims=['latitude', 'longitude'],
            coords={'latitude': u.latitude, 'longitude': u.longitude}
        )
        
        # 广播到完整维度
        dx = dx.broadcast_like(qu)
        dy = dy.broadcast_like(qu)
        
        # 确保dx和dy有正确的坐标
        dx = dx.assign_coords({
            'valid_time': u.valid_time,
            'pressure_level': u.pressure_level
        })
        
        dy = dy.assign_coords({
            'valid_time': u.valid_time,
            'pressure_level': u.pressure_level
        })
        
        # 计算经度方向导数 (考虑周期性边界)
        logger.info("Calculating longitude derivative")
        
        # 使用手动差分方法
        qu_roll_west = qu.roll(longitude=1, roll_coords=False)
        qu_roll_east = qu.roll(longitude=-1, roll_coords=False)
        dqu_dx = (qu_roll_east - qu_roll_west) / (2 * dx)
        
        # 计算纬度方向导数
        logger.info("Calculating latitude derivative")
        
        # 使用手动差分方法
        qv_roll_north = qv.roll(latitude=1, roll_coords=False)
        qv_roll_south = qv.roll(latitude=-1, roll_coords=False)
        dqv_dy = (qv_roll_north - qv_roll_south) / (2 * dy)
        
        # 总散度
        div = dqu_dx + dqv_dy
        
        # 5. 垂直积分
        logger.info("Performing vertical integration")
        
        # 准备气压数据 (转换为Pa)
        pressure_pa = ds_uv.pressure_level * 100.0  # hPa -> Pa
        
        # 修正气压差计算 - 考虑气压层递减顺序
        # 气压层是从高到低（1000hPa到50hPa），所以差值为正
        # 使用梯形法计算dp
        dp = xr.zeros_like(pressure_pa)
        # 首层：当前层到下一层的距离
        dp[0] = pressure_pa[0] - pressure_pa[1]
        # 中间层：上下层差的平均值
        for i in range(1, len(pressure_pa)-1):
            dp[i] = (pressure_pa[i-1] - pressure_pa[i+1]) / 2.0
        # 最后一层：上一层到当前层的距离
        dp[-1] = pressure_pa[-2] - pressure_pa[-1]
        
        # 确保dp为正值（气压递减）
        dp = xr.where(dp > 0, dp, -dp)
        
        # 扩展dp以匹配div的维度
        dp_expanded = dp.broadcast_like(div)
        
        # 垂直积分 (梯形法)
        div_weighted = div * dp_expanded
        integral = div_weighted.sum(dim='pressure_level')
        
        # 计算VIMD
        vimd = -integral / GRAVITY
        
        # 6. 创建输出数据集
        logger.info("Creating output dataset")
        ds_out = xr.Dataset({
            'vimd': vimd.rename('Vertically Integrated Moisture Divergence')
        })
        
        # 添加元数据
        ds_out['vimd'].attrs = {
            'long_name': 'Vertically Integrated Moisture Divergence',
            'units': 'kg m^{-2} s^{-1}',
            'description': 'Negative values indicate moisture convergence',
            'calculation_method': 'Calculated from q, u, v using centered differences',
            'vertical_integration': 'Trapezoidal method from surface to top',
            'gravity_constant': f'{GRAVITY} m/s²',
            'earth_radius': f'{RADIUS_EARTH} m'
        }
        
        # 添加全局属性
        ds_out.attrs = {
            'title': 'Vertically Integrated Moisture Divergence (VIMD)',
            'institution': 'Calculated from ERA5 data',
            'source': f'ERA5 u, v, q data for {yyyymm}',
            'history': f'Created on {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}',
            'conventions': 'CF-1.7',
            'time_resolution': '6-hourly',
            'spatial_resolution': '0.5°x0.5°',
            'latitude_range': f'{u.latitude.min().values} to {u.latitude.max().values}',
            'longitude_range': f'{u.longitude.min().values} to {u.longitude.max().values}'
        }
        
        # 7. 保存结果
        output_file = os.path.join(output_dir, f"{yyyymm}_VIMD.nc")
        logger.info(f"Saving results to {output_file}")
        
        encoding = {'vimd': {'zlib': True, 'complevel': 5}}
        
        # 使用Dask并行计算
        with ProgressBar():
            ds_out.to_netcdf(output_file, encoding=encoding)
        
        # 关闭输入文件
        ds_uv.close()
        ds_q.close()
        
        # 记录处理时间
        proc_time = datetime.now() - start_time
        logger.info(f"Successfully processed {yyyymm} in {proc_time}")
        
        return True
        
    except Exception as e:
        logger.error(f"Error processing {yyyymm}: {str(e)}")
        return False

if __name__ == '__main__':
    freeze_support()  # Windows下多进程处理必需的调用
    
    # 生成需要处理的所有年月
    start_year, end_year = 2014, 2023
    months_to_process = [
        (year, month) 
        for year in range(start_year, end_year + 1) 
        for month in range(1, 13)
    ]
    
    # 记录开始信息
    logger.info(f"Starting VIMD calculation for {start_year}01 to {end_year}12")
    logger.info(f"Total months to process: {len(months_to_process)}")
    logger.info(f"Input directory: {input_dir}")
    logger.info(f"Output directory: {output_dir}")
    
    # 处理所有月份
    success_count = 0
    failure_count = 0
    start_time = datetime.now()
    
    # 使用顺序处理
    for ym in tqdm(months_to_process, desc="Processing months"):
        if calculate_vimd_for_month(ym):
            success_count += 1
        else:
            failure_count += 1
    
    # 输出统计信息
    total_time = datetime.now() - start_time
    logger.info(f"Processing completed: {success_count} succeeded, {failure_count} failed")
    logger.info(f"Total processing time: {total_time}")
    logger.info(f"Success rate: {success_count/len(months_to_process)*100:.2f}%")
    logger.info(f"Output directory: {output_dir}")
    
    # 打印最终摘要
    print("\n" + "="*80)
    print(f"VIMD CALCULATION SUMMARY")
    print(f"Total months processed: {len(months_to_process)}")
    print(f"Successfully processed: {success_count}")
    print(f"Failed: {failure_count}")
    print(f"Total time: {total_time}")
    print(f"Output directory: {output_dir}")
    print("="*80)