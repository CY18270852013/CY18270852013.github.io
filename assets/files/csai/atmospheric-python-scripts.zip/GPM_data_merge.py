import xarray as xr
import os
import glob
from natsort import natsorted
from dask.diagnostics import ProgressBar
import datetime

# 设置输入和输出路径
input_dir = r"D:\Freddy_ChenYong\Codes_Matlab\New_codes\GPM_3IMERGDF_20230101_20230331"
output_dir = r"D:\Freddy_ChenYong\Codes_Matlab\New_codes"
output_file = os.path.join(output_dir, "GPM_20230101_20230331_merged.nc4")

# 获取所有nc4文件
files_pattern = os.path.join(input_dir, "*.nc4")
files = glob.glob(files_pattern)

# 使用自然排序确保日期顺序正确
files = natsorted(files)

# 打印文件列表验证
print(f"找到 {len(files)} 个文件准备合并:")
for i, file in enumerate(files[:5]):  # 只打印前5个文件示例
    print(f"{i+1}. {os.path.basename(file)}")
if len(files) > 5:
    print(f"... 以及 {len(files)-5} 个其他文件")
print("\n")

# 检查文件数量
expected_count = 90
if len(files) != expected_count:
    print(f"警告: 找到 {len(files)} 个文件，但预期 {expected_count} 个文件")
    if not files:
        raise FileNotFoundError("未找到任何文件，请检查路径: " + input_dir)

# 记录开始时间
start_time = datetime.datetime.now()
print(f"开始合并处理: {start_time.strftime('%Y-%m-%d %H:%M:%S')}")

try:
    # 打开并合并数据集 - 使用netcdf4引擎替代h5netcdf
    merged_data = xr.open_mfdataset(
        files,
        combine='by_coords',     # 按坐标自动对齐
        parallel=True,           # 启用并行处理
        chunks={'time': 10},     # 优化内存使用的分块大小
        engine='netcdf4',        # 使用更通用的netcdf4引擎
        data_vars='minimal',     # 仅合并必需的变量
        coords='minimal',
        compat='override'
    )
    
    # 添加合并历史信息
    history_attr = f"Merged {len(files)} files using xarray on {xr.__version__}"
    if 'history' in merged_data.attrs:
        merged_data.attrs['history'] += f"\n{history_attr}"
    else:
        merged_data.attrs['history'] = history_attr

    # 保存合并后的文件
    print(f"开始保存合并数据到: {output_file}")
    with ProgressBar():
        merged_data.to_netcdf(
            output_file,
            format='NETCDF4',       # 指定为NetCDF4格式
            engine='netcdf4',       # 使用netcdf4引擎
            encoding={
                'precipitation': {'zlib': True, 'complevel': 5},
                'randomError': {'zlib': True, 'complevel': 5}
            }
        )
    
    # 计算处理时间
    end_time = datetime.datetime.now()
    duration = (end_time - start_time).total_seconds()
    
    print("\n" + "="*70)
    print(f"成功合并 {len(files)} 个文件!")
    print(f"输出文件: {output_file}")
    print(f"文件大小: {os.path.getsize(output_file)/1024**2:.2f} MB")
    print(f"处理时间: {duration:.2f} 秒 ({duration/60:.2f} 分钟)")
    print("="*70)

except Exception as e:
    print(f"处理过程中发生错误: {str(e)}")
    # 提供更多错误信息
    if "NetCDF: HDF error" in str(e):
        print("\n建议: 尝试安装h5netcdf库: pip install h5netcdf")
    elif "unable to open file" in str(e):
        print("\n建议: 检查文件路径是否正确，文件是否损坏")
    else:
        print("\n建议: 检查xarray和netCDF4库是否安装正确")

finally:
    # 确保关闭数据集释放资源
    if 'merged_data' in locals():
        merged_data.close()