# -*- coding: utf-8 -*-
"""
Created on Sun Oct 13 23:02:14 2024

@author: Dell
"""

import os

# 定义文件夹路径
folder_path = r'C:\Users\Dell\Desktop\sea_surface_temperature'

# 获取文件夹下的所有文件名，并按文件名排序
files = sorted([f for f in os.listdir(folder_path) if f.startswith('sst_') and f.endswith('.png')])

# 遍历并重命名文件
for index, file in enumerate(files):
    old_path = os.path.join(folder_path, file)
    new_filename = f'{index}.png'
    new_path = os.path.join(folder_path, new_filename)
    
    os.rename(old_path, new_path)
    print(f'Renamed: {file} -> {new_filename}')

print("文件重命名完成！")
