import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from datetime import datetime, timedelta
import os
import warnings
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import Normalize
import matplotlib.cm as cm
from matplotlib import colors
warnings.filterwarnings('ignore')

# 配置参数
freddy_sid = b'2023036S12117'  # Freddy的SID
dates = [datetime(2023, 2, d, 12) for d in range(4, 11)]  # 2023-02-04到2023-02-10每天12UTC
genesis_box = {'lon_min': 110, 'lon_max': 120, 'lat_min': -20, 'lat_max': -10}  # Freddy genesis box
plot_extent = [100, 130, -25, -5]  # 绘图区域: [lon_min, lon_max, lat_min, lat_max]

# 创建输出目录
output_dir = r'D:\Freddy_ChenYong\Plot_ChenYong\Figure7_2'
os.makedirs(output_dir, exist_ok=True)
print(f"输出目录: {output_dir}")

# ========================= 1. 从IBTrACS获取Freddy位置 =========================
print("\n>>> 从IBTrACS获取Freddy位置...")
ibtr_path = r'D:\Freddy_ChenYong\Data\IBTrACS.SI.v04r01.nc'
ibtr_ds = xr.open_dataset(ibtr_path)

# 找到Freddy热带气旋
freddy_idx = np.where(ibtr_ds['sid'].values == freddy_sid)[0]
if len(freddy_idx) == 0:
    raise ValueError(f"未找到SID为 {freddy_sid} 的热带气旋数据")
freddy_idx = freddy_idx[0]

# 提取位置数据
times = ibtr_ds['time'].isel(storm=freddy_idx).values
lats = ibtr_ds['lat'].isel(storm=freddy_idx).values
lons = ibtr_ds['lon'].isel(storm=freddy_idx).values

# 转换为datetime对象并过滤有效数据
valid_mask = ~np.isnat(times) & ~np.isnan(lats) & ~np.isnan(lons)
times = times[valid_mask].astype('datetime64[s]').astype(datetime)
lats = lats[valid_mask]
lons = lons[valid_mask]

# 为每个目标日期找到最近的位置
freddy_positions = {}
for target_date in dates:
    time_diffs = np.abs([(t - target_date).total_seconds() for t in times])
    closest_idx = np.argmin(time_diffs)
    closest_time = times[closest_idx]
    time_diff_hr = time_diffs[closest_idx] / 3600
    
    if time_diff_hr > 3:  # 如果时间差大于3小时，使用插值
        print(f"警告: {target_date} 无精确位置 (最近: {closest_time}, 差 {time_diff_hr:.1f} 小时)")
        # 简单线性插值
        if closest_idx > 0 and closest_idx < len(times) - 1:
            prev_time = times[closest_idx-1]
            next_time = times[closest_idx+1]
            prev_diff = (target_date - prev_time).total_seconds()
            total_diff = (next_time - prev_time).total_seconds()
            ratio = prev_diff / total_diff
            
            lat_interp = lats[closest_idx-1] + ratio * (lats[closest_idx+1] - lats[closest_idx-1])
            lon_interp = lons[closest_idx-1] + ratio * (lons[closest_idx+1] - lons[closest_idx-1])
            freddy_positions[target_date] = (lon_interp, lat_interp)
        else:
            freddy_positions[target_date] = (lons[closest_idx], lats[closest_idx])
    else:
        freddy_positions[target_date] = (lons[closest_idx], lats[closest_idx])

# ========================= 2. 准备计算数据 =========================
print("\n>>> 准备计算数据...")

# 打开CCKW散度异常数据
cckw_path = r'E:\divergence_anomaly_6hourly\divergence_anomaly_for_Kelvin_6hourly_20230101_20230331.nc'
cckw_ds = xr.open_dataset(cckw_path)

# 检查并修正CCKW数据的纬度顺序
print("检查CCKW数据纬度顺序...")
if 'lat' in cckw_ds.coords:
    if cckw_ds.lat[0] > cckw_ds.lat[-1]:  # 如果纬度是从北向南排列
        print("CCKW纬度顺序为从北向南，将反转为从南向北")
        cckw_ds = cckw_ds.sortby('lat')  # 反转纬度顺序
    print(f"CCKW纬度范围: {cckw_ds.lat.values[0]} 到 {cckw_ds.lat.values[-1]}")
    
    # 选择850hPa数据
    if 'level' in cckw_ds.dims:
        cckw_ds = cckw_ds.sel(level=850, method='nearest')
        print("已选择850hPa的CCKW数据")
    else:
        print("警告: CCKW数据没有level维度，使用所有数据")

# 打开ERA5涡度数据
era5_files = [
    r'E:\ERA5_dv_q_uv_200901_202312_every_6hours\202301_dv.nc',
    r'E:\ERA5_dv_q_uv_200901_202312_every_6hours\202302_dv.nc',
    r'E:\ERA5_dv_q_uv_200901_202312_every_6hours\202303_dv.nc'
]
era5_ds = xr.open_mfdataset(era5_files, combine='by_coords')

# 检查并修正ERA5数据的纬度顺序
print("检查ERA5数据纬度顺序...")
if 'latitude' in era5_ds.coords:
    if era5_ds.latitude[0] > era5_ds.latitude[-1]:  # 如果纬度是从北向南排列
        print("ERA5纬度顺序为从北向南，将反转为从南向北")
        era5_ds = era5_ds.sortby('latitude')  # 反转纬度顺序
    print(f"ERA5纬度范围: {era5_ds.latitude.values[0]} 到 {era5_ds.latitude.values[-1]}")

era5_ds = era5_ds.sel(pressure_level=850)  # 选择850hPa

# 计算绝对涡度 (相对涡度 + 科氏参数)
omega = 7.292115e-5  # 地球自转角速度 (rad/s)
lats_rad = np.deg2rad(era5_ds.latitude)
f = 2 * omega * np.sin(lats_rad)
absolute_vorticity = era5_ds['vo'] + f

# ========================= 3. 计算涡旋拉伸项 =========================
print("\n>>> 计算涡旋拉伸项...")

# 存储有效的涡旋拉伸项数据
all_vortex_stretching = []
valid_dates = []

# 循环处理每个日期
for target_date in dates:
    print(f"\n处理 {target_date.strftime('%Y-%m-%d %H:%M')} UTC...")
    
    # 从CCKW数据中提取散度异常 - 正确纬度顺序
    try:
        # 先选择时间点
        cckw_time = cckw_ds['kelvin'].sel(time=target_date, method='nearest')
        print(f"CCKW时间: {cckw_time.time.values}")
        
        # 再选择空间范围 - 正确纬度顺序 (从小到大)
        cckw_div = cckw_time.sel(
            lon=slice(plot_extent[0], plot_extent[1]),
            lat=slice(plot_extent[2], plot_extent[3])  # 注意: 纬度从小到大
        )
        print(f"CCKW数据形状: {cckw_div.shape}")
    except Exception as e:
        print(f"处理CCKW数据时出错: {e}")
        continue
    
    # 从ERA5数据中提取绝对涡度 - 正确纬度顺序
    try:
        # 先选择时间点
        abs_vort_time = absolute_vorticity.sel(valid_time=target_date, method='nearest')
        print(f"ERA5时间: {abs_vort_time.valid_time.values}")
        
        # 再选择空间范围 - 正确纬度顺序 (从小到大)
        abs_vort = abs_vort_time.sel(
            longitude=slice(plot_extent[0], plot_extent[1]),
            latitude=slice(plot_extent[2], plot_extent[3])  # 注意: 纬度从小到大
        )
        print(f"ERA5数据形状: {abs_vort.shape}")
    except Exception as e:
        print(f"处理ERA5数据时出错: {e}")
        continue
    
    # 确保坐标对齐 - 重命名ERA5维度以匹配CCKW
    abs_vort = abs_vort.rename({
        'longitude': 'lon',
        'latitude': 'lat'
    })
    
    # 对齐数据
    cckw_div, abs_vort = xr.align(cckw_div, abs_vort, join='inner')
    print(f"对齐后数据形状: CCKW={cckw_div.shape}, ERA5={abs_vort.shape}")
    
    # 检查数据是否为空
    if cckw_div.size == 0 or abs_vort.size == 0:
        print(f"警告: {target_date} 无有效数据，跳过")
        continue
    
    # 计算涡旋拉伸项: η * (-∇·V')
    vortex_stretching = abs_vort * (-cckw_div)
    
    # 检查计算结果是否为空
    if vortex_stretching.size == 0:
        print(f"警告: {target_date} 涡旋拉伸项计算结果为空，跳过")
        continue
    
    # 将数据加载到内存（避免Dask数组问题）
    vortex_stretching = vortex_stretching.compute()
    
    all_vortex_stretching.append(vortex_stretching)
    valid_dates.append(target_date)
    print(f"成功计算 {target_date} 涡旋拉伸项，数据形状: {vortex_stretching.shape}")

# 检查是否有有效数据
if not all_vortex_stretching:
    raise ValueError("没有有效的涡旋拉伸项数据，无法继续绘图")

# 确定全局色标范围
valid_min = min([vs.min().values for vs in all_vortex_stretching])
valid_max = max([vs.max().values for vs in all_vortex_stretching])
abs_max = max(abs(valid_min), abs(valid_max))
vmin, vmax = -abs_max, abs_max  # 对称色标
print(f"全局色标范围: {vmin:.2e} 到 {vmax:.2e} s⁻²")

# ========================= 4. 绘制三维立体图 =========================
print("\n>>> 绘制三维立体图...")

# 创建自定义颜色映射
cmap = plt.get_cmap('RdBu_r')  # 红蓝对比色

# 循环绘制每个时刻的图像
for i, target_date in enumerate(valid_dates):
    print(f"\n绘图 {target_date.strftime('%Y-%m-%d %H:%M')} UTC...")
    vortex_stretching = all_vortex_stretching[i]
    freddy_lon, freddy_lat = freddy_positions[target_date]
    
    # 创建三维图形
    fig = plt.figure(figsize=(16, 12))
    ax = fig.add_subplot(111, projection='3d')
    
    # 获取数据网格
    lons = vortex_stretching.lon.values
    lats = vortex_stretching.lat.values
    lon_grid, lat_grid = np.meshgrid(lons, lats)
    Z = vortex_stretching.values * 1e11  # 转换为10^{-11} s^{-2}单位
    
    # 创建颜色映射
    norm = Normalize(vmin=vmin*1e11, vmax=vmax*1e11)
    colors = cmap(norm(Z))
    
    # 绘制三维曲面
    surf = ax.plot_surface(
        lon_grid, lat_grid, Z, 
        facecolors=colors,
        rstride=1, cstride=1,  # 控制网格密度
        edgecolor='none', 
        alpha=0.8
    )
    
    # 添加色标
    cbar = fig.colorbar(
        cm.ScalarMappable(norm=norm, cmap=cmap),
        ax=ax, pad=0.1, shrink=0.6
    )
    cbar.set_label('Vortex Stretching ($10^{-11}$ s$^{-2}$)', fontsize=12)
    
    # 标记Freddy涡旋位置
    ax.plot([freddy_lon], [freddy_lat], [0], 'rx', 
            markersize=12, markeredgewidth=2, zorder=5, label='TC Freddy')
    
    # 添加垂直线显示位置
    try:
        # 获取Freddy位置处的值
        # 找到最接近的网格点
        lon_idx = np.abs(lons - freddy_lon).argmin()
        lat_idx = np.abs(lats - freddy_lat).argmin()
        z_val = Z[lat_idx, lon_idx]
        
        # 绘制垂直线
        ax.plot([freddy_lon, freddy_lon], [freddy_lat, freddy_lat], 
                [0, z_val], 'r-', linewidth=2, zorder=4)
    except Exception as e:
        print(f"无法绘制Freddy位置的垂直线: {e}")
    
    # 绘制Genesis Box
    box_lons = [genesis_box['lon_min'], genesis_box['lon_max'], 
               genesis_box['lon_max'], genesis_box['lon_min'], 
               genesis_box['lon_min']]
    box_lats = [genesis_box['lat_min'], genesis_box['lat_min'], 
               genesis_box['lat_max'], genesis_box['lat_max'], 
               genesis_box['lat_min']]
    ax.plot(box_lons, box_lats, [0, 0, 0, 0, 0], 'm-', 
            linewidth=2.5, zorder=4, label='Genesis Box')
    
    # 添加Genesis Box标签
    ax.text(
        genesis_box['lon_min'] + 0.5, 
        genesis_box['lat_min'] + 0.5, 0, 
        'Freddy Genesis Box', 
        color='m', fontsize=10, zorder=4
    )
    
    # 设置轴标签
    ax.set_xlabel('Longitude (°E)', fontsize=12, labelpad=15)
    ax.set_ylabel('Latitude (°N)', fontsize=12, labelpad=15)
    ax.set_zlabel('Vortex Stretching ($10^{-11}$ s$^{-2}$)', fontsize=12, labelpad=15)
    
    # 设置标题
    ax.set_title(
        f"Vortex Stretching: CCKW Divergence × Absolute Vorticity\n"
        f"Date: {target_date.strftime('%Y-%m-%d %H:%M')} UTC | "
        f"TC Freddy: {freddy_lon:.2f}°E, {freddy_lat:.2f}°N",
        fontsize=14,
        pad=20
    )
    
    # 设置图例
    ax.legend(loc='upper right')
    
    # 设置视角
    ax.view_init(elev=35, azim=-60)  # 调整视角以获得最佳视觉效果
    
    # 设置z轴范围
    z_abs_max = np.max(np.abs(Z))
    ax.set_zlim(-z_abs_max * 1.2, z_abs_max * 1.2)
    
    # 设置绘图区域
    ax.set_xlim(plot_extent[0], plot_extent[1])
    ax.set_ylim(plot_extent[2], plot_extent[3])
    
    # 添加网格
    ax.grid(True, linestyle='--', alpha=0.5)
    
    # 保存图像
    date_str = target_date.strftime('%Y%m%d_%H%M')
    output_path = os.path.join(output_dir, f'Freddy_Vortex_Stretching_3D_{date_str}.png')
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    print(f"保存图像: {output_path}")
    
    # 显示图像
    plt.show()
    plt.close()

# 关闭数据集
cckw_ds.close()
era5_ds.close()
ibtr_ds.close()

print("\n处理完成! 所有日期图像已生成")