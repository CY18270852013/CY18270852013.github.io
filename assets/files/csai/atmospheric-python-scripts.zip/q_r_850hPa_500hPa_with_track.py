import xarray as xr
import matplotlib.pyplot as plt
import os
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import numpy as np
from datetime import datetime, timezone
import warnings
from cartopy.io import DownloadWarning
import pandas as pd

# 禁用cartopy的下载警告
warnings.filterwarnings("ignore", category=DownloadWarning)

# 读取流场数据
uv_file_path = "D:\\MATLAB\\Freddy\\Initial_phase_environmental_field.nc"
ds = xr.open_dataset(uv_file_path)

# 读取热带气旋Freddy的路径数据
track_file_path = 'D:/MATLAB/Freddy/IBTrACS.SI.v04r01.nc'
track_data = xr.open_dataset(track_file_path)

# 找到FREDDY热带气旋的数据
freddy_sid = b'2023036S12117'  # FREDDY的sid
freddy_data = track_data.sel(storm=(track_data['sid'] == freddy_sid))

# 检查是否找到FREDDY的数据
if freddy_data.sizes['storm'] == 0:
    raise ValueError(f"未找到sid为 {freddy_sid} 的热带气旋数据。")

# 获取FREDDY的时间和经纬度数据
times = freddy_data['time'].values
lats = freddy_data['lat'].values
lons = freddy_data['lon'].values

# 过滤掉无效的时间和数据
valid_indices = ~np.isnat(times) & ~np.isnan(lats) & ~np.isnan(lons)
times = times[valid_indices]
lats = lats[valid_indices]
lons = lons[valid_indices]

# 将时间转换为datetime对象（时区感知）
times = [datetime.fromtimestamp(t.astype('O')/1e9, tz=timezone.utc) for t in times]

# 设置绘图范围
lat_range = (0, -40)  # 数据筛选范围：从赤道到南纬40°
lon_range = (25, 130)
time_range = ('2023-02-01', '2023-03-31')

# 筛选流场数据
ds = ds.sel(latitude=slice(*lat_range), longitude=slice(*lon_range), valid_time=slice(*time_range))

# 创建保存图像的文件夹
os.makedirs("C:\\Users\\Dell\\Desktop\\q_850hPa_with_track", exist_ok=True)
os.makedirs("C:\\Users\\Dell\\Desktop\\q_500hPa_with_track", exist_ok=True)
os.makedirs("C:\\Users\\Dell\\Desktop\\r_850hPa_with_track", exist_ok=True)
os.makedirs("C:\\Users\\Dell\\Desktop\\r_500hPa_with_track", exist_ok=True)

# 格式化时间戳为合法的文件名
def format_filename(time):
    return time.dt.strftime("%Y-%m-%d_%H-%M-%S").values

# 设置颜色映射（数值大用蓝色，数值小用红色）
cmap = plt.cm.coolwarm.reversed()  # 反转颜色映射

# 计算全局最小值和最大值，并设置颜色柱的分层
def get_levels(data, variable, pressure_level, num_levels=20):
    data_subset = data[variable].sel(pressure_level=pressure_level)
    vmin = data_subset.min().values
    vmax = data_subset.max().values
    levels = np.linspace(vmin, vmax, num_levels)  # 均匀分层
    return levels

# 获取颜色柱的分层
q_850_levels = get_levels(ds, "q", 850)
q_500_levels = get_levels(ds, "q", 500)
r_850_levels = get_levels(ds, "r", 850)
r_500_levels = get_levels(ds, "r", 500)

# 绘制比湿（q）和相对湿度（r）的热力分布图，并叠加Freddy路径
def plot_humidity_with_track(data, variable, pressure_level, time, save_folder, levels, freddy_times, freddy_lons, freddy_lats):
    # 将流场时间转换为时区感知的datetime对象
    current_time = pd.to_datetime(time.values).replace(tzinfo=timezone.utc)
    
    # 创建地图
    fig = plt.figure(figsize=(12, 8))
    ax = plt.axes(projection=ccrs.PlateCarree())
    
    # 添加地图背景
    ax.set_facecolor('white')  # 设置背景为白色
    ax.add_feature(cfeature.LAND, edgecolor='black')  # 添加陆地边界
    ax.add_feature(cfeature.OCEAN, edgecolor='black')  # 添加海洋边界
    ax.add_feature(cfeature.COASTLINE, linewidth=0.5)  # 添加海岸线
    ax.add_feature(cfeature.BORDERS, linestyle=':', linewidth=0.5)  # 添加国界线
    
    # 添加经纬网
    gl = ax.gridlines(draw_labels=True, linewidth=0.5, color='gray', alpha=0.5, linestyle='--')
    gl.top_labels = False  # 不显示顶部标签
    gl.right_labels = False  # 不显示右侧标签
    
    # 绘制热力分布图
    plot = ax.contourf(ds.longitude, ds.latitude, data, cmap=cmap, levels=levels, extend='both')
    cbar = plt.colorbar(plot, ax=ax, orientation='horizontal', pad=0.05, label=f"{variable} at {pressure_level}hPa")
    
    # 设置颜色柱刻度的字体大小和旋转角度
    cbar.ax.tick_params(labelsize=8)  # 设置字体大小
    for tick in cbar.ax.get_xticklabels():
        tick.set_rotation(45)  # 旋转45°
    
    # 绘制Freddy路径（如果存在）
    if current_time >= datetime(2023, 2, 4, tzinfo=timezone.utc) and current_time <= datetime(2023, 3, 14, tzinfo=timezone.utc):
        # 找到当前时间之前的路径点
        path_indices = [i for i, t in enumerate(freddy_times) if t <= current_time]
        if path_indices:
            ax.plot(freddy_lons[path_indices], freddy_lats[path_indices], color='red', marker='o', markersize=4, transform=ccrs.PlateCarree())
    
    # 设置标题和坐标轴
    ax.set_title(f"{variable} at {pressure_level}hPa with Freddy Track on {current_time.strftime('%Y-%m-%d %H:%M:%S')}")
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_xlim(lon_range)
    ax.set_ylim(lat_range[::-1])  # 翻转纬度轴
    
    # 格式化文件名并保存
    filename = format_filename(time)
    plt.savefig(f"{save_folder}\\{filename}.png", dpi=300, bbox_inches='tight')
    plt.close()

# 绘制850hPa和500hPa的比湿（q）和相对湿度（r），并叠加Freddy路径
for time in ds.valid_time:
    # 850hPa比湿（q）
    q_850 = ds.q.sel(pressure_level=850, valid_time=time)
    plot_humidity_with_track(q_850, "Specific Humidity (q)", 850, time, "C:\\Users\\Dell\\Desktop\\q_850hPa_with_track", q_850_levels, times, lons, lats)
    
    # 500hPa比湿（q）
    q_500 = ds.q.sel(pressure_level=500, valid_time=time)
    plot_humidity_with_track(q_500, "Specific Humidity (q)", 500, time, "C:\\Users\\Dell\\Desktop\\q_500hPa_with_track", q_500_levels, times, lons, lats)
    
    # 850hPa相对湿度（r）
    r_850 = ds.r.sel(pressure_level=850, valid_time=time)
    plot_humidity_with_track(r_850, "Relative Humidity (r)", 850, time, "C:\\Users\\Dell\\Desktop\\r_850hPa_with_track", r_850_levels, times, lons, lats)
    
    # 500hPa相对湿度（r）
    r_500 = ds.r.sel(pressure_level=500, valid_time=time)
    plot_humidity_with_track(r_500, "Relative Humidity (r)", 500, time, "C:\\Users\\Dell\\Desktop\\r_500hPa_with_track", r_500_levels, times, lons, lats)

# 关闭数据集
ds.close()
track_data.close()