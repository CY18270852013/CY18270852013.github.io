import numpy as np
import xarray as xr
import matplotlib.pyplot as plt
import os
import time
from datetime import datetime, timedelta

# 配置路径
input_dir = "E:/GPM_daily_20090101_20231231"
output_dir = "E:/GPM_harmonic_components"
os.makedirs(output_dir, exist_ok=True)

# 记录开始时间
start_time = time.time()
print(f"====== Harmonic Component Analysis Started ======")
print(f"Start time: {time.strftime('%Y-%m-%d %H:%M:%S')}")
print(f"Input directory: {input_dir}")
print(f"Output directory: {output_dir}")
print(f"Analysis years: 2009-2023 (15 years)")

# 1. 构建气候态数据集
print("\n====== Step 1/5: Building Climatology Dataset ======")
clim_days = 366  # 闰年天数
years = list(range(2009, 2024))  # 2009-2023年
lat_size, lon_size = 1800, 3600
total_years = len(years)
print(f"Grid dimensions: Longitude {lon_size} × Latitude {lat_size}")
print(f"Climatology days: {clim_days} (leap year system)")
print(f"Processing {total_years} years to build climatology...")

# 初始化气候态数组
clim_sum = np.zeros((clim_days, lat_size, lon_size), dtype=np.float32)
clim_count = np.zeros(clim_days, dtype=np.int32)

# 统计文件总数
total_files = 0
for year in years:
    if (year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)):
        total_files += 366  # 闰年
    else:
        total_files += 365  # 平年

print(f"Total files to process: {total_files}")
processed_files = 0
last_progress = -1

# 遍历所有年份的每日数据
for year_idx, year in enumerate(years):
    print(f"\nProcessing year {year} ({year_idx+1}/{total_years})...")
    start_date = datetime(year, 1, 1)
    end_date = datetime(year, 12, 31)
    current_date = start_date
    
    while current_date <= end_date:
        # 构建文件名
        filename = f"GPM_daily_{current_date.strftime('%Y%m%d')}.nc"
        filepath = os.path.join(input_dir, filename)
        
        if os.path.exists(filepath):
            try:
                # 读取数据
                with xr.open_dataset(filepath) as ds:
                    precip = ds['precipitation'].values.squeeze()
                
                # 计算闰年中的日序 (1-366)
                doy_leap = (current_date - datetime(year, 1, 1)).days + 1
                
                # 非闰年且超过2月28日时调整日序
                if not (year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)) and doy_leap > 59:
                    doy_leap += 1
                
                idx = doy_leap - 1  # 转换为0-based索引
                
                # 累加降水数据
                if idx < clim_days:
                    clim_sum[idx] += precip
                    clim_count[idx] += 1
            except Exception as e:
                print(f"\nWarning: Error processing file {filename} - {str(e)}")
        
        # 更新进度
        processed_files += 1
        progress = int(100 * processed_files / total_files)
        if progress > last_progress:
            print(f"Progress: {progress}% ({processed_files}/{total_files} files)", end='\r')
            last_progress = progress
        
        # 下一天
        current_date += timedelta(days=1)

# 计算平均气候态
print("\nCalculating mean climatology...")
climatology = np.zeros_like(clim_sum)
for i in range(clim_days):
    if clim_count[i] > 0:
        climatology[i] = clim_sum[i] / clim_count[i]
    else:
        climatology[i] = np.nan  # 处理无数据日

# 打印气候态统计信息
print("\nClimatology Statistics:")
print(f"  Valid days: {np.sum(clim_count > 0)}/{clim_days}")
print(f"  Max daily precipitation: {np.nanmax(climatology):.2f} mm")
print(f"  Min daily precipitation: {np.nanmin(climatology):.2f} mm")
print(f"  Global mean precipitation: {np.nanmean(climatology):.2f} mm")

# 2. 选择代表性格点
print("\n====== Step 2/5: Selecting Representative Grid Points ======")
# 定义三个代表性位置（海洋、陆地、热带）
points = {
    "Tropical_Ocean": {"lon": 160.0, "lat": 0.0, "color": "blue", "label": "Tropical Ocean (160°E, 0°N)"},
    "Midlatitude_Land": {"lon": 100.0, "lat": 45.0, "color": "green", "label": "Midlatitude Land (100°E, 45°N)"},
    "Polar_Ocean": {"lon": 0.0, "lat": -70.0, "color": "purple", "label": "Polar Ocean (0°E, 70°S)"}
}

def find_grid_index(lon, lat):
    """根据经纬度查找最近的格点索引"""
    # 经度范围: 0.05 到 359.95, 0.1度分辨率
    lon_idx = int(round((lon - 0.05) / 0.1)) % lon_size
    # 纬度范围: -89.95 到 89.95, 0.1度分辨率
    lat_idx = int(round((lat - (-89.95)) / 0.1))
    return lon_idx, lat_idx

# 存储各点的气候态序列
point_data = {}

for name, info in points.items():
    lon_idx, lat_idx = find_grid_index(info["lon"], info["lat"])
    print(f"Location: {info['label']} -> Grid index (lon={lon_idx}, lat={lat_idx})")
    
    # 提取该点的气候态序列
    ts = climatology[:, lat_idx, lon_idx]
    point_data[name] = {
        "ts": ts,
        "lon_idx": lon_idx,
        "lat_idx": lat_idx,
        "color": info["color"],
        "label": info["label"]
    }

# 3. 谐波拟合
print("\n====== Step 3/5: Performing Harmonic Fitting ======")
t = np.arange(clim_days)
T = clim_days  # 周期长度

# 设计矩阵 (前三阶谐波)
A = np.column_stack([
    np.ones(clim_days),  # 常数项
    np.cos(2 * np.pi * t / T),  # 年周期 (基波)
    np.sin(2 * np.pi * t / T),
    np.cos(4 * np.pi * t / T),  # 半年周期 (一次谐波)
    np.sin(4 * np.pi * t / T),
    np.cos(6 * np.pi * t / T),  # 四个月周期 (二次谐波)
    np.sin(6 * np.pi * t / T)
])

print("Harmonic basis functions:")
print("  1. Constant term")
print("  2. Annual cycle (cos)")
print("  3. Annual cycle (sin)")
print("  4. Semi-annual cycle (cos)")
print("  5. Semi-annual cycle (sin)")
print("  6. 4-month cycle (cos)")
print("  7. 4-month cycle (sin)")

# 对每个点进行谐波拟合
for name, data in point_data.items():
    print(f"\nFitting harmonics for {data['label']}...")
    ts = data["ts"]
    
    # 检查并处理NaN值
    valid = ~np.isnan(ts)
    if not np.all(valid):
        print(f"  Warning: Found {np.sum(~valid)} NaN values, ignoring these points")
    
    # 最小二乘拟合
    A_valid = A[valid]
    ts_valid = ts[valid]
    coeffs = np.linalg.lstsq(A_valid, ts_valid, rcond=None)[0]
    
    # 存储结果
    data["coeffs"] = coeffs
    
    # 计算每个谐波分量
    components = []
    component_names = ["Constant", "Annual Cycle", "Semi-Annual Cycle", "4-Month Cycle"]
    
    # 常数项
    components.append(coeffs[0] * np.ones_like(t))
    
    # 年周期分量 (基波)
    annual = coeffs[1] * A[:, 1] + coeffs[2] * A[:, 2]
    components.append(annual)
    
    # 半年周期分量 (一次谐波)
    semi_annual = coeffs[3] * A[:, 3] + coeffs[4] * A[:, 4]
    components.append(semi_annual)
    
    # 四个月周期分量 (二次谐波)
    four_month = coeffs[5] * A[:, 5] + coeffs[6] * A[:, 6]
    components.append(four_month)
    
    # 存储分量
    data["components"] = components
    data["component_names"] = component_names
    
    # 计算每个分量的振幅和相位
    amplitudes = []
    phases = []
    
    # 常数项
    amplitudes.append(np.abs(coeffs[0]))
    phases.append(0)
    
    # 年周期
    amp_annual = np.sqrt(coeffs[1]**2 + coeffs[2]**2)
    phase_annual = np.arctan2(coeffs[2], coeffs[1])  # 弧度
    amplitudes.append(amp_annual)
    phases.append(phase_annual)
    
    # 半年周期
    amp_semi = np.sqrt(coeffs[3]**2 + coeffs[4]**2)
    phase_semi = np.arctan2(coeffs[4], coeffs[3])
    amplitudes.append(amp_semi)
    phases.append(phase_semi)
    
    # 四个月周期
    amp_4m = np.sqrt(coeffs[5]**2 + coeffs[6]**2)
    phase_4m = np.arctan2(coeffs[6], coeffs[5])
    amplitudes.append(amp_4m)
    phases.append(phase_4m)
    
    data["amplitudes"] = amplitudes
    data["phases"] = phases
    
    # 打印谐波参数
    print("  Harmonic parameters:")
    for i in range(4):
        print(f"    {component_names[i]}:")
        print(f"      Amplitude: {amplitudes[i]:.4f} mm")
        if i > 0:
            phase_days = phases[i] * T / (2 * np.pi * i)  # 转换为天数
            print(f"      Phase: {phases[i]:.4f} rad ({phase_days:.1f} days)")
    
    # 计算总拟合序列
    total_fit = np.sum(components, axis=0)
    residual = ts - total_fit
    r2 = 1 - np.nansum(residual**2) / np.nansum((ts - np.nanmean(ts))**2)
    print(f"  Total fit quality: R² = {r2:.4f}")

# 4. 可视化谐波分量
print("\n====== Step 4/5: Visualizing Harmonic Components ======")
plt.figure(figsize=(15, 12))

# 对每个点创建可视化
for i, (name, data) in enumerate(point_data.items()):
    # 创建子图网格: 3行2列
    ax_main = plt.subplot(3, 2, i*2+1)
    ax_components = plt.subplot(3, 2, i*2+2)
    
    # 主图: 原始气候态和总拟合
    ax_main.plot(t, data["ts"], 'k-', linewidth=1.5, label="Original climatology")
    ax_main.plot(t, np.sum(data["components"], axis=0), data["color"], linewidth=2, label="Harmonic fit")
    ax_main.set_title(f"{data['label']} - Precipitation Climatology", fontsize=12)
    ax_main.set_xlabel("Day of Year (Jan 1 = 0)", fontsize=10)
    ax_main.set_ylabel("Precipitation (mm)", fontsize=10)
    ax_main.legend()
    ax_main.grid(True, linestyle='--', alpha=0.7)
    
    # 标记季节
    seasons = {"Jan 1": 0, "Apr 1": 90, "Jul 1": 181, "Oct 1": 273}
    for label, day in seasons.items():
        ax_main.axvline(day, color='gray', linestyle='--', alpha=0.5)
        ax_main.text(day, ax_main.get_ylim()[1]*0.95, label, ha='center', fontsize=9)
    
    # 分量图: 显示各个谐波分量
    colors = ['black', 'red', 'green', 'blue']
    for j, component in enumerate(data["components"]):
        ax_components.plot(t, component, color=colors[j], linewidth=1.5, 
                          label=f"{data['component_names'][j]}")
    
    ax_components.set_title(f"Harmonic Components", fontsize=12)
    ax_components.set_xlabel("Day of Year (Jan 1 = 0)", fontsize=10)
    ax_components.set_ylabel("Component Value (mm)", fontsize=10)
    ax_components.legend()
    ax_components.grid(True, linestyle='--', alpha=0.7)
    
    # 添加谐波参数信息
    info_text = "Harmonic Parameters:\n"
    for j in range(4):
        info_text += f"{data['component_names'][j]}: "
        info_text += f"Amp = {data['amplitudes'][j]:.2f} mm"
        if j > 0:
            phase_days = data["phases"][j] * T / (2 * np.pi * j)
            info_text += f", Phase = {phase_days:.1f} days"
        info_text += "\n"
    
    ax_components.text(0.98, 0.98, info_text, transform=ax_components.transAxes,
                      verticalalignment='top', horizontalalignment='right',
                      fontsize=9, bbox=dict(facecolor='white', alpha=0.8))

plt.tight_layout()

# 5. 保存结果
print("\n====== Step 5/5: Saving Results ======")
output_path = os.path.join(output_dir, "harmonic_components_analysis.png")
plt.savefig(output_path, dpi=300)
print(f"Visualization saved to: {output_path}")

# 打印总运行时间
total_time = time.time() - start_time
hours, remainder = divmod(total_time, 3600)
minutes, seconds = divmod(remainder, 60)
print("\n====== Processing Complete! ======")
print(f"Total runtime: {int(hours)}h {int(minutes)}m {seconds:.1f}s")
print(f"Output file: {output_path}")
print(f"End time: {time.strftime('%Y-%m-%d %H:%M:%S')}")

# 显示图形
plt.show()