# -*- coding: utf-8 -*-
"""
Created on Wed Nov 13 20:22:08 2024

@author: Dell
"""

import h5py

# 文件路径
path = r"D:\MATLAB\Freddy\w_mjo.mat"

def explore_hdf5_group(group, indent=0):
    """递归遍历hdf5组，打印所有数据集的信息"""
    for key, item in group.items():
        # 打印键名和缩进，方便观察层级结构
        print(" " * indent + f"Key: '{key}'")
        
        # 检查item类型
        if isinstance(item, h5py.Group):
            # 如果item是组（相当于一个文件夹），递归处理
            print(" " * (indent + 2) + f"Group: '{key}'")
            explore_hdf5_group(item, indent + 4)
        elif isinstance(item, h5py.Dataset):
            # 如果item是数据集，打印其详细信息
            print(" " * (indent + 2) + f"Dataset: '{key}'")
            print(" " * (indent + 4) + f"Shape: {item.shape}")
            print(" " * (indent + 4) + f"Data Type: {item.dtype}")
            
            # 读取数据（如果数据集较小，显示数据内容）
            data = item[()]
            if data.size <= 10:  # 控制输出数据量，防止过长
                print(" " * (indent + 4) + f"Data: {data}")
            else:
                print(" " * (indent + 4) + "Data: <Too large to display>")

# 打开MATLAB v7.3文件并调用函数打印详细信息
with h5py.File(path, 'r') as mat_file:
    print("文件 w_mjo.mat 包含的详细信息：")
    explore_hdf5_group(mat_file)
