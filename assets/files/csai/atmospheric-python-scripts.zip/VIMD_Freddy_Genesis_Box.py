import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
import sys

# === 1. 数据路径 ===
file_paths = {
    'vimd': r'E:\VIMD_anomaly_6hourly\VIMD_anomaly_6hourly_20230101_20230331.nc',
    'vimd_mjo': r'E:\VIMD_anomaly_6hourly\VIMD_anomaly_for_MJO_6hourly_20230101_20230331.nc',
    'vimd_kelvin': r'E:\VIMD_anomaly_6hourly\VIMD_anomaly_for_Kelvin_6hourly_20230101_20230331.nc',
    'vimd_mrg': r'E:\VIMD_anomaly_6hourly\VIMD_anomaly_for_MRG_6hourly_20230101_20230331.nc',
    'vimd_er': r'E:\VIMD_anomaly_6hourly\VIMD_anomaly_for_ER_6hourly_20230101_20230331.nc'
}

# === 2. 加载数据 ===
print("加载数据...")
try:
    # 原始VIMD异常
    vimd_data = xr.open_dataset(file_paths['vimd'])['vimd_anomaly']
    
    # 各波动分量
    vimd_mjo = xr.open_dataset(file_paths['vimd_mjo'])['vimd_anomaly_mjo']
    vimd_kelvin = xr.open_dataset(file_paths['vimd_kelvin'])['vimd_anomaly_kelvin']
    vimd_mrg = xr.open_dataset(file_paths['vimd_mrg'])['vimd_anomaly_mrg']
    vimd_er = xr.open_dataset(file_paths['vimd_er'])['vimd_anomaly_er']
    
except Exception as e:
    print(f"加载数据失败: {e}")
    sys.exit()

# === 3. 设置时间与空间范围 ===
start_date = datetime(2023, 2, 1)
end_date = datetime(2023, 3, 15)
lon_range = slice(110, 120)  # 110°E ~ 120°E
lat_range = slice(-20, -10)  # 10°S ~ 20°S (纬度降序)

# === 4. 切片与空间平均 ===
print("\n切片与空间平均...")

# 处理原始VIMD数据
vimd_slice = vimd_data.sel(time=slice(start_date, end_date), 
                          longitude=lon_range, 
                          latitude=lat_range)
vimd_avg = vimd_slice.mean(dim=['longitude', 'latitude'], skipna=True)

# 处理MJO分量
vimd_mjo_slice = vimd_mjo.sel(time=slice(start_date, end_date), 
                             lon=lon_range, 
                             lat=lat_range)
vimd_mjo_avg = vimd_mjo_slice.mean(dim=['lon', 'lat'], skipna=True)

# 处理Kelvin分量
vimd_kelvin_slice = vimd_kelvin.sel(time=slice(start_date, end_date), 
                                   lon=lon_range, 
                                   lat=lat_range)
vimd_kelvin_avg = vimd_kelvin_slice.mean(dim=['lon', 'lat'], skipna=True)

# 处理MRG分量
vimd_mrg_slice = vimd_mrg.sel(time=slice(start_date, end_date), 
                             lon=lon_range, 
                             lat=lat_range)
vimd_mrg_avg = vimd_mrg_slice.mean(dim=['lon', 'lat'], skipna=True)

# 处理ER分量
vimd_er_slice = vimd_er.sel(time=slice(start_date, end_date), 
                           lon=lon_range, 
                           lat=lat_range)
vimd_er_avg = vimd_er_slice.mean(dim=['lon', 'lat'], skipna=True)

# 计算所有波动分量之和
sum_waves = vimd_mjo_avg + vimd_kelvin_avg + vimd_mrg_avg + vimd_er_avg

# === 5. 数据处理：确保没有NaN或Inf值 ===
# 打印数据统计信息以便调试
print("\n数据统计信息:")
print(f"原始VIMD异常: 最小值={np.nanmin(vimd_avg.values):.4f}, 最大值={np.nanmax(vimd_avg.values):.4f}")
print(f"MJO分量: 最小值={np.nanmin(vimd_mjo_avg.values):.4f}, 最大值={np.nanmax(vimd_mjo_avg.values):.4f}")
print(f"Kelvin分量: 最小值={np.nanmin(vimd_kelvin_avg.values):.4f}, 最大值={np.nanmax(vimd_kelvin_avg.values):.4f}")
print(f"MRG分量: 最小值={np.nanmin(vimd_mrg_avg.values):.4f}, 最大值={np.nanmax(vimd_mrg_avg.values):.4f}")
print(f"ER分量: 最小值={np.nanmin(vimd_er_avg.values):.4f}, 最大值={np.nanmax(vimd_er_avg.values):.4f}")
print(f"波动总和: 最小值={np.nanmin(sum_waves.values):.4f}, 最大值={np.nanmax(sum_waves.values):.4f}")

# 替换任何可能的NaN值为0
vimd_avg = vimd_avg.fillna(0)
vimd_mjo_avg = vimd_mjo_avg.fillna(0)
vimd_kelvin_avg = vimd_kelvin_avg.fillna(0)
vimd_mrg_avg = vimd_mrg_avg.fillna(0)
vimd_er_avg = vimd_er_avg.fillna(0)
sum_waves = sum_waves.fillna(0)

# === 6. 数值缩放：将数据乘以1000 ===
print("数值缩放：将数据乘以1000...")
scale_factor = 1000  # 缩放因子

vimd_avg = vimd_avg * scale_factor
vimd_mjo_avg = vimd_mjo_avg * scale_factor
vimd_kelvin_avg = vimd_kelvin_avg * scale_factor
vimd_mrg_avg = vimd_mrg_avg * scale_factor
vimd_er_avg = vimd_er_avg * scale_factor
sum_waves = sum_waves * scale_factor

# === 7. 绘图 ===
print("开始绘图...")
plt.figure(figsize=(12, 6), dpi=300)

# 绘制各波动分量
plt.plot(vimd_avg.time.values, vimd_avg.values, 
         color='green', label='Anomaly', linewidth=2.0)
plt.plot(vimd_mjo_avg.time.values, vimd_mjo_avg.values, 
         color='black', label='MJO', linewidth=2.0)
plt.plot(vimd_kelvin_avg.time.values, vimd_kelvin_avg.values, 
         color='blue', label='Kelvin', linewidth=2.0)
plt.plot(vimd_mrg_avg.time.values, vimd_mrg_avg.values, 
         color='gray', label='MRG', linewidth=2.0)
plt.plot(vimd_er_avg.time.values, vimd_er_avg.values, 
         color='red', label='ER', linewidth=2.0)
plt.plot(sum_waves.time.values, sum_waves.values, 
         color='purple', linestyle='--', label='Sum of Waves', linewidth=2.4)

# 设置横轴格式
ax = plt.gca()
ax.xaxis.set_major_locator(mdates.DayLocator(interval=2))  # 每2天一个刻度
ax.xaxis.set_major_formatter(mdates.DateFormatter('%b-%d'))  # 格式: Feb-01
plt.xticks(rotation=45)

# 设置纵轴范围 - 使用安全方法避免NaN/Inf
try:
    # 获取所有数据点（忽略NaN）的最小值和最大值
    all_data = np.concatenate([
        vimd_avg.values,
        vimd_mjo_avg.values,
        vimd_kelvin_avg.values,
        vimd_mrg_avg.values,
        vimd_er_avg.values,
        sum_waves.values
    ])
    
    # 移除NaN和Inf值
    all_data = all_data[np.isfinite(all_data)]
    
    # 计算最小值和最大值
    y_min = np.min(all_data) * 1.1
    y_max = np.max(all_data) * 1.1
    
    # 确保y轴范围有效
    if np.isnan(y_min) or np.isinf(y_min) or np.isnan(y_max) or np.isinf(y_max):
        raise ValueError("计算出的y轴范围无效")
        
    plt.ylim(y_min, y_max)
    
except Exception as e:
    print(f"自动计算y轴范围失败: {e}")
    print("使用默认范围: -0.5 到 0.5")
    plt.ylim(-0.5, 0.5)

# 添加标题和标签
plt.title('VIMD Anomalies and Wave Contributions (110°E-120°E, 10°S-20°S)', 
          fontsize=14)
plt.xlabel('Date', fontsize=12)
ax.set_xlim([datetime(2023, 2, 1), datetime(2023, 3, 15)])
plt.ylabel('VIMD Anomaly ($10^{-3}$ kg m$^{-2}$ s$^{-1}$)', fontsize=12)  # 修改单位标签

# 添加水平参考线
plt.axhline(y=0, color='k', linestyle='-', alpha=0.3)

'''
# 添加网格
plt.grid(True, linestyle='--', alpha=0.6)
'''

# 添加图例
plt.legend(loc='upper center', bbox_to_anchor=(0.5, -0.2), 
           ncol=6, fontsize=10, frameon=False)

# 调整布局
plt.tight_layout()

# 保存图像
output_path = r'D:\Freddy_ChenYong\Plot_ChenYong\Figure5_Freddy_Genesis_Box\VIMD_Freddy_Genesis_Box.png'
plt.savefig(output_path, bbox_inches='tight', dpi=300)
print(f"图像已保存至: {output_path}")

plt.show()