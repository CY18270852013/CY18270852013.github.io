import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import os

# 打开NetCDF文件
file_path = r"D:\MATLAB\Freddy\ERA5_data\sea_surface_temperature.nc"
ds = xr.open_dataset(file_path)

# 提取数据
sst = ds['sst']  # 海表面温度
time = ds['valid_time']
lat = ds['latitude']
lon = ds['longitude']

# 计算海表面温度距平
sst_clim = sst.mean(dim='valid_time')  # 平均的海表面温度 (气候态)
sst_anomaly = sst - sst_clim  # 距平

# 设置保存路径
output_dir = r"C:\Users\Dell\Desktop\sea_surface_temperature"
os.makedirs(output_dir, exist_ok=True)  # 如果文件夹不存在，则创建

# 绘图函数
def plot_heatmap(data, title, cmap, vmin, vmax, file_name):
    plt.figure(figsize=(10, 6))
    ax = plt.axes(projection=ccrs.PlateCarree())
    
    # 添加海岸线、国界线和经纬度网格
    ax.coastlines(resolution='110m', linewidth=1.5)  # 清晰的海岸线
    ax.add_feature(cfeature.BORDERS, linestyle='-', linewidth=1.5)  # 国界线
    ax.set_extent([25, 125, -50, 20], crs=ccrs.PlateCarree())  # 设置范围

    # 添加经纬度网格
    gl = ax.gridlines(draw_labels=True, linewidth=1, color='gray', alpha=0.5, linestyle='--')
    gl.top_labels = False  # 不显示顶部的经纬度标签
    gl.right_labels = False  # 不显示右侧的经纬度标签
    gl.xlabel_style = {'size': 10, 'color': 'black'}
    gl.ylabel_style = {'size': 10, 'color': 'black'}
    
    # 绘制热力图
    plt.contourf(lon, lat, data, cmap=cmap, vmin=vmin, vmax=vmax, transform=ccrs.PlateCarree())
    plt.colorbar(label='SST (K)')
    plt.title(title)
    
    # 保存图像，使用完整路径
    plt.savefig(f"{output_dir}/{file_name}", dpi=300)
    plt.close()

# 循环绘制每一天的SST和SST距平
for i in range(len(time)):
    # 每一天的SST图
    sst_day = sst[i, :, :]
    title_sst = f'SST on {time[i].dt.strftime("%Y-%m-%d").item()} 12:00'
    file_name_sst = f'sst_{i}.png'
    plot_heatmap(sst_day, title_sst, cmap='coolwarm', vmin=sst.min(), vmax=sst.max(), file_name=file_name_sst)
    
    # 每一天的SST距平图
    sst_anomaly_day = sst_anomaly[i, :, :]
    title_anomaly = f'SST Anomaly on {time[i].dt.strftime("%Y-%m-%d").item()} 12:00'
    file_name_anomaly = f'sst_anomaly_{i}.png'
    plot_heatmap(sst_anomaly_day, title_anomaly, cmap='RdBu_r', vmin=-2, vmax=2, file_name=file_name_anomaly)

print("海表面温度和距平图已保存完毕。")
