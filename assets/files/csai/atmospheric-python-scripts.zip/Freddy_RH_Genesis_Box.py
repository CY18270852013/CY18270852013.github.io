import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
import os

# 1. 定义参数
box_lon = slice(110, 120)    # 经度范围: 110°E~120°E
box_lat = slice(-10, -20)    # 纬度范围: 10°S~20°S (ERA5纬度从北到南递减)
plevels = [500, 700, 850]    # 气压层
rh_threshold = 81            # 相对湿度阈值线
start_date = "2023-02-01"    # 起始日期
end_date = "2023-03-15"      # 结束日期

# 2. 读取并合并数据
def load_and_combine_data():
    """加载并合并1-3月数据"""
    base_path = "E:/ERA5_dv_q_uv_200901_202312_every_6hours/"
    datasets = []
    
    # 1月数据（仅需最后几天）
    ds_jan = xr.open_dataset(os.path.join(base_path, "202301_q.nc"))
    ds_jan = ds_jan.sel(valid_time=slice("2023-01-29", "2023-01-31"))
    
    # 2月数据
    ds_feb = xr.open_dataset(os.path.join(base_path, "202302_q.nc"))
    
    # 3月数据（仅需上半月）
    ds_mar = xr.open_dataset(os.path.join(base_path, "202303_q.nc"))
    ds_mar = ds_mar.sel(valid_time=slice("2023-03-01", "2023-03-15"))
    
    # 合并数据集
    combined = xr.concat([ds_jan, ds_feb, ds_mar], dim="valid_time")
    return combined

# 3. 处理数据
def process_data(ds):
    """处理数据并计算区域平均"""
    # 选择目标区域和气压层
    ds_box = ds.sel(
        longitude=box_lon,
        latitude=box_lat,
        pressure_level=plevels
    )
    
    # 计算区域平均
    ds_avg = ds_box.mean(dim=["longitude", "latitude"])
    
    # 转换为datetime
    times = ds_avg.valid_time.values.astype("datetime64[s]")
    
    # 提取各层相对湿度
    rh_data = {
        f"{level}hPa": ds_avg["r"].sel(pressure_level=level).values
        for level in plevels
    }
    
    return times, rh_data

# 4. 绘制图表
def plot_rh_timeseries(times, rh_data):
    """绘制相对湿度时间序列图"""
    plt.figure(figsize=(15, 8))
    
    # 绘制三条折线
    colors = ["black", "blue", "red"]  # 黑、蓝、红
    for i, (level, rh_vals) in enumerate(rh_data.items()):
        plt.plot(
            times, 
            rh_vals, 
            label=level, 
            linewidth=2,
            color=colors[i]
        )
    
    # 添加81%参考线
    plt.axhline(
        y=rh_threshold, 
        color="orange", 
        linestyle="--", 
        linewidth=2,
        label=f"{rh_threshold}% threshold"
    )
    
    # 设置坐标轴和标签
    plt.title("Relative Humidity Changes in Freddy Genesis Box\n(110-120°E, 10-20°S)", fontsize=16)
    plt.xlabel("Date", fontsize=14)
    plt.ylabel("Relative Humidity (%)", fontsize=14)
    
    # 设置日期格式（每两天一个刻度）
    plt.gca().xaxis.set_major_locator(mdates.DayLocator(interval=2))
    plt.gca().xaxis.set_major_formatter(mdates.DateFormatter("%m-%d"))
    plt.gcf().autofmt_xdate()  # 自动旋转日期标签
    
    # 设置Y轴范围（根据数据动态调整）
    all_rh = np.concatenate(list(rh_data.values()))
    y_min = min(40, np.floor(np.min(all_rh) / 5) * 5)
    y_max = max(100, np.ceil(np.max(all_rh) / 5) * 5)
    plt.ylim(y_min, y_max)
    # 设置横轴范围（关键添加）
    plt.xlim(
        np.datetime64("2023-02-01"),
        np.datetime64("2023-03-15")
    )
    
    # 添加网格和图例
    plt.grid(alpha=0.3)
    plt.legend(loc="best", fontsize=12)
    
    # 高亮Freddy生成期 (2月6日生成)
    freddy_genesis = datetime(2023, 2, 6)
    plt.axvline(
        x=freddy_genesis, 
        color="red", 
        linestyle=":", 
        alpha=0.7,
        label="Freddy Genesis (Feb 6)"
    )
    
    plt.tight_layout()
    plt.savefig("D:\Freddy_ChenYong\Plot_ChenYong\Figure8\Freddy_RH_Genesis_Box.png", dpi=300)
    plt.show()

# 主程序
if __name__ == "__main__":
    # 加载并处理数据
    ds = load_and_combine_data()
    times, rh_data = process_data(ds)
    
    # 筛选指定日期范围
    mask = (times >= np.datetime64(start_date)) & (times <= np.datetime64(end_date))
    filtered_times = times[mask]
    filtered_rh = {k: v[mask] for k, v in rh_data.items()}
    
    # 绘制图表
    plot_rh_timeseries(filtered_times, filtered_rh)