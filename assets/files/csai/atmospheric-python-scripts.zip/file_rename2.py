# -*- coding: utf-8 -*-
"""
Created on Mon Mar 10 23:32:14 2025

@author: Dell
"""

import os

# 定义路径
directory = r"C:\Users\Dell\Desktop\w_mjo_500hPa_with_track"

# 获取目录下所有 .png 文件
files = [f for f in os.listdir(directory) if f.endswith('.png')]

# 按文件名排序（确保顺序正确）
files.sort()

# 遍历文件并重命名
for index, filename in enumerate(files):
    # 构造新文件名
    new_name = f"{index}.png"
    
    # 构造完整路径
    old_path = os.path.join(directory, filename)
    new_path = os.path.join(directory, new_name)
    
    # 重命名文件
    os.rename(old_path, new_path)
    print(f"重命名: {filename} -> {new_name}")

print("重命名完成！")