# -*- coding: utf-8 -*-
"""
Created on Wed Dec 18 01:43:33 2024

@author: Chen Yong
"""

import matplotlib.pyplot as plt
import numpy as np

# 定义步长h和对应的Gauss-Legendre Error
h_values = np.array([
    7.8125000000000000E-003, 3.9062500000000000E-003, 1.9531250000000000E-003,
    9.7656250000000000E-004, 4.8828125000000000E-004, 2.4414062500000000E-004,
    1.2207031250000000E-004, 6.1035156250000000E-005, 3.0517578125000000E-005,
    1.5258789062500000E-005
])

error_form1 = np.array([
    4.9999959306263372E-002, 2.4999994912451595E-002, 1.2499999363591016E-002,
    6.2499999202146059E-003, 3.1249999899096415E-003, 1.5624999986801117E-003,
    7.8124999980571698E-004, 3.9062499996106621E-004, 1.9531249998780908E-004,
    9.7656249994814022E-005
])

error_form2 = np.array([
    2.4999979654381676E-002, 1.2499997456850796E-002, 6.2499996821080072E-003,
    3.1249999602635525E-003, 1.5624999950329455E-003, 7.8124999937911823E-004,
    3.9062499992238969E-004, 1.9531249999029871E-004, 9.7656249998787325E-005,
    4.8828124999848411E-005
])

# 取自然对数
ln_h_values = np.log(h_values)
ln_error_form1 = np.log(error_form1)
ln_error_form2 = np.log(error_form2)

# 绘制折线图
plt.figure(figsize=(10, 6))
plt.plot(ln_h_values, ln_error_form1, label='Gauss-Legendre Error Integral Form 1', color='blue')
plt.plot(ln_h_values, ln_error_form2, label='Gauss-Legendre Error Integral Form 2', color='red')

# 添加图例
plt.legend()

# 添加标题和轴标签
plt.title('Gauss-Legendre Error vs Step Size h (Log Scale)')
plt.xlabel('ln(Step size h)')
plt.ylabel('ln(Gauss-Legendre Error)')

# 设置y轴和x轴的刻度为科学计数法
plt.ticklabel_format(style='sci', axis='y', scilimits=(0,0))
plt.ticklabel_format(style='sci', axis='x', scilimits=(0,0))

# 显示网格
plt.grid(True)

# 显示图表
plt.show()