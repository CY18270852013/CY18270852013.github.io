# -*- coding: utf-8 -*-
"""
Created on Sun Jul 20 16:22:36 2025

@author: Dell
"""

import numpy as np
import xarray as xr
import matplotlib.pyplot as plt
import os
import time
from datetime import datetime, timedelta

# Configuration paths
input_dir = "E:/GPM_daily_20090101_20231231"
output_dir = "E:/GPM_harmonic_analysis"
os.makedirs(output_dir, exist_ok=True)

# Record start time
start_time = time.time()
print(f"====== Harmonic Analysis Started ======")
print(f"Start time: {time.strftime('%Y-%m-%d %H:%M:%S')}")
print(f"Input directory: {input_dir}")
print(f"Output directory: {output_dir}")
print(f"Analysis years: 2009-2023 (15 years)")

# 1. Build climatology dataset
print("\n====== Step 1/5: Building Climatology Dataset ======")
clim_days = 366  # Leap year days
years = list(range(2009, 2024))  # 2009-2023
lat_size, lon_size = 1800, 3600
total_years = len(years)
print(f"Grid dimensions: Longitude {lon_size} × Latitude {lat_size}")
print(f"Climatology days: {clim_days} (leap year system)")
print(f"Processing {total_years} years to build climatology...")

# Initialize climatology arrays
clim_sum = np.zeros((clim_days, lat_size, lon_size), dtype=np.float32)
clim_count = np.zeros(clim_days, dtype=np.int32)

# Count total files
total_files = 0
for year in years:
    if (year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)):
        total_files += 366  # Leap year
    else:
        total_files += 365  # Common year

print(f"Total files to process: {total_files}")
processed_files = 0
last_progress = -1

# Process daily data for all years
for year_idx, year in enumerate(years):
    print(f"\nProcessing year {year} ({year_idx+1}/{total_years})...")
    start_date = datetime(year, 1, 1)
    end_date = datetime(year, 12, 31)
    current_date = start_date
    
    while current_date <= end_date:
        # Build filename
        filename = f"GPM_daily_{current_date.strftime('%Y%m%d')}.nc"
        filepath = os.path.join(input_dir, filename)
        
        if os.path.exists(filepath):
            try:
                # Read data
                with xr.open_dataset(filepath) as ds:
                    precip = ds['precipitation'].values.squeeze()
                
                # Calculate day of year in leap year system
                doy_leap = (current_date - datetime(year, 1, 1)).days + 1
                
                # Adjust for non-leap years after Feb 28
                if not (year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)) and doy_leap > 59:
                    doy_leap += 1
                
                idx = doy_leap - 1  # Convert to 0-based index
                
                # Accumulate precipitation data
                if idx < clim_days:
                    clim_sum[idx] += precip
                    clim_count[idx] += 1
            except Exception as e:
                print(f"\nWarning: Error processing file {filename} - {str(e)}")
        
        # Update progress
        processed_files += 1
        progress = int(100 * processed_files / total_files)
        if progress > last_progress:
            print(f"Progress: {progress}% ({processed_files}/{total_files} files)", end='\r')
            last_progress = progress
        
        # Next day
        current_date += timedelta(days=1)

# Calculate mean climatology
print("\nCalculating mean climatology...")
climatology = np.zeros_like(clim_sum)
for i in range(clim_days):
    if clim_count[i] > 0:
        climatology[i] = clim_sum[i] / clim_count[i]
    else:
        climatology[i] = np.nan  # Handle missing days

# Print climatology statistics
print("\nClimatology Statistics:")
print(f"  Valid days: {np.sum(clim_count > 0)}/{clim_days}")
print(f"  Max daily precipitation: {np.nanmax(climatology):.2f} mm")
print(f"  Min daily precipitation: {np.nanmin(climatology):.2f} mm")
print(f"  Global mean precipitation: {np.nanmean(climatology):.2f} mm")

# 2. Select representative grid points
print("\n====== Step 2/5: Selecting Representative Grid Points ======")
# Define three representative locations (ocean, land, tropical)
points = {
    "Tropical_Ocean": {"lon": 160.0, "lat": 0.0, "color": "blue", "label": "Tropical Ocean (160°E, 0°N)"},
    "Midlatitude_Land": {"lon": 100.0, "lat": 45.0, "color": "green", "label": "Midlatitude Land (100°E, 45°N)"},
    "Polar_Ocean": {"lon": 0.0, "lat": -70.0, "color": "purple", "label": "Polar Ocean (0°E, 70°S)"}
}

def find_grid_index(lon, lat):
    """Find nearest grid index for given coordinates"""
    # Longitude range: 0.05 to 359.95, 0.1° resolution
    lon_idx = int(round((lon - 0.05) / 0.1)) % lon_size
    # Latitude range: -89.95 to 89.95, 0.1° resolution
    lat_idx = int(round((lat - (-89.95)) / 0.1))
    return lon_idx, lat_idx

# Store climatology time series for each point
point_data = {}

for name, info in points.items():
    lon_idx, lat_idx = find_grid_index(info["lon"], info["lat"])
    print(f"Location: {info['label']} -> Grid index (lon={lon_idx}, lat={lat_idx})")
    
    # Extract climatology time series
    ts = climatology[:, lat_idx, lon_idx]
    point_data[name] = {
        "ts": ts,
        "lon_idx": lon_idx,
        "lat_idx": lat_idx,
        "color": info["color"],
        "label": info["label"]
    }

# 3. Harmonic fitting
print("\n====== Step 3/5: Performing Harmonic Fitting ======")
t = np.arange(clim_days)
T = clim_days  # Period length

# Design matrix (first three harmonics)
A = np.column_stack([
    np.ones(clim_days),  # Constant term
    np.cos(2 * np.pi * t / T),  # Annual cycle
    np.sin(2 * np.pi * t / T),
    np.cos(4 * np.pi * t / T),  # Semi-annual cycle
    np.sin(4 * np.pi * t / T),
    np.cos(6 * np.pi * t / T),  # 4-month cycle
    np.sin(6 * np.pi * t / T)
])

print("Harmonic basis functions:")
print("  1. Constant term")
print("  2. Annual cycle (cos)")
print("  3. Annual cycle (sin)")
print("  4. Semi-annual cycle (cos)")
print("  5. Semi-annual cycle (sin)")
print("  6. 4-month cycle (cos)")
print("  7. 4-month cycle (sin)")

# Perform harmonic fitting for each point
for name, data in point_data.items():
    print(f"\nFitting harmonics for {data['label']}...")
    ts = data["ts"]
    
    # Check and handle NaN values
    valid = ~np.isnan(ts)
    if not np.all(valid):
        print(f"  Warning: Found {np.sum(~valid)} NaN values, these will be ignored")
    
    # Least squares fitting
    A_valid = A[valid]
    ts_valid = ts[valid]
    coeffs = np.linalg.lstsq(A_valid, ts_valid, rcond=None)[0]
    
    # Reconstruct fitted time series
    fitted_ts = np.zeros(clim_days)
    for i in range(len(coeffs)):
        fitted_ts += coeffs[i] * A[:, i]
    
    # Calculate residuals
    residual = ts - fitted_ts
    residual[~valid] = np.nan
    
    # Store results
    data["coeffs"] = coeffs
    data["fitted_ts"] = fitted_ts
    data["residual"] = residual
    
    # Print fitting results
    print("  Fitting coefficients:")
    for i, c in enumerate(coeffs):
        print(f"    Coefficient {i+1}: {c:.4f}")
    
    # Calculate fitting quality metrics
    r2 = 1 - np.nansum(residual**2) / np.nansum((ts - np.nanmean(ts))**2)
    rmse = np.sqrt(np.nanmean(residual**2))
    print(f"  Fit quality: R² = {r2:.4f}, RMSE = {rmse:.4f} mm")

# 4. Visualize results
print("\n====== Step 4/5: Visualizing Results ======")
plt.figure(figsize=(15, 12))

# Create subplot for each point
for i, (name, data) in enumerate(point_data.items()):
    ax = plt.subplot(3, 1, i+1)
    
    # Original climatology
    ax.plot(t, data["ts"], 'k-', linewidth=1.5, label="Original climatology")
    
    # Fitted harmonics
    ax.plot(t, data["fitted_ts"], data["color"], linewidth=2, label="Harmonic fit")
    
    # Residuals
    ax.plot(t, data["residual"], 'r-', alpha=0.6, linewidth=0.8, label="Residuals")
    
    # Mark seasons
    seasons = {
        "Jan 1": 0,
        "Apr 1": 90,
        "Jul 1": 181,
        "Oct 1": 273
    }
    for label, day in seasons.items():
        ax.axvline(day, color='gray', linestyle='--', alpha=0.5)
        ax.text(day, ax.get_ylim()[1]*0.95, label, ha='center', fontsize=10)
    
    # Set title and labels
    ax.set_title(f"{data['label']} - Precipitation Climatology and Harmonic Fit", fontsize=12)
    ax.set_xlabel("Day of Year (Jan 1 = 0)", fontsize=10)
    ax.set_ylabel("Precipitation (mm)", fontsize=10)
    ax.legend(loc='upper right')
    ax.grid(True, linestyle='--', alpha=0.7)
    
    # Add fitting equation information
    eq_text = f"Fitted equation: y = {data['coeffs'][0]:.2f} + "
    for j in range(1, 4):
        a, b = data['coeffs'][2*j-1], data['coeffs'][2*j]
        amp = np.sqrt(a**2 + b**2)
        phase = np.arctan2(b, a) * T / (2 * np.pi * j)
        eq_text += f"\n{amp:.2f}·cos(2πt/{T/j:.1f} + {phase:.1f})"
    
    ax.text(0.02, 0.95, eq_text, transform=ax.transAxes, 
            verticalalignment='top', fontsize=9, bbox=dict(facecolor='white', alpha=0.8))

plt.tight_layout()

# 5. Save results
print("\n====== Step 5/5: Saving Results ======")
output_path = os.path.join(output_dir, "harmonic_analysis_results.png")
plt.savefig(output_path, dpi=300)
print(f"Visualization saved to: {output_path}")

# Print total runtime
total_time = time.time() - start_time
hours, remainder = divmod(total_time, 3600)
minutes, seconds = divmod(remainder, 60)
print("\n====== Processing Complete! ======")
print(f"Total runtime: {int(hours)}h {int(minutes)}m {seconds:.1f}s")
print(f"Output file: {output_path}")
print(f"End time: {time.strftime('%Y-%m-%d %H:%M:%S')}")

# Display plot
plt.show()