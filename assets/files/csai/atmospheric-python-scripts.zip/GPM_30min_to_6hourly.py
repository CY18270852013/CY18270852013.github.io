import os
import h5py
import numpy as np
from datetime import datetime, timedelta
from netCDF4 import Dataset

# 配置路径
input_dir = r'\\DS1821\Observation\GPM'
output_dir = r'E:\GPM_6hourly_20090101_20231231'
os.makedirs(output_dir, exist_ok=True)

# 时间范围
start_date = datetime(2009, 1, 1)
end_date = datetime(2023, 12, 31)
time_offsets = ['00', '06', '12', '18']  # 6小时时段起始时间

# 预计算经纬度网格 (0.1°分辨率)
lons = np.arange(-179.95, 180, 0.1).round(2)
lats = np.arange(89.95, -90, -0.1).round(2)  # 从北到南

# 基准时间 (1980-01-06 UTC)
base_time = datetime(1980, 1, 6)

# 遍历每一天
current_date = start_date
while current_date <= end_date:
    date_str = current_date.strftime("%Y%m%d")
    print(f"Processing date: {date_str}")
    
    for offset in time_offsets:
        # 构建12个文件名
        file_paths = []
        valid_segment = True
        
        for i in range(12):
            # 计算半小时文件的起始时间
            hours = int(offset) + i // 2
            minutes = 30 * (i % 2)
            time_str = f"{hours:02d}{minutes:02d}00"
            
            # 计算结束时间 (29分59秒后)
            start_time = datetime.strptime(f"{date_str}{time_str}", "%Y%m%d%H%M%S")
            end_time = start_time + timedelta(minutes=29, seconds=59)
            end_time_str = end_time.strftime("%H%M%S")
            
            # 计算分钟偏移量
            total_minutes = hours * 60 + minutes
            minute_offset = f"{total_minutes:04d}"
            
            # 尝试V07A和V07B版本
            base_name = f"3B-HHR.MS.MRG.3IMERG.{date_str}-S{time_str}-E{end_time_str}.{minute_offset}"
            for version in ["V07A", "V07B"]:
                file_name = f"{base_name}.{version}.HDF5"
                file_path = os.path.join(input_dir, file_name)
                if os.path.exists(file_path):
                    file_paths.append(file_path)
                    break
            else:
                print(f"  !! Missing file: {base_name} (Skipping segment)")
                valid_segment = False
                break
        
        if not valid_segment or len(file_paths) != 12:
            continue  # 跳过不完整的时段
        
        # 初始化累积降水数组
        accum_precip = np.zeros((1800, 3600), dtype=np.float32)
        missing_mask = np.zeros((1800, 3600), dtype=bool)
        
        # 处理12个文件
        for file_path in file_paths:
            try:
                with h5py.File(file_path, 'r') as f:
                    # 正确读取并转置数据形状
                    precip_data = f['/Grid/precipitation'][:]
                    
                    # 处理可能的形状问题：(time, lat, lon) 或 (lat, lon, time)
                    if precip_data.shape == (1, 1800, 3600):
                        precip = precip_data[0, :, :]  # 形状 (1800, 3600)
                    elif precip_data.shape == (1, 3600, 1800):
                        precip = precip_data[0, :, :].T  # 转置为 (1800, 3600)
                    elif precip_data.shape == (1800, 3600, 1):
                        precip = precip_data[:, :, 0]  # 形状 (1800, 3600)
                    elif precip_data.shape == (3600, 1800, 1):
                        precip = precip_data[:, :, 0].T  # 转置为 (1800, 3600)
                    else:
                        raise ValueError(f"Unexpected data shape: {precip_data.shape}")
                    
                    # 处理缺测值并累积
                    valid_data = np.where(precip != -9999.9, precip * 0.5, 0)
                    accum_precip += valid_data
                    
                    # 更新缺测掩码
                    missing_mask |= (precip == -9999.9)
            except Exception as e:
                print(f"  !! Error reading {os.path.basename(file_path)}: {e}")
                missing_mask[:, :] = True  # 标记整个时段为缺测
                break
        
        # 应用缺测值
        accum_precip[missing_mask] = -9999.9
        
        # 构建输出文件名
        start_time_str = f"{date_str}{offset}0000"
        end_hour = int(offset) + 5
        end_time_str = f"{date_str}{end_hour:02d}5959"
        out_file = f"GPM_6hourly_{start_time_str}_{end_time_str}.nc"
        out_path = os.path.join(output_dir, out_file)
        
        # 创建NetCDF文件
        with Dataset(out_path, 'w', format='NETCDF4') as nc:
            # 全局属性
            nc.title = "GPM IMERG 6-Hourly Accumulated Precipitation"
            nc.source = "Converted from GPM half-hourly data"
            nc.history = f"Created on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            nc.Conventions = "CF-1.8"
            
            # 创建维度
            nc.createDimension('lon', 3600)
            nc.createDimension('lat', 1800)
            nc.createDimension('time', 1)
            
            # 时间变量 (使用第一个文件的起始时间)
            time_var = nc.createVariable('time', 'i4', ('time',))
            seg_start = datetime.strptime(start_time_str, "%Y%m%d%H%M%S")
            time_val = int((seg_start - base_time).total_seconds())
            time_var[:] = time_val
            time_var.units = "seconds since 1980-01-06 00:00:00 UTC"
            time_var.long_name = "Time"
            time_var.calendar = "julian"
            
            # 经度变量
            lon_var = nc.createVariable('lon', 'f4', ('lon',))
            lon_var[:] = lons
            lon_var.units = "degrees_east"
            lon_var.long_name = "Longitude"
            lon_var.standard_name = "longitude"
            
            # 纬度变量
            lat_var = nc.createVariable('lat', 'f4', ('lat',))
            lat_var[:] = lats
            lat_var.units = "degrees_north"
            lat_var.long_name = "Latitude"
            lat_var.standard_name = "latitude"
            
            # 降水变量
            fill_value = np.float32(-9999.9)  # 确保使用单精度浮点数
            precip_var = nc.createVariable('precipitation', 'f4', ('time', 'lat', 'lon'),
                                          fill_value=fill_value, zlib=True)
            precip_var[0, :, :] = accum_precip
            precip_var.units = "mm"
            precip_var.long_name = "6-hour accumulated precipitation"
            precip_var.missing_value = fill_value  # 使用相同的单精度值
        
        print(f"  Created: {out_file}")
    
    # 移动到下一天
    current_date += timedelta(days=1)

print("Processing completed!")