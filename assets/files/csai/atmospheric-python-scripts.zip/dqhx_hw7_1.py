# -*- coding: utf-8 -*-
"""
Created on Fri May 30 21:12:56 2025

@author: Chen Yong
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter

# 原始数据
intervals = [(0.1, 0.2), (0.2, 0.4), (0.4, 0.7), (0.7, 1.0),
            (1.0, 2.0), (2.0, 4.0), (4.0, 7.0), (7.0, 10.0), (10.0, 20.0)]
D_geo = [0.1414, 0.2828, 0.5292, 0.8367, 1.414, 2.828, 5.292, 8.637, 14.14]  # 几何平均直径 (μm)
N = [50, 460, 1055, 980, 1705, 680, 102, 10, 2]  # 粒子数

# 计算每个间隔的对数宽度 ΔlogD_p
d_logDp = [np.log10(upper) - np.log10(lower) for lower, upper in intervals]

# 计算 ΔN/ΔlogD_p
dN_dlogDp = [n / dlog for n, dlog in zip(N, d_logDp)]

# 计算 ΔS/ΔlogD_p (单个粒子表面积 = πD²)
dS_dlogDp = [n * np.pi * d**2 / dlog for n, d, dlog in zip(N, D_geo, d_logDp)]

# 计算 ΔV/ΔlogD_p (单个粒子体积 = πD³/6)
dV_dlogDp = [n * np.pi * d**3 / 6 / dlog for n, d, dlog in zip(N, D_geo, d_logDp)]

# 计算直方图的边界位置 (对数坐标)
bin_edges_log = np.log10([0.1, 0.2, 0.4, 0.7, 1.0, 2.0, 4.0, 7.0, 10.0, 20.0])
bin_centers_log = [(bin_edges_log[i] + bin_edges_log[i+1])/2 for i in range(len(bin_edges_log)-1)]
bin_centers = 10**np.array(bin_centers_log)  # 转换为线性坐标用于标签

# 创建包含三个子图的图表
fig, axes = plt.subplots(3, 1, figsize=(10, 12), sharex=True)
plt.subplots_adjust(hspace=0.1)

# 1. 绘制数浓度分布 ΔN/ΔlogD_p
ax = axes[0]
ax.bar(bin_edges_log[:-1], dN_dlogDp, width=np.diff(bin_edges_log), 
       align='edge', edgecolor='k', alpha=0.7)
ax.set_ylabel(r'$\Delta N / \Delta \log D_p$', fontsize=12)
ax.set_title('Particle Number Distribution')
ax.grid(True, linestyle='--', alpha=0.6)
ax.set_ylim(0, max(dN_dlogDp)*1.1)

# 2. 绘制表面积分布 ΔS/ΔlogD_p
ax = axes[1]
ax.bar(bin_edges_log[:-1], dS_dlogDp, width=np.diff(bin_edges_log), 
       align='edge', edgecolor='k', alpha=0.7, color='orange')
ax.set_ylabel(r'$\Delta S / \Delta \log D_p$ ($\mu m^2$)', fontsize=12)
ax.set_title('Surface Area Distribution')
ax.grid(True, linestyle='--', alpha=0.6)
ax.set_ylim(0, max(dS_dlogDp)*1.1)

# 3. 绘制体积分布 ΔV/ΔlogD_p
ax = axes[2]
ax.bar(bin_edges_log[:-1], dV_dlogDp, width=np.diff(bin_edges_log), 
       align='edge', edgecolor='k', alpha=0.7, color='green')
ax.set_ylabel(r'$\Delta V / \Delta \log D_p$ ($\mu m^3$)', fontsize=12)
ax.set_title('Volume Distribution')
ax.grid(True, linestyle='--', alpha=0.6)
ax.set_ylim(0, max(dV_dlogDp)*1.1)

# 设置公共X轴（对数坐标）
ax.set_xlabel('Particle Diameter $D_p$ ($\mu m$)', fontsize=12)
ax.set_xlim(bin_edges_log[0], bin_edges_log[-1])

# 设置对数坐标的刻度标签
tick_positions = np.log10([0.1, 0.2, 0.4, 0.7, 1, 2, 4, 7, 10, 20])
tick_labels = ['0.1', '0.2', '0.4', '0.7', '1', '2', '4', '7', '10', '20']
plt.xticks(tick_positions, tick_labels)

# 在条形上方添加数值标签
for i, (ax, data) in enumerate(zip(axes, [dN_dlogDp, dS_dlogDp, dV_dlogDp])):
    for j, val in enumerate(data):
        x_pos = bin_edges_log[j] + (bin_edges_log[j+1] - bin_edges_log[j])/2
        ax.text(x_pos, val*1.05, f'{val:.1f}', 
                ha='center', va='bottom', fontsize=8, rotation=0)

plt.suptitle('Aerosol Size Distribution Functions', fontsize=16)
plt.tight_layout()
plt.show()