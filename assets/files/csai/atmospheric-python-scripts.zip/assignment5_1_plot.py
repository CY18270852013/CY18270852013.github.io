# -*- coding: utf-8 -*-
"""
Created on Mon Nov 18 23:46:01 2024

@author: Chen Yong
"""

import matplotlib.pyplot as plt
import numpy as np

# 读取Fortran输出的条件数数据
data = np.loadtxt(r"C:\Users\Chen Yong\Desktop\Calculation_Mathod_Fortran_codes\condition_numbers.dat")
n = data[:, 0]
condition_numbers = data[:, 1]

# 绘制条件数曲线
plt.figure(figsize=(8, 6))
plt.plot(n, condition_numbers, marker='o', label='Condition Number')
plt.xlabel('Matrix Size (n)', fontsize=12)
plt.ylabel('Condition Number', fontsize=12)
plt.title('Condition Number of Hilbert Matrix vs. Matrix Size', fontsize=14)
plt.grid(True)
plt.legend()
plt.show()
