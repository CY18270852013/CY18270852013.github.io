# -*- coding: utf-8 -*-
"""
Created on Mon May  5 04:34:27 2025

@author: Dell
"""

import xarray as xr
import numpy as np
import matplotlib.pyplot as plt

# 1. 读取ERA5月平均数据
era5_path = r"D:\Freddy_ChenYong\Data\ERA5_monthly_averaged_data_on_pressure_levels.nc"
ds_era5 = xr.open_dataset(era5_path)

# 提取2023年2月数据（索引0对应2月）
q_feb = ds_era5['q'].isel(valid_time=0) * 1000  # kg/kg → g/kg
pressure_levels = ds_era5.pressure_level.values

# 2. 读取IBTrACS数据并提取Freddy路径
ibtracs_path = r"D:\Freddy_ChenYong\Data\IBTrACS.SI.v04r01.nc"
ds_ibtracs = xr.open_dataset(ibtracs_path)
freddy_sid = b'2023036S12117'

# 筛选Freddy数据
freddy_mask = ds_ibtracs['sid'] == freddy_sid
freddy_lon = ds_ibtracs['lon'].where(freddy_mask, drop=True).squeeze().values
freddy_lat = ds_ibtracs['lat'].where(freddy_mask, drop=True).squeeze().values

# 3. 沿Freddy路径提取比湿数据（空间插值）
q_along_track = []
for lat, lon in zip(freddy_lat, freddy_lon):
    lon_adj = lon % 360  # 确保经度在0-360范围内
    q_point = q_feb.sel(latitude=lat, longitude=lon_adj, method="nearest")
    q_along_track.append(q_point.values)

# 沿路径垂直平均
q_freddy = np.nanmean(q_along_track, axis=0)

# 4. 定义区域并提取数据（关键修正）
# (a) 西印度洋：50-70°E, 10°S-10°N (Jordan, 1958)
# 确保纬度顺序与数据一致（ERA5纬度从北到南排列）
q_west_indian = q_feb.sel(
    latitude=slice(10, -10),   # 从10°N到10°S
    longitude=slice(50, 70)
).mean(dim=['latitude', 'longitude'], skipna=True)

# (b) 热带北大西洋：55-15°W (305-345°E), 10-20°N (Dunion, 2011)
q_tna = q_feb.sel(
    latitude=slice(20, 10),    # 从20°N到10°N（因纬度降序排列）
    longitude=slice(305, 345)
).mean(dim=['latitude', 'longitude'], skipna=True)

# 5. 绘图设置
plt.figure(figsize=(8, 10))
ax = plt.gca()

# 绘制三条廓线
ax.plot(q_freddy, pressure_levels, 'k-', linewidth=2, label='Freddy track')
ax.plot(q_west_indian, pressure_levels, 'r-', linewidth=2, label='Western Indian')
ax.plot(q_tna, pressure_levels, 'b-', linewidth=2, label='Tropical North Atlantic')

# 坐标轴设置
ax.set_yscale('log')
ax.invert_yaxis()
ax.set_yticks([1000, 925, 850, 700, 600, 500, 400])
ax.set_yticklabels(['1000', '925', '850', '700', '600', '500', '400'])
ax.set_ylim(1000, 400)  # 纵轴范围1000-400 hPa
ax.set_xlim(0, 20)

ax.set_xlabel('Specific Humidity (g kg$^{-1}$)', fontsize=12)
ax.set_ylabel('Pressure (hPa)', fontsize=12)
ax.tick_params(axis='both', labelsize=10)
ax.grid(linestyle='--', alpha=0.5)

# 添加图例和标题
ax.legend(loc='upper right', frameon=False, fontsize=10)
plt.title('Specific Humidity Profiles - February 2023', fontsize=14, pad=20)

# 保存图片
plt.savefig('specific_humidity_profile_corrected.png', dpi=300, bbox_inches='tight')
plt.close()