import numpy as np
import matplotlib.pyplot as plt

# 文件路径
file_path = r'C:\Users\Chen Yong\Desktop\result1.txt'

# 读取数据
data = np.loadtxt(file_path)

# 提取x和z数据
x = data[:, 0]
z = data[:, 2]

# 绘制x-z平面轨线分布图
plt.figure(figsize=(10, 6))
plt.plot(x, z, label="Trajectory in x-z plane", color='b')

# 设置标题和标签
plt.title("Lorenz System Trajectory in x-z Plane")
plt.xlabel("x")
plt.ylabel("z")
plt.legend()
plt.grid()

# 显示图形
plt.show()
