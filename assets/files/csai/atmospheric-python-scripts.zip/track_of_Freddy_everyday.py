import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from datetime import datetime, timezone
import numpy as np
import warnings
from cartopy.io import DownloadWarning

# 禁用cartopy的下载警告
warnings.filterwarnings("ignore", category=DownloadWarning)

# 读取NetCDF文件
file_path = 'D:\Freddy_ChenYong\Data\IBTrACS.SI.v04r01.nc'
data = xr.open_dataset(file_path)

# 找到FREDDY热带气旋的数据
freddy_sid = b'2023036S12117'  # FREDDY的sid
freddy_data = data.sel(storm=(data['sid'] == freddy_sid))

# 检查是否找到FREDDY的数据
if freddy_data.sizes['storm'] == 0:
    raise ValueError(f"未找到sid为 {freddy_sid} 的热带气旋数据。")

# 获取FREDDY的时间和经纬度数据
times = freddy_data['time'].values
lats = freddy_data['lat'].values
lons = freddy_data['lon'].values

# 过滤掉无效的时间和数据
valid_indices = ~np.isnat(times) & ~np.isnan(lats) & ~np.isnan(lons)
times = times[valid_indices]
lats = lats[valid_indices]
lons = lons[valid_indices]

# 将时间转换为datetime对象
times = [datetime.fromtimestamp(t.astype('O')/1e9, tz=timezone.utc) for t in times]

# 找到FREDDY的起始日期
start_date = datetime(2023, 2, 4, tzinfo=timezone.utc)

# 循环绘制每一天的路径图
for i in range(len(times)):
    current_date = times[i].date()
    if current_date < start_date.date():
        continue
    
    # 创建地图
    fig = plt.figure(figsize=(10, 6))
    ax = plt.axes(projection=ccrs.PlateCarree())
    ax.add_feature(cfeature.COASTLINE)
    ax.add_feature(cfeature.BORDERS, linestyle=':')
    ax.add_feature(cfeature.LAND, edgecolor='black')
    ax.add_feature(cfeature.OCEAN)
    
    # 绘制FREDDY的路径
    ax.plot(lons[:i+1], lats[:i+1], color='red', marker='o', markersize=4, transform=ccrs.PlateCarree())
    
    # 设置地图范围
    ax.set_extent([min(lons[:i+1]) - 5, max(lons[:i+1]) + 5, min(lats[:i+1]) - 5, max(lats[:i+1]) + 5], crs=ccrs.PlateCarree())
    
    # 添加标题
    plt.title(f"Tropical Cyclone FREDDY Path - {current_date.strftime('%Y-%m-%d')}")
    
    # 保存图像
    #plt.savefig(f"freddy_path_{current_date.strftime('%Y%m%d')}.png", dpi=300)
    plt.show()
    plt.close()

# 关闭数据集
data.close()