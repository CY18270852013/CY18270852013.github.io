import os
import re

# 定义文件夹路径
folder_path = r'C:\Users\Dell\Desktop\equipotential_height'

# 正则表达式匹配文件名，例如：Figure 2024-10-13 220116 (0).png
pattern = r'Figure \d{4}-\d{2}-\d{2} \d{6} \((\d+)\)\.png'


# 获取文件夹下的所有文件名，并按匹配到的序号排序
files = [f for f in os.listdir(folder_path) if re.match(pattern, f)]
files.sort(key=lambda x: int(re.search(pattern, x).group(1)))

# 遍历并重命名文件
for file in files:
    # 提取文件中的序号
    match = re.search(pattern, file)
    if match:
        index = int(match.group(1))
        old_path = os.path.join(folder_path, file)
        new_filename = f'{index}.png'
        new_path = os.path.join(folder_path, new_filename)
        
        # 重命名文件
        os.rename(old_path, new_path)
        print(f'Renamed: {file} -> {new_filename}')

print("文件重命名完成！")
