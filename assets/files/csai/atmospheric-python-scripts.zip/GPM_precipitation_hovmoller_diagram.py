import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime, timedelta
import matplotlib.ticker as ticker

# 设置全局字体
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 12

# 1. 读取数据并检查纬度范围
def load_data(file_path, var_name=None):
    ds = xr.open_dataset(file_path)
    if var_name:
        data = ds[var_name]
        return data
    return ds

print("加载数据...")
precip_anom = load_data('E:/GPM_anomaly_6hours_accumulated/GPM_anomaly_20230101_20230331.nc', 'precipitation_anomaly')
mjo_anom = load_data('E:/GPM_anomaly_6hours_accumulated/GPM_anomaly_for_MJO_20230101_20230331.nc', 'mjo')
kelvin_anom = load_data('E:/GPM_anomaly_6hours_accumulated/GPM_anomaly_for_Kelvin_20230101_20230331.nc', 'kelvin')
mrg_anom = load_data('E:/GPM_anomaly_6hours_accumulated/GPM_anomaly_for_MRG_20230101_20230331.nc', 'mrg')
er_anom = load_data('E:/GPM_anomaly_6hours_accumulated/GPM_anomaly_for_ER_20230101_20230331.nc', 'er')

# 2. 设置时间和空间范围
start_date = datetime(2023, 1, 15)
end_date = datetime(2023, 3, 15)
lon_range = slice(80, 180)

# 3. 创建纬度带数据集
def prepare_data(ds, lat_min, lat_max):
    # 确保纬度顺序正确（南纬为负）
    if ds.lat[0] > ds.lat[-1]:
        ds = ds.sortby('lat', ascending=True)
    
    # 选择纬度范围
    ds_slice = ds.sel(
        time=slice(start_date, end_date),
        lon=lon_range,
        lat=slice(lat_min, lat_max)
    )
    
    # 应用纬度平均
    ds_avg = ds_slice.mean(dim='lat', skipna=True)
    return ds_avg

# 第一纬度带: 5°S ~ 15°S (南纬为负值)
print("准备第一纬度带数据 (5°S ~ 15°S)...")
domain1 = {
    'precip': prepare_data(precip_anom, -15, -5),
    'mjo': prepare_data(mjo_anom, -15, -5),
    'kelvin': prepare_data(kelvin_anom, -15, -5),
    'mrg': prepare_data(mrg_anom, -15, -5),
    'er': prepare_data(er_anom, -15, -5)
}

# 第二纬度带: 15°S ~ 25°S (南纬为负值)
print("准备第二纬度带数据 (15°S ~ 25°S)...")
domain2 = {
    'precip': prepare_data(precip_anom, -25, -15),
    'mjo': prepare_data(mjo_anom, -25, -15),
    'kelvin': prepare_data(kelvin_anom, -25, -15),
    'mrg': prepare_data(mrg_anom, -25, -15),
    'er': prepare_data(er_anom, -25, -15)
}

# 第三纬度带: 10°S ~ 20°S (南纬为负值)
print("准备第二纬度带数据 (10°S ~ 20°S)...")
domain3 = {
    'precip': prepare_data(precip_anom, -20, -10),
    'mjo': prepare_data(mjo_anom, -20, -10),
    'kelvin': prepare_data(kelvin_anom, -20, -10),
    'mrg': prepare_data(mrg_anom, -20, -10),
    'er': prepare_data(er_anom, -20, -10)
}

# 4. 创建Hovmöller图函数
def plot_hovmoller(data, title, ax, add_label=False):
    # 准备网格数据
    lon = data['precip'].lon.values
    time = data['precip'].time.values
    
    # 创建网格
    X, Y = np.meshgrid(lon, time)
    
    # 绘制降水异常填色图（缩小颜色范围）
    pcm = ax.pcolormesh(
        X, Y, 
        data['precip'].values,
        cmap='RdYlBu_r',  # 使用红蓝对比色
        vmin=-8, vmax=8,  # 缩小范围以增强细节 [-8,8]
        shading='auto'
    )
    
    # 设置等值线
    main_contour_levels = np.arange(1, 10, 2)  # 0,2,4,6,8
    
    # MJO (黑色实线)
    cs_mjo_main = ax.contour(
        X, Y,
        data['mjo'].values,
        levels=main_contour_levels,
        colors='black',
        linewidths=2.5,
        linestyles='solid'
    )
    # 添加标注
    ax.clabel(cs_mjo_main, inline=True, fontsize=9, fmt='%1.0f')
    
    # Kelvin波 (蓝色实线)
    cs_kelvin_main = ax.contour(
        X, Y,
        data['kelvin'].values,
        levels=main_contour_levels,
        colors='blue',
        linewidths=2.5,
        linestyles='solid'
    )
    ax.clabel(cs_kelvin_main, inline=True, fontsize=9, fmt='%1.0f')
    
    # ER波 (红色实线)
    cs_er_main = ax.contour(
        X, Y,
        data['er'].values,
        levels=main_contour_levels,
        colors='red',
        linewidths=2.5,
        linestyles='solid'
    )
    ax.clabel(cs_er_main, inline=True, fontsize=9, fmt='%1.0f')
    
    # MRG波 (灰色实线)
    cs_mrg_main = ax.contour(
        X, Y,
        data['mrg'].values,
        levels=main_contour_levels,
        colors='gray',
        linewidths=2.5,
        linestyles='solid'
    )
    ax.clabel(cs_mrg_main, inline=True, fontsize=9, fmt='%1.0f')
    
    # 标注Freddy生成位置（2月4-8日）
    genesis_time_start = np.datetime64('2023-02-04T00:00:00')
    genesis_time_end = np.datetime64('2023-02-08T00:00:00')
    genesis_lon_start, genesis_lon_end = 110, 120
    
    # 绘制粉红色方框
    ax.plot(
        [genesis_lon_start, genesis_lon_end, genesis_lon_end, genesis_lon_start, genesis_lon_start],
        [genesis_time_start, genesis_time_start, genesis_time_end, genesis_time_end, genesis_time_start],
        color='magenta',
        linewidth=2.5
    )
    
    # 添加箭头和文本 
    ax.annotate('Freddy Genesis', 
        xy=((genesis_lon_start+genesis_lon_end)/2, genesis_time_start), 
        xytext=((genesis_lon_start+genesis_lon_end)/2, genesis_time_start - np.timedelta64(3, 'D')),
        arrowprops=dict(facecolor='magenta', shrink=0.05, width=1.5, headwidth=8),
        ha='center', color='magenta', fontsize=11, weight='bold')
    
    # 设置坐标轴
    ax.set_title(title, fontsize=14, pad=10)
    ax.set_xlabel('Longitude (°E)', fontsize=12)
    ax.set_ylabel('Date', fontsize=12)
    ax.set_xlim(80, 180)
    
    # 设置时间轴格式
    ax.yaxis.set_major_locator(mdates.DayLocator(interval=2))
    ax.yaxis.set_major_formatter(mdates.DateFormatter('%m-%d'))
    ax.tick_params(axis='both', which='major', labelsize=10)
    
    # 添加网格
    ax.grid(True, linestyle='--', alpha=0.3)
    
    return pcm

# 5. 绘制第一纬度带 (5°S ~ 15°S)
print("绘制第一纬度带图像...")
fig1, ax1 = plt.subplots(figsize=(14, 8), dpi=300)
pcm1 = plot_hovmoller(domain1, 'a) Precipitation Anomalies and Wave Activity (5°S-15°S)', ax1, add_label=True)

# 添加颜色条
cbar1 = fig1.colorbar(pcm1, ax=ax1, extend='both')
cbar1.set_label('Precipitation Anomaly (mm)', fontsize=12)
cbar1.ax.tick_params(labelsize=10)

# 添加图例
legend_elements = [
    plt.Line2D([0], [0], color='black', lw=1.8, label='MJO'),
    plt.Line2D([0], [0], color='blue', lw=1.4, label='Kelvin Wave'),
    plt.Line2D([0], [0], color='red', lw=1.4, label='ER Wave'),
    plt.Line2D([0], [0], color='gray', lw=1.4, label='MRG Wave'),
    plt.Line2D([0], [0], color='magenta', lw=2.5, label='Freddy Genesis (Feb 4-8)')
]
fig1.legend(handles=legend_elements, loc='upper center', 
           bbox_to_anchor=(0.5, 0.05), ncol=5, fontsize=11)

plt.tight_layout(rect=[0, 0.05, 1, 0.95])
plt.savefig(r'D:\Freddy_ChenYong\Plot_ChenYong\GPM_precipitation_hovmoller_diagram\Hovmoller_Diagram_Freddy_Domain1.png', bbox_inches='tight', dpi=300)
print("第一纬度带图像保存成功")

# 6. 绘制第二纬度带 (15°S ~ 25°S)
print("绘制第二纬度带图像...")
fig2, ax2 = plt.subplots(figsize=(14, 8), dpi=300)
pcm2 = plot_hovmoller(domain2, 'b) Precipitation Anomalies and Wave Activity (15°S-25°S)', ax2)

# 添加颜色条
cbar2 = fig2.colorbar(pcm2, ax=ax2, extend='both')
cbar2.set_label('Precipitation Anomaly (mm)', fontsize=12)
cbar2.ax.tick_params(labelsize=10)

# 添加图例
fig2.legend(handles=legend_elements, loc='upper center', 
           bbox_to_anchor=(0.5, 0.05), ncol=5, fontsize=11)

plt.tight_layout(rect=[0, 0.05, 1, 0.95])
plt.savefig(r'D:\Freddy_ChenYong\Plot_ChenYong\GPM_precipitation_hovmoller_diagram\Hovmoller_Diagram_Freddy_Domain2.png', bbox_inches='tight', dpi=300)
print("第二纬度带图像保存成功")

# 7. 绘制第二纬度带 (10°S ~ 20°S)
print("绘制第三纬度带图像...")
fig3, ax3 = plt.subplots(figsize=(14, 8), dpi=300)
pcm3 = plot_hovmoller(domain3, 'c) Precipitation Anomalies and Wave Activity (10°S-20°S)', ax3)

# 添加颜色条
cbar3 = fig3.colorbar(pcm3, ax=ax3, extend='both')
cbar3.set_label('Precipitation Anomaly (mm)', fontsize=12)
cbar3.ax.tick_params(labelsize=10)

# 添加图例
fig3.legend(handles=legend_elements, loc='upper center', 
           bbox_to_anchor=(0.5, 0.05), ncol=5, fontsize=11)

plt.tight_layout(rect=[0, 0.05, 1, 0.95])
plt.savefig(r'D:\Freddy_ChenYong\Plot_ChenYong\GPM_precipitation_hovmoller_diagram\Hovmoller_Diagram_Freddy_Domain3.png', bbox_inches='tight', dpi=300)
print("第二纬度带图像保存成功")

plt.show()