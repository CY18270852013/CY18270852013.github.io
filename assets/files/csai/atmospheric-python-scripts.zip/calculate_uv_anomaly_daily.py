import numpy as np
import xarray as xr
import pandas as pd
from datetime import datetime
import time
import dask
import warnings

# 禁用不必要的警告
warnings.filterwarnings('ignore', category=RuntimeWarning)

# 记录开始时间
start_time = time.time()
print(f"程序开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print("="*80)

# 定义常量
T = 365.2425  # 平均年长度（天）
start_date_clim = datetime(2009, 1, 1)
start_date_target = datetime(2023, 1, 1)
end_date_target = datetime(2023, 3, 31)

print(f"计算参数设置:")
print(f"- 气候态参考期: {start_date_clim.strftime('%Y-%m-%d')} 至 2023-12-31")
print(f"- 目标分析期: {start_date_target.strftime('%Y-%m-%d')} 至 {end_date_target.strftime('%Y-%m-%d')}")
print(f"- 使用前三阶年谐波 (周期: 1年, 半年, 4个月)")
print(f"- 平均年长度: {T:.4f} 天")
print("="*80)

# 打开数据集
print("步骤1/6: 加载原始数据集...")
print(f"  文件路径: E:/u_v_daily/u_v_daily_20090101_20231231.nc")
ds = xr.open_dataset(
    "E:/u_v_daily/u_v_daily_20090101_20231231.nc",
    chunks={'time': 100, 'longitude': 180, 'latitude': 40}
)

# 打印数据集信息
print(f"  数据集加载完成，包含:")
print(f"  - 时间维度: {len(ds.time)} 个时间点 (2009-01-01 至 2023-12-31)")
print(f"  - 气压层: {len(ds.pressure_level)} 层 ({ds.pressure_level.values.min()} 至 {ds.pressure_level.values.max()} hPa)")
print(f"  - 纬度范围: {ds.latitude.values.min()}°S 至 {ds.latitude.values.max()}°N")
print(f"  - 经度范围: {ds.longitude.values.min()}°E 至 {ds.longitude.values.max()}°E")
print(f"  - 变量: u_daily_mean, v_daily_mean")
print("="*80)

# 时间处理函数
def get_day_of_year(dates, reference_date):
    """计算日期序列相对于参考日期的年日序数"""
    dates_pd = pd.to_datetime(dates)
    days_since_ref = (dates_pd - pd.Timestamp(reference_date)).days.values
    return days_since_ref

# 计算气候态时间段的时间序列
print("步骤2/6: 计算气候态时间序列...")
time_clim = ds.time.values
t_clim = get_day_of_year(time_clim, start_date_clim)
print(f"  计算完成，时间序列长度: {len(t_clim)} 天")
print("="*80)

# 构建谐波基函数设计矩阵
print("步骤3/6: 构建谐波基函数设计矩阵...")
X = np.column_stack([
    np.ones(len(t_clim)),
    np.cos(2 * np.pi * t_clim / T),
    np.sin(2 * np.pi * t_clim / T),
    np.cos(4 * np.pi * t_clim / T),
    np.sin(4 * np.pi * t_clim / T),
    np.cos(6 * np.pi * t_clim / T),
    np.sin(6 * np.pi * t_clim / T)
])
print(f"  设计矩阵形状: {X.shape} (时间点 × 谐波系数)")
print("="*80)

# 计算目标时间段
print("步骤4/6: 准备目标时间段数据...")
ds_target = ds.sel(time=slice(start_date_target, end_date_target))
time_target = ds_target.time.values
t_target = get_day_of_year(time_target, start_date_clim)
print(f"  目标时间段: {len(ds_target.time)} 天")

# 构建目标时间段的设计矩阵
X_target = np.column_stack([
    np.ones(len(t_target)),
    np.cos(2 * np.pi * t_target / T),
    np.sin(2 * np.pi * t_target / T),
    np.cos(4 * np.pi * t_target / T),
    np.sin(4 * np.pi * t_target / T),
    np.cos(6 * np.pi * t_target / T),
    np.sin(6 * np.pi * t_target / T)
])
print(f"  目标设计矩阵形状: {X_target.shape}")
print("="*80)

# 计算伪逆矩阵（大幅加速计算）
print("步骤5/6: 计算伪逆矩阵...")
pinv_start = time.time()
# 使用SVD计算伪逆矩阵，避免直接求逆
U, s, VT = np.linalg.svd(X, full_matrices=False)
s_inv = np.zeros_like(s)
s_inv[s > 1e-10] = 1.0 / s[s > 1e-10]  # 避免除以零
X_pinv = VT.T @ np.diag(s_inv) @ U.T
print(f"  伪逆矩阵计算完成，耗时: {time.time() - pinv_start:.2f} 秒")
print("="*80)

# 定义向量化拟合函数
def vectorized_fit_harmonics(data, X, X_pinv):
    """向量化计算谐波系数"""
    # 重塑数据为 (time, space)
    n_time, n_level, n_lat, n_lon = data.shape
    flat_data = data.data.reshape(n_time, -1)
    
    # 使用伪逆矩阵计算系数
    coeffs = X_pinv @ flat_data
    
    # 计算目标时间段的季节循环值
    climatology = X_target @ coeffs
    
    # 计算异常值
    target_flat = data.sel(time=slice(start_date_target, end_date_target)).data.reshape(len(t_target), -1)
    anomaly_flat = target_flat - climatology
    
    # 恢复原始形状
    return anomaly_flat.reshape((len(t_target), n_level, n_lat, n_lon))

# 计算u分量异常值
print("计算u分量异常值...")
u_start = time.time()
u_anomaly = vectorized_fit_harmonics(ds.u_daily_mean, X, X_pinv)
print(f"  u分量异常值计算完成，耗时: {time.time() - u_start:.2f} 秒")

# 计算v分量异常值
print("计算v分量异常值...")
v_start = time.time()
v_anomaly = vectorized_fit_harmonics(ds.v_daily_mean, X, X_pinv)
print(f"  v分量异常值计算完成，耗时: {time.time() - v_start:.2f} 秒")
print("="*80)

# 创建新的数据集
print("步骤6/6: 创建输出数据集...")
ds_anomaly = xr.Dataset(
    {
        'u_anomaly_daily': (['time', 'pressure_level', 'latitude', 'longitude'], u_anomaly),
        'v_anomaly_daily': (['time', 'pressure_level', 'latitude', 'longitude'], v_anomaly)
    },
    coords={
        'time': ds_target.time,
        'pressure_level': ds.pressure_level,
        'latitude': ds.latitude,
        'longitude': ds.longitude
    }
)

# 设置变量属性
ds_anomaly.u_anomaly_daily.attrs = {
    'units': 'm s**-1',
    'long_name': 'Daily anomaly of eastward wind component',
    'description': 'Anomaly calculated by removing first three annual harmonics'
}
ds_anomaly.v_anomaly_daily.attrs = {
    'units': 'm s**-1',
    'long_name': 'Daily anomaly of northward wind component',
    'description': 'Anomaly calculated by removing first three annual harmonics'
}

# 设置全局属性
ds_anomaly.attrs = {
    'title': 'Wind Component Anomalies',
    'institution': 'Generated from ERA5 data',
    'source': 'ERA5 reanalysis',
    'history': f'Created on {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}',
    'reference': 'Method based on Latos et al. (2023) Nature Communications',
    'period': f'{start_date_target.strftime("%Y-%m-%d")} to {end_date_target.strftime("%Y-%m-%d")}',
    'climatology_period': f'{start_date_clim.strftime("%Y-%m-%d")} to 2023-12-31',
    'method': 'Anomalies calculated by removing first three annual harmonics',
    'computation_time': f'{(time.time() - start_time):.1f} seconds',
    'optimization': 'Vectorized computation using pseudo-inverse'
}

# 保存结果
output_path = "E:/u_v_daily/u_v_anomaly_daily_20230101_20230331.nc"
print(f"\n保存结果到: {output_path}")
ds_anomaly.to_netcdf(output_path)

# 最终总结
total_time = time.time() - start_time
print("\n" + "="*80)
print("处理完成!")
print(f"总耗时: {total_time:.1f} 秒 ({total_time/60:.1f} 分钟)")
print(f"输出文件信息:")
print(f"- 时间点: {len(ds_anomaly.time)} (2023-01-01 至 2023-03-31)")
print(f"- 气压层: {len(ds_anomaly.pressure_level)} 层")
print(f"- 纬度范围: {ds_anomaly.latitude.values.min()}°S 至 {ds_anomaly.latitude.values.max()}°N")
print(f"- 经度范围: {ds_anomaly.longitude.values.min()}°E 至 {ds_anomaly.longitude.values.max()}°E")
print(f"- 变量: u_anomaly_daily, v_anomaly_daily")
print("="*80)