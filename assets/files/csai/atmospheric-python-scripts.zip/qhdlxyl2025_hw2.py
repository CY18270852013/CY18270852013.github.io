# -*- coding: utf-8 -*-
"""
Created on Wed Apr  2 20:39:41 2025

@author: Chen Yong
"""

import numpy as np
import matplotlib.pyplot as plt

# 参数设置
L = 1  # 加热区半宽（单位：无量纲，对应约10个纬度距）
k = np.pi / (2 * L)  # 波数

# 生成网格
x = np.linspace(-2*L, 2*L, 200)
y = np.linspace(-5, 5, 200)
X, Y = np.meshgrid(x, y)

# 计算加热函数F(x)
F_x = np.where(np.abs(X) <= L, np.cos(k * X), 0)  # 在|x|<=L时为cos(kx)，否则为0

# 计算对称加热Qs和反对称加热Qas
D0 = np.exp(-Y**2 / 4)         # 对称基底函数D0(y)
D1 = Y * np.exp(-Y**2 / 4)     # 反对称基底函数D1(y)
Qs = F_x * D0                  # 对称加热场
Qas = F_x * D1                 # 反对称加热场

# 绘图设置
fig, axes = plt.subplots(1, 2, figsize=(12, 5), sharey=True)
cmap = 'RdBu_r'  # 红蓝颜色图，负值蓝色，正值红色

# 对称加热场Qs
c1 = axes[0].contourf(X, Y, Qs, levels=20, cmap=cmap, vmin=-1, vmax=1)
plt.colorbar(c1, ax=axes[0], label='Heating (Qs)')
axes[0].set_title('Symmetric Heating (Qs)')
axes[0].set_xlabel('x (L=1)')
axes[0].set_ylabel('y')
axes[0].axvline(x=L, color='k', linestyle='--', linewidth=0.5)  # 标记加热区边界
axes[0].axvline(x=-L, color='k', linestyle='--', linewidth=0.5)

# 反对称加热场Qas
c2 = axes[1].contourf(X, Y, Qas, levels=20, cmap=cmap, vmin=-1, vmax=1)
plt.colorbar(c2, ax=axes[1], label='Heating (Qas)')
axes[1].set_title('Antisymmetric Heating (Qas)')
axes[1].set_xlabel('x (L=1)')
axes[1].axvline(x=L, color='k', linestyle='--', linewidth=0.5)
axes[1].axvline(x=-L, color='k', linestyle='--', linewidth=0.5)

plt.tight_layout()
plt.show()