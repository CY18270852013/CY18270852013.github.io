# -*- coding: utf-8 -*-
"""
Created on Mon Apr  7 08:21:51 2025

@author: Chen Yong
"""

import numpy as np
import matplotlib.pyplot as plt

# 参数设置
c = 20.0  # 平流速度 (m/s)
dx = 400  # 空间步长 (m)
dt = 2    # 时间步长 (s)
nx = 360  # 空间网格数
tbar = 360  # 时间间隔个数

# 空间网格 (闭合圈，等分为360份)
x = np.linspace(-180, 180, nx, endpoint=False)

# 初始条件
u0 = np.where(x < 0, 0, 1)  # x<0时赋值为0，否则为1
    
# 初始化数值解和存储数组
u = u0.copy()
u_new = np.zeros(nx)
u_history = np.zeros((tbar + 1, nx))  # 存储所有时间步的风速

# 迭代求解并保存历史数据
for n in range(tbar + 1):
    for m in range(nx):
        m_prev = (m - 1) % nx
        m_next = (m + 1) % nx
        u_new[m] = u[m] - c * dt / (2 * dx) * (u[m_next] - u[m_prev])  # 中央差分
    u = u_new.copy()
    u_history[n, :] = u  # 保存当前时间步的结果

plt.figure(figsize=(15, 20))
for i, t in enumerate(range(0, 361, 30)):
    plt.subplot(7, 2, i + 1)
    
    plt.plot(x, u_history[t, :])
    plt.xlabel('x')
    plt.ylabel('u(m/s)')
    plt.title(f'tbar = {t}')
    # plt.legend()
    plt.grid(linestyle='--', alpha=0.5)
    plt.ylim(-0.5, 1.5)

plt.tight_layout()
plt.show()