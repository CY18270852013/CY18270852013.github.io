# -*- coding: utf-8 -*-
"""
Created on Fri Oct 31 16:53:43 2025

@author: Chen Yong
"""

import netCDF4 as nc
import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs

file_path = r'C:\Users\Chen Yong\Downloads\IBTrACS.SI.v04r01.nc'
ds = nc.Dataset(file_path, 'r')
print("文件格式：", ds.file_format)
print("维度信息：", ds.dimensions.keys(), '\n')
# print("变量列表：", list(ds.variables.keys()))
name = ds.variables['name'][:]
# print(name)
lat = ds.variables['lat'][:]
lon = ds.variables['lon'][:]
time = ds.variables['time'][:]
# print(time)
wmo_wind = ds.variables['wmo_wind'][:]
fig = plt.figure(figsize = (12, 8))
ax = plt.axes(projection = ccrs.PlateCarree())
