# -*- coding: utf-8 -*-
"""
Created on Tue Mar 11 18:53:30 2025

@author: Dell
"""

import h5py

# 读取 .mat 文件
with h5py.File(r"D:\MATLAB\Freddy\w_mjo.mat", 'r') as file:
    # 查看文件内容
    print(list(file.keys()))

    # 提取具体变量
    variable_name = 'w_mjo'  # 替换为 .mat 文件中的变量名
    variable_data = file[variable_name][()]  # 获取数据

    print(variable_data)