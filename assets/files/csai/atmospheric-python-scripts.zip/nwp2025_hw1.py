# -*- coding: utf-8 -*-
"""
Created on Mon Feb 24 08:36:43 2025

@author: Chen Yong
"""

import xarray as xr
import numpy as np
import matplotlib.pyplot as plt

ds = xr.open_dataset(r'C:\Users\Chen Yong\Desktop\数值天气预报上机实习\data_hw1\data\NetCDF\ELat.198101-201012.clt.nc')
uwnd = ds['uwnd']
vwnd = ds['vwnd']
hgt = ds['hgt']
airtemp = ['air']
