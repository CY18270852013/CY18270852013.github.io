import xarray as xr
import matplotlib.pyplot as plt
import os
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from datetime import datetime
import numpy as np

# 读取数据
file_path = "D:\\MATLAB\\Freddy\\Initial_phase_environmental_field.nc"
ds = xr.open_dataset(file_path)

# 设置绘图范围
lat_range = (0, -40)  # 数据筛选范围：从赤道到南纬40°
lon_range = (25, 130)
time_range = ('2023-02-01', '2023-03-31')

# 筛选数据
ds = ds.sel(latitude=slice(*lat_range), longitude=slice(*lon_range), valid_time=slice(*time_range))

# 创建保存图像的文件夹
os.makedirs("C:\\Users\\Dell\\Desktop\\uv_850hPa", exist_ok=True)
os.makedirs("C:\\Users\\Dell\\Desktop\\uv_200hPa", exist_ok=True)

# 格式化时间戳为合法的文件名
def format_filename(time):
    return time.dt.strftime("%Y-%m-%d_%H-%M-%S").values

# 设置降采样间隔
stride = 8  # 每隔8个点取一个数据点

# 设置箭头缩放比例（更大的值会使箭头更短）
arrow_scale = 300  # 增大 scale 值以使箭头更短

# 绘制850hPa风场
for time in ds.valid_time:
    u_850 = ds.u.sel(pressure_level=850, valid_time=time)
    v_850 = ds.v.sel(pressure_level=850, valid_time=time)
    
    fig = plt.figure(figsize=(12, 8))
    ax = plt.axes(projection=ccrs.PlateCarree())
    
    # 添加地图背景
    ax.set_facecolor('white')  # 设置背景为白色
    ax.add_feature(cfeature.LAND, edgecolor='black')  # 添加陆地边界
    ax.add_feature(cfeature.OCEAN, edgecolor='black')  # 添加海洋边界
    ax.add_feature(cfeature.COASTLINE, linewidth=0.5)  # 添加海岸线
    ax.add_feature(cfeature.BORDERS, linestyle=':', linewidth=0.5)  # 添加国界线
    
    # 降采样数据
    lon_subset = ds.longitude.values[::stride]
    lat_subset = ds.latitude.values[::stride]
    u_subset = u_850.values[::stride, ::stride]
    v_subset = v_850.values[::stride, ::stride]
    
    # 绘制箭头表示的流场
    Q = ax.quiver(lon_subset, lat_subset, u_subset, v_subset, scale=arrow_scale, width=0.001, color='black')  # 调整箭头宽度
    ax.quiverkey(Q, X=0.9, Y=1.05, U=10, label='10 m/s', labelpos='E')
    
    # 添加经纬网
    gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=0.5, color='gray', alpha=0.5)
    gl.top_labels = False
    gl.right_labels = False
    
    ax.set_title(f"850hPa Wind Field at {time.values}")
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_xlim(lon_range)  # 经度范围不变
    ax.set_ylim((-40, 0))  # 翻转纬度轴，从上到下表示从赤道到南纬40°
    
    # 格式化文件名并保存
    filename = format_filename(time)
    plt.savefig(f"C:\\Users\\Dell\\Desktop\\uv_850hPa\\{filename}.png", dpi=300, bbox_inches='tight')
    plt.close()

# 绘制200hPa风场
for time in ds.valid_time:
    u_200 = ds.u.sel(pressure_level=200, valid_time=time)
    v_200 = ds.v.sel(pressure_level=200, valid_time=time)
    
    fig = plt.figure(figsize=(12, 8))
    ax = plt.axes(projection=ccrs.PlateCarree())
    
    # 添加地图背景
    ax.set_facecolor('white')  # 设置背景为白色
    ax.add_feature(cfeature.LAND, edgecolor='black')  # 添加陆地边界
    ax.add_feature(cfeature.OCEAN, edgecolor='black')  # 添加海洋边界
    ax.add_feature(cfeature.COASTLINE, linewidth=0.5)  # 添加海岸线
    ax.add_feature(cfeature.BORDERS, linestyle=':', linewidth=0.5)  # 添加国界线
    
    # 降采样数据
    lon_subset = ds.longitude.values[::stride]
    lat_subset = ds.latitude.values[::stride]
    u_subset = u_200.values[::stride, ::stride]
    v_subset = v_200.values[::stride, ::stride]
    
    # 绘制箭头表示的流场
    Q = ax.quiver(lon_subset, lat_subset, u_subset, v_subset, scale=arrow_scale, width=0.001, color='black')  # 调整箭头宽度
    ax.quiverkey(Q, X=0.9, Y=1.05, U=10, label='10 m/s', labelpos='E')
    
    # 添加经纬网
    gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=0.5, color='gray', alpha=0.5)
    gl.top_labels = False
    gl.right_labels = False
    
    ax.set_title(f"200hPa Wind Field at {time.values}")
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_xlim(lon_range)  # 经度范围不变
    ax.set_ylim((-40, 0))  # 翻转纬度轴，从上到下表示从赤道到南纬40°
    
    # 格式化文件名并保存
    filename = format_filename(time)
    plt.savefig(f"C:\\Users\\Dell\\Desktop\\uv_200hPa\\{filename}.png", dpi=300, bbox_inches='tight')
    plt.close()