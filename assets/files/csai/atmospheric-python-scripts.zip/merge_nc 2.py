import xarray as xr
import os
import glob
from natsort import natsorted
from dask.diagnostics import ProgressBar

# Specify the path to the directory containing NetCDF files
data_path = r'/Users/blatos/Desktop/Work/BoM/era5/tp/regridded/'
# Use a wildcard (*) to select all NetCDF files in the directory
files_pattern = os.path.join(data_path, "*.nc")

# Use glob to list all files matching the pattern
files = glob.glob(files_pattern)

# Sort files using natsort to ensure correct order
files = natsorted(files)

# Print the list of files found
print("Files found for merging:")
for file in files:
    print(file)

# Check if any files were found
if not files:
    raise OSError("No files to open. Please check the directory path and file pattern.")

# Open and merge all NetCDF files using dask
# Adjusting chunks for better performance
merged_data = xr.open_mfdataset(
    files,
    combine='by_coords',
    parallel=True,
    chunks={'time': 100},  # Adjust chunk size as needed
    engine='netcdf4'  # Specify engine for better compatibility
)

# Save the merged dataset to a new NetCDF file
output_file = r'/Users/blatos/Desktop/Work/BoM/era5/tp/regridded/merged_data.nc'

# Use a progress bar to monitor the saving process
with ProgressBar():
    merged_data.to_netcdf(output_file)

# Close the dataset
merged_data.close()

print(f"Successfully merged and saved to {output_file}")
