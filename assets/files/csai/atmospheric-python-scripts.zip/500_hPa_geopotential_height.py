# -*- coding: utf-8 -*-
"""
Created on Sun Oct 13 16:47:03 2024

@author: Dell
"""

import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature

# 文件路径
file_path = r'D:\MATLAB\Freddy\ERA5_data\500hPa_geopotential_20230203_20230314.nc'

# 读取数据
ds = xr.open_dataset(file_path)

# 提取变量
geopotential = ds['z']  # 位势高度（单位: m^2/s^2）
lon = ds['longitude']  # 经度
lat = ds['latitude']  # 纬度
valid_time = ds['valid_time']  # 时间

# 将位势高度转换为 dagpm（除以9.81）
geopotential_dagpm = geopotential / 9.81

# 遍历每一天的数据并绘制
for t in range(len(valid_time)):
    plt.figure(figsize=(12, 8))
    ax = plt.axes(projection=ccrs.PlateCarree())

    # 绘制高度场
    contour = ax.contourf(lon, lat, geopotential_dagpm[t, 0, :, :], levels=20, cmap='coolwarm', transform=ccrs.PlateCarree())

    # 添加海岸线、国家边界和经纬度网格
    ax.coastlines()
    ax.add_feature(cfeature.BORDERS, linestyle=':')
    ax.gridlines(draw_labels=True, linewidth=1, color='gray', alpha=0.5, linestyle='--')

    # 添加颜色条
    cb = plt.colorbar(contour, ax=ax, orientation='vertical', pad=0.05)
    cb.set_label('Geopotential Height (dagpm)')

    # 设置标题和轴标签
    plt.title(f'500 hPa Geopotential Height (dagpm) on {str(valid_time[t].values)[:10]} at 06:00 UTC')
    plt.xlabel('Longitude (°E)')
    plt.ylabel('Latitude (°N)')

    # 显示图形
    plt.show()
