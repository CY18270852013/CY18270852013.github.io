import h5py
import numpy as np
import matplotlib.pyplot as plt
import os
from datetime import datetime, timedelta

# 文件路径和保存路径
mat_file_path = r"D:\MATLAB\Freddy\q_mjo.mat"
output_dir = r"C:\Users\Dell\Desktop\q_mjo_500hPa"

# 确保输出目录存在
os.makedirs(output_dir, exist_ok=True)

# 加载 q_mjo 数据
with h5py.File(mat_file_path, 'r') as f:
    q_mjo = np.array(f['q_mjo'])  # 读取变量 q_mjo

# 目标范围
start_date = datetime(2023, 2, 1)
end_date = datetime(2023, 3, 31)
dates = [start_date + timedelta(days=i) for i in range((end_date - start_date).days + 1)]

pressure_index = 15  # 对应 850 hPa（Python索引从0开始，第7个值为6）
latitudes = np.linspace(0, -40, 81)  # 纬度范围：0° 到 -40°
longitudes = np.linspace(0, 180, 360)  # 经度范围：0° 到 180°
lon_mask = (longitudes >= 40) & (longitudes <= 140)  # 经度掩膜
lat_mask = (latitudes <= 0) & (latitudes >= -40)  # 纬度掩膜

# 筛选目标范围的数据
lat_indices = np.where(lat_mask)[0]
lon_indices = np.where(lon_mask)[0]

# 提取所需时间范围的数据
start_index = (start_date - datetime(2001, 1, 1)).days
end_index = (end_date - datetime(2001, 1, 1)).days + 1
q_subset = q_mjo[start_index:end_index, pressure_index, lat_indices[:, None], lon_indices]

# 绘图
for i, (date, data) in enumerate(zip(dates, q_subset)):
    plt.figure(figsize=(10, 6))
    plt.contourf(
        longitudes[lon_indices],
        latitudes[lat_indices],
        data,
        levels=np.linspace(-5, 5, 21),  # 调整色阶范围
        cmap="coolwarm",
        extend="both"
    )
    plt.colorbar(label="Specific Humidity (g/kg)")
    plt.title(f"Specific Humidity at 500 hPa\n{date.strftime('%Y-%m-%d')}")
    plt.xlabel("Longitude (°E)")
    plt.ylabel("Latitude (°N)")
    plt.grid(linestyle="--", alpha=0.5)
    
    # 保存图像
    output_path = os.path.join(output_dir, f"q_500hPa_{i:02d}.png")
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close()

print(f"完成绘图并保存到：{output_dir}")
