# -*- coding: utf-8 -*-
"""
Created on Tue Feb 25 09:51:39 2025

@author: Chen Yong
"""

import xarray as xr
import numpy as np
import matplotlib.pyplot as plt

# 读取NetCDF文件
file_path = r'C:\Users\Chen Yong\Desktop\气象统计预报上机作业\CN05.1_Pre_1961_2022_monthly_025x025.nc'
ds = xr.open_dataset(file_path)

# 提取降雨量数据
pre = ds['pre']  # 降雨量数据，维度为 (time, lat, lon)
lat = ds['lat'][:]  # 纬度数据
lon = ds['lon'][:]  # 经度数据
time = ds['time']  # 时间数据

# 按年份分组，计算每年的总降雨量
annual_pre = pre.groupby('time.year').sum(dim='time')  # 按年求和，维度为 (year, lat, lon)

# 计算中国区域的平均降雨量
# 假设中国区域的范围为：纬度 15°N-55°N，经度 73°E-135°E
mask_lat = (lat >= 15) & (lat <= 55)
mask_lon = (lon >= 73) & (lon <= 135)
annual_pre_china = annual_pre[:, mask_lat, mask_lon]  # 提取中国区域的数据

# 计算每年的中国区域平均降雨量
annual_mean_china = annual_pre_china.mean(dim=('lat', 'lon'))  # 对纬度和经度求平均

# 计算长期平均值（1961-2022 年的平均值）
climatology = annual_mean_china.mean(dim='year')  # 长期平均值

# 计算距平值
anomaly = annual_mean_china - climatology  # 每年的距平值

# 获取年份和对应的距平值
years = anomaly['year'].values
anomaly_values = anomaly.values

# 关闭数据集
ds.close()

# 绘制时间序列曲线
plt.figure(figsize=(10, 6))
plt.plot(years, anomaly_values, marker='o', linestyle='-', color='b', label='Precipitation Anomaly')
plt.axhline(y=0, color='r', linestyle='--', linewidth=1, label='Climatology')  # 添加长期平均值参考线
plt.xlabel('Year', fontsize=12)
plt.ylabel('Precipitation Anomaly (mm)', fontsize=12)
plt.title('Annual Precipitation Anomaly in China (1961-2022)', fontsize=14)
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend()
plt.show()