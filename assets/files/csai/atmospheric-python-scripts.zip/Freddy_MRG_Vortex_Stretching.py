import numpy as np
import xarray as xr
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime, timedelta
import pandas as pd
import time
import os
import warnings
warnings.filterwarnings("ignore", category=UserWarning)

# 记录开始时间
start_time = time.time()
print("="*80)
print(f"STARTING PROCESS AT: {time.strftime('%Y-%m-%d %H:%M:%S')}")
print("="*80)

# 配置参数
start_date = datetime(2023, 2, 1)
end_date = datetime(2023, 3, 15)
freddy_box = {'lon_min': 110, 'lon_max': 120, 'lat_min': -20, 'lat_max': -10}  # 10°S~20°S
print("\n>>> CONFIGURATION:")
print(f"Time Range: {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}")
print(f"Freddy Genesis Box: Longitude {freddy_box['lon_min']}°E to {freddy_box['lon_max']}°E")
print(f"                   Latitude {abs(freddy_box['lat_min'])}°S to {abs(freddy_box['lat_max'])}°S")

# 1. ========================= 读取并处理MRG散度异常数据 =========================
print("\n" + "="*80)
print("PROCESSING MRG DIVERGENCE DATA")
print("="*80)
mrg_path = 'E:/divergence_anomaly_6hourly/divergence_anomaly_for_MRG_6hourly_20230101_20230331.nc'
print(f"Opening MRG dataset: {mrg_path}")

mrg_ds = xr.open_dataset(mrg_path)
print(">>> MRG Dataset Info:")
print(f"  Dimensions: {dict(mrg_ds.dims)}")
print(f"  Variables: {list(mrg_ds.variables.keys())}")
print(f"  Time range: {mrg_ds.time.min().values} to {mrg_ds.time.max().values}")
print(f"  Latitude range: {mrg_ds.lat.min().values} to {mrg_ds.lat.max().values}")
print(f"  Longitude range: {mrg_ds.lon.min().values} to {mrg_ds.lon.max().values}")

# 提取850 hPa数据
pressure_levels = mrg_ds.level.values
print(f"\nAvailable pressure levels: {pressure_levels}")
level_idx = np.abs(pressure_levels - 850).argmin()
selected_level = pressure_levels[level_idx]
print(f"Selected pressure level: {selected_level} hPa (index {level_idx})")

# 筛选时间和区域
print("\nFiltering data for Freddy box and time range...")
mrg_data = mrg_ds.mrg.sel(
    time=slice(start_date, end_date),
    level=selected_level,
    lat=slice(freddy_box['lat_min'], freddy_box['lat_max']),
    lon=slice(freddy_box['lon_min'], freddy_box['lon_max'])
)

# 计算区域平均
mrg_avg = mrg_data.mean(dim=['lat', 'lon'])
print("\n>>> MRG Spatial Average Stats:")
print(f"  Min: {mrg_avg.min().values:.3e}")
print(f"  Max: {mrg_avg.max().values:.3e}")
print(f"  Mean: {mrg_avg.mean().values:.3e}")

# 2. ========================= 读取并处理ERA5涡度数据 =========================
print("\n" + "="*80)
print("PROCESSING ERA5 VORTICITY DATA")
print("="*80)
era5_files = [
    'E:/ERA5_dv_q_uv_200901_202312_every_6hours/202301_dv.nc',
    'E:/ERA5_dv_q_uv_200901_202312_every_6hours/202302_dv.nc',
    'E:/ERA5_dv_q_uv_200901_202312_every_6hours/202303_dv.nc'
]

print(f"Opening ERA5 datasets: {era5_files}")
era5_ds = xr.open_mfdataset(era5_files, combine='by_coords')
print(">>> ERA5 Dataset Info:")
print(f"  Dimensions: {dict(era5_ds.dims)}")
print(f"  Variables: {list(era5_ds.variables.keys())}")
print(f"  Time range: {era5_ds.valid_time.min().values} to {era5_ds.valid_time.max().values}")
print(f"  Latitude range: {era5_ds.latitude.min().values} to {era5_ds.latitude.max().values}")
print(f"  Longitude range: {era5_ds.longitude.min().values} to {era5_ds.longitude.max().values}")

# 筛选时间和区域
print("\nFiltering data for 850 hPa, Freddy box and time range...")
era5_data = era5_ds.sel(
    valid_time=slice(start_date, end_date),
    pressure_level=850,  # 850 hPa
    latitude=slice(freddy_box['lat_max'], freddy_box['lat_min']),  # 纬度从大到小
    longitude=slice(freddy_box['lon_min'], freddy_box['lon_max'])
)

# 计算绝对涡度 (相对涡度 + 科氏参数)
print("\nCalculating absolute vorticity...")
omega = 7.292115e-5  # 地球自转角速度 (rad/s)

# 计算每个格点的科氏参数
lats = era5_data.latitude.values
lats_rad = np.deg2rad(lats)
f = 2 * omega * np.sin(lats_rad)

# 创建科氏参数DataArray
f_da = xr.DataArray(
    f,
    dims=['latitude'],
    coords={'latitude': era5_data.latitude}
)

# 计算绝对涡度 (使用瞬时相对涡度)
absolute_vorticity = era5_data.vo + f_da
print("\n>>> Absolute Vorticity Stats:")
print(f"  Min: {absolute_vorticity.min().values:.3e}")
print(f"  Max: {absolute_vorticity.max().values:.3e}")
print(f"  Mean: {absolute_vorticity.mean().values:.3e}")

# 3. ========================= 计算涡旋拉伸项 (修正维度广播问题) =========================
print("\n" + "="*80)
print("CALCULATING VORTEX STRETCHING TERM (FIXED DIMENSION BROADCASTING)")
print("="*80)

# 对齐时间序列
print("\nAligning time series between datasets...")
mrg_times = mrg_avg.time.values.astype('datetime64[s]')
era5_times = absolute_vorticity.valid_time.values.astype('datetime64[s]')

common_times = np.intersect1d(mrg_times, era5_times)
print(f"  MRG times: {len(mrg_times)}")
print(f"  ERA5 times: {len(era5_times)}")
print(f"  Common times: {len(common_times)}")

if len(common_times) == 0:
    print("ERROR: No common time steps found between datasets!")
    exit(1)

# 筛选共同时间步的数据
mrg_data_common = mrg_data.sel(time=common_times)
abs_vort_common = absolute_vorticity.sel(valid_time=common_times)

# 重命名ERA5数据的维度以匹配MRG数据
abs_vort_common = abs_vort_common.rename({
    'valid_time': 'time',
    'latitude': 'lat',
    'longitude': 'lon'
})

# 确保维度对齐
mrg_data_common = mrg_data_common.transpose('time', 'lat', 'lon')
abs_vort_common = abs_vort_common.transpose('time', 'lat', 'lon')

# 计算每个格点的涡旋拉伸项: η * (-∇·V')
vortex_stretching = abs_vort_common * (-mrg_data_common)

# 空间平均
vortex_stretching_avg = vortex_stretching.mean(dim=['lat', 'lon'])
mrg_avg_common = mrg_avg.sel(time=common_times)

print("\n>>> Vortex Stretching Stats:")
print(f"  Min: {vortex_stretching_avg.min().values:.3e}")
print(f"  Max: {vortex_stretching_avg.max().values:.3e}")
print(f"  Mean: {vortex_stretching_avg.mean().values:.3e}")

# 4. ========================= 绘图 =========================
print("\n" + "="*80)
print("CREATING PLOT")
print("="*80)

# 准备绘图数据
times = pd.to_datetime(common_times)

# 创建图表
plt.figure(figsize=(14, 8))
print(f"Created figure with size: 14x8 inches")

# 创建双纵轴
ax1 = plt.gca()
ax2 = ax1.twinx()

# 绘制MRG散度异常 (左轴)
print("Plotting MRG divergence...")
line1 = ax1.plot(times, mrg_avg_common.values, 
                 'b-', linewidth=2.5, label='MRG Divergence Anomaly')

# 绘制涡旋拉伸项 (右轴)
print("Plotting vortex stretching...")
line2 = ax2.plot(times, vortex_stretching_avg.values, 
                 'r-', linewidth=2.5, label='Vortex Stretching')

# 添加零线
ax1.axhline(y=0, color='k', linestyle='-', alpha=0.3)
ax2.axhline(y=0, color='k', linestyle='-', alpha=0.3)

# 设置横轴
ax1.set_xlim([start_date, end_date])
ax1.xaxis.set_major_locator(mdates.DayLocator(interval=2))
ax1.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d'))
plt.xticks(rotation=45, fontsize=10)

# 获取数据范围
cdiv_min, cdiv_max = np.nanmin(mrg_avg_common.values), np.nanmax(mrg_avg_common.values)
vstr_min, vstr_max = np.nanmin(vortex_stretching_avg.values), np.nanmax(vortex_stretching_avg.values)

print(f"MRG Divergence range: {cdiv_min:.2e} to {cdiv_max:.2e}")
print(f"Vortex Stretching range: {vstr_min:.2e} to {vstr_max:.2e}")

# 调整纵轴范围 - 增强可视化
cdiv_buffer = 0.1 * max(abs(cdiv_min), abs(cdiv_max))
vstr_buffer = 0.1 * max(abs(vstr_min), abs(vstr_max))

ax1.set_ylim([cdiv_min - cdiv_buffer, cdiv_max + cdiv_buffer])
ax2.set_ylim([vstr_min - vstr_buffer, vstr_max + vstr_buffer])

# 设置轴标签
ax1.set_ylabel('MRG Divergence Anomaly (s$^{-1}$)', color='b', fontsize=12)
ax1.tick_params(axis='y', colors='b', labelsize=10)
ax2.set_ylabel('Vortex Stretching (s$^{-2}$)', color='r', fontsize=12)
ax2.tick_params(axis='y', colors='r', labelsize=10)

# 添加标题和网格
plt.title('MRG Influence on Vorticity in Freddy Genesis Box (2023-02-01 to 2023-03-15)', 
          fontsize=14, pad=20)
ax1.grid(True, linestyle='--', alpha=0.6)

# 合并图例
print("Creating legend...")
lines = line1 + line2
labels = [l.get_label() for l in lines]
ax1.legend(lines, labels, loc='upper left', fontsize=10)

# 添加区域信息框
textstr = f"Freddy Genesis Box:\n{freddy_box['lon_min']}°E-{freddy_box['lon_max']}°E\n{abs(freddy_box['lat_min'])}°S-{abs(freddy_box['lat_max'])}°S\n850 hPa"
props = dict(boxstyle='round', facecolor='wheat', alpha=0.5)
ax1.text(0.02, 0.91, textstr, transform=ax1.transAxes, 
         fontsize=10, verticalalignment='top', bbox=props)

# 优化布局
plt.tight_layout()

# 确保输出目录存在
output_dir = r'D:\Freddy_ChenYong\Plot_ChenYong\Figure7'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)
    print(f"Created output directory: {output_dir}")

# 保存图像
output_path = os.path.join(output_dir, 'Freddy_MRG_Vortex_Stretching.png')
print(f"\nSaving plot to: {output_path}")
plt.savefig(output_path, dpi=300, bbox_inches='tight')
print("Plot saved successfully!")

# 显示图像
plt.show()

# 关闭数据集
mrg_ds.close()
era5_ds.close()

# 计算并打印总运行时间
end_time = time.time()
elapsed = end_time - start_time
print("\n" + "="*80)
print(f"PROCESS COMPLETED SUCCESSFULLY!")
print(f"Total execution time: {elapsed:.2f} seconds")
print("="*80)