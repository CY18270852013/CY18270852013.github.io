import numpy as np
import xarray as xr
import os
import time
from datetime import datetime, timedelta

# 配置路径
input_dir = "E:/GPM_daily_20090101_20231231"
output_dir = "E:/GPM_anomaly_daily"
os.makedirs(output_dir, exist_ok=True)

# 记录开始时间
start_time = time.time()
print(f"====== 开始计算降水异常值 ======")
print(f"开始时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")
print(f"输入目录: {input_dir}")
print(f"输出目录: {output_dir}")
print(f"气候态年份: 2009-2023 (共{2023-2009+1}年)")
print(f"目标日期: 2023-01-01 至 2023-03-31 (共90天)")

# 1. 构建气候态数据集 (2009-2023)
print("\n====== 步骤1/5: 构建气候态数据集 ======")
clim_days = 366  # 闰年日数
years = list(range(2009, 2024))  # 2009-2023年
lat_size, lon_size = 1800, 3600
total_years = len(years)
print(f"网格尺寸: 经度 {lon_size} × 纬度 {lat_size}")
print(f"气候态天数: {clim_days} (闰年系统)")
print(f"开始处理 {total_years} 年数据构建气候态...")

# 初始化气候态数组
clim_sum = np.zeros((clim_days, lat_size, lon_size), dtype=np.float32)
clim_count = np.zeros(clim_days, dtype=np.int32)

# 统计文件总数
total_files = 0
for year in years:
    if (year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)):
        total_files += 366  # 闰年
    else:
        total_files += 365  # 平年

print(f"预计处理文件数: {total_files}")
processed_files = 0
last_progress = -1

# 遍历所有年份的每日数据
for year_idx, year in enumerate(years):
    print(f"\n处理年份 {year} ({year_idx+1}/{total_years})...")
    start_date = datetime(year, 1, 1)
    end_date = datetime(year, 12, 31)
    current_date = start_date
    
    while current_date <= end_date:
        # 构建文件名
        filename = f"GPM_daily_{current_date.strftime('%Y%m%d')}.nc"
        filepath = os.path.join(input_dir, filename)
        
        if os.path.exists(filepath):
            # 读取数据
            with xr.open_dataset(filepath) as ds:
                precip = ds['precipitation'].values.squeeze()
            
            # 计算闰年中的日序 (1-366)
            doy_leap = (current_date - datetime(year, 1, 1)).days + 1
            
            # 非闰年且超过2月28日时调整日序
            if not (year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)) and doy_leap > 59:
                doy_leap += 1
            
            idx = doy_leap - 1  # 转换为0-based索引
            
            # 累加降水数据
            if idx < clim_days:
                clim_sum[idx] += precip
                clim_count[idx] += 1
        
        # 更新进度
        processed_files += 1
        progress = int(100 * processed_files / total_files)
        if progress > last_progress:
            print(f"进度: {progress}% ({processed_files}/{total_files} 文件)", end='\r')
            last_progress = progress
        
        # 下一天
        current_date += timedelta(days=1)

# 计算平均气候态
print("\n计算平均气候态...")
climatology = np.zeros_like(clim_sum)
for i in range(clim_days):
    if clim_count[i] > 0:
        climatology[i] = clim_sum[i] / clim_count[i]
    else:
        climatology[i] = np.nan  # 处理无数据日

# 打印气候态统计信息
print("\n气候态统计信息:")
print(f"  有效天数: {np.sum(clim_count > 0)}/{clim_days}")
print(f"  最大日平均降水: {np.nanmax(climatology):.2f} mm")
print(f"  最小日平均降水: {np.nanmin(climatology):.2f} mm")
print(f"  全球平均降水: {np.nanmean(climatology):.2f} mm")

# 2. 谐波拟合气候态
print("\n====== 步骤2/5: 进行谐波拟合 ======")
print("使用前三阶谐波拟合气候态...")
t = np.arange(clim_days)
T = clim_days  # 周期长度

# 设计矩阵 (前三阶谐波)
A = np.column_stack([
    np.ones(clim_days),
    np.cos(2 * np.pi * t / T),
    np.sin(2 * np.pi * t / T),
    np.cos(4 * np.pi * t / T),
    np.sin(4 * np.pi * t / T),
    np.cos(6 * np.pi * t / T),
    np.sin(6 * np.pi * t / T)
])

# 预计算矩阵
print("预计算矩阵...")
ATA_inv = np.linalg.inv(A.T @ A)
coeffs = np.zeros((7, lat_size, lon_size))

# 对每个格点进行拟合
print(f"开始拟合 {lat_size * lon_size:,} 个格点...")
total_points = lat_size * lon_size
points_processed = 0
last_progress = -1
start_fit_time = time.time()

for i in range(lat_size):
    for j in range(lon_size):
        y = climatology[:, i, j]
        valid = ~np.isnan(y)
        
        if np.any(valid):
            # 最小二乘拟合
            A_valid = A[valid]
            y_valid = y[valid]
            coeffs[:, i, j] = ATA_inv @ A_valid.T @ y_valid
        
        # 更新进度
        points_processed += 1
        progress = int(100 * points_processed / total_points)
        if progress > last_progress:
            elapsed = time.time() - start_fit_time
            est_total = elapsed * 100 / max(1, progress)
            est_remaining = est_total - elapsed
            print(f"拟合进度: {progress}% ({points_processed:,}/{total_points:,} 格点) | "
                  f"用时: {elapsed:.1f}s | 预计剩余: {est_remaining:.1f}s", end='\r')
            last_progress = progress

# 重建拟合气候态
print("\n重建拟合气候态...")
harmonics_climatology = np.zeros_like(climatology)
for k in range(7):
    harmonics_climatology += coeffs[k][np.newaxis, :, :] * A[:, k][:, np.newaxis, np.newaxis]

# 打印拟合结果统计
fit_diff = np.nanmean(np.abs(climatology - harmonics_climatology))
print(f"拟合质量评估:")
print(f"  气候态与拟合值平均绝对差异: {fit_diff:.4f} mm")
print(f"  最大拟合值: {np.nanmax(harmonics_climatology):.2f} mm")
print(f"  最小拟合值: {np.nanmin(harmonics_climatology):.2f} mm")

# 3. 计算2023年降水异常
print("\n====== 步骤3/5: 计算2023年降水异常 ======")
start_date = datetime(2023, 1, 1)
end_date = datetime(2023, 3, 31)
num_days = (end_date - start_date).days + 1
anomalies = np.zeros((num_days, lat_size, lon_size), dtype=np.float32)

print(f"处理 {num_days} 天数据 (2023-01-01 至 2023-03-31)...")

# 处理2023年每日数据
for day_idx in range(num_days):
    current_date = start_date + timedelta(days=day_idx)
    filename = f"GPM_daily_{current_date.strftime('%Y%m%d')}.nc"
    filepath = os.path.join(input_dir, filename)
    
    # 读取原始降水数据
    with xr.open_dataset(filepath) as ds:
        precip = ds['precipitation'].values.squeeze()
    
    # 计算在气候态中的索引
    doy_leap = (current_date - datetime(2023, 1, 1)).days + 1
    if not (2023 % 4 == 0 and (2023 % 100 != 0 or 2023 % 400 == 0)) and doy_leap > 59:
        doy_leap += 1
    
    clim_idx = doy_leap - 1
    
    # 计算异常值
    if clim_idx < harmonics_climatology.shape[0]:
        anomalies[day_idx] = precip - harmonics_climatology[clim_idx]
    
    # 打印每日处理结果
    date_str = current_date.strftime("%Y-%m-%d")
    day_min = np.nanmin(anomalies[day_idx])
    day_max = np.nanmax(anomalies[day_idx])
    day_mean = np.nanmean(anomalies[day_idx])
    print(f"日期 {date_str}: 异常值范围 [{day_min:.2f}, {day_max:.2f}] mm, 平均值 {day_mean:.2f} mm")

# 打印异常值总体统计
print("\n异常值总体统计:")
print(f"  最大正异常: {np.nanmax(anomalies):.2f} mm")
print(f"  最大负异常: {np.nanmin(anomalies):.2f} mm")
print(f"  平均绝对值: {np.nanmean(np.abs(anomalies)):.2f} mm")

# 4. 创建输出数据集
print("\n====== 步骤4/5: 创建输出数据集 ======")
time_coords = [start_date + timedelta(days=i) for i in range(num_days)]
lon_coords = np.arange(0.05, 360.0, 0.1)  # 经度: 0.05, 0.15, ..., 359.95
lat_coords = np.arange(-89.95, 90.0, 0.1)  # 纬度: -89.95, -89.85, ..., 89.95

print("设置坐标变量...")
print(f"  时间维度: {num_days} 个时间点")
print(f"  经度范围: {lon_coords[0]:.2f}° 至 {lon_coords[-1]:.2f}°")
print(f"  纬度范围: {lat_coords[0]:.2f}° 至 {lat_coords[-1]:.2f}°")

ds_out = xr.Dataset(
    {
        "precipitation_anomaly": (
            ["time", "lat", "lon"],
            anomalies,
            {
                "units": "mm",
                "long_name": "Daily precipitation anomaly",
                "description": "Anomaly from climatology after harmonic fitting",
                "min_value": float(np.nanmin(anomalies)),
                "max_value": float(np.nanmax(anomalies)),
                "mean_abs_value": float(np.nanmean(np.abs(anomalies)))
            }
        )
    },
    coords={
        "time": time_coords,
        "lat": lat_coords,
        "lon": lon_coords
    },
    attrs={
        "title": "GPM Daily Precipitation Anomaly",
        "institution": "Processed according to research methodology",
        "source": "GPM IMERG Final Precipitation L3",
        "history": f"Created on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "method": "Anomaly calculated by removing first three harmonics of climatology (2009-2023)",
        "period": "2023-01-01 to 2023-03-31",
        "climatology_years": "2009-2023",
        "harmonic_components": "First three annual harmonics"
    }
)

# 5. 保存结果
print("\n====== 步骤5/5: 保存结果 ======")
output_path = os.path.join(output_dir, "GPM_anomaly_daily_20230101_20230331.nc")
print(f"保存结果到: {output_path}")

# 保存数据集
save_start = time.time()
ds_out.to_netcdf(output_path)
save_time = time.time() - save_start

print(f"文件保存完成! 耗时: {save_time:.1f} 秒")
print(f"文件大小: {os.path.getsize(output_path)/(1024**2):.1f} MB")

# 打印总运行时间
total_time = time.time() - start_time
hours, remainder = divmod(total_time, 3600)
minutes, seconds = divmod(remainder, 60)
print("\n====== 处理完成! ======")
print(f"总运行时间: {int(hours)}小时 {int(minutes)}分 {seconds:.1f}秒")
print(f"输出文件: {output_path}")
print(f"结束时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")