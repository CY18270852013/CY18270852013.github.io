# -*- coding: utf-8 -*-
"""
Created on Fri May  2 17:26:56 2025

@author: Chen Yong
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import signal
from statsmodels.tsa.stattools import acf
from statsmodels.tsa.arima_process import ArmaProcess

# 1. 数据读取和预处理
def load_and_preprocess():
    df = pd.read_csv(
        r'C:\Users\Chen Yong\Python codes\nina34.csv',
        na_values=[-99.99],
        dtype={'Year': int}  # 强制年份为整数
    )
    
    months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    df[months] = df[months].apply(pd.to_numeric, errors='coerce')
    
    # 转换为长格式
    df_long = df.melt(
        id_vars='Year',
        var_name='Month',
        value_name='Anomaly'
    ).dropna(subset=['Anomaly'])
    
    month_map = {
        'Jan': 1, 'Feb': 2, 'Mar': 3, 'Apr': 4,
        'May': 5, 'Jun': 6, 'Jul': 7, 'Aug': 8,
        'Sep': 9, 'Oct': 10, 'Nov': 11, 'Dec': 12
    }
    df_long['MonthNum'] = df_long['Month'].map(month_map)
    df_long['Date'] = pd.to_datetime(
        df_long['Year'].astype(str) + '-' + df_long['MonthNum'].astype(str),
        format='%Y-%m',
        errors='coerce'
    )
    
    df_clean = df_long.dropna(subset=['Date']).set_index('Date').sort_index()
    # 添加Year和MonthNum列以便后续处理
    df_clean['Year'] = df_clean.index.year
    df_clean['MonthNum'] = df_clean.index.month
    return df_clean[['Year', 'MonthNum', 'Anomaly']]

# 2. 计算滞后相关系数
def calculate_autocorrelation(series, nlags=40):
    autocorr = acf(series, nlags=nlags, fft=False)
    return autocorr

# 3/4. 分段功率谱
def segment_spectrum(data, window_size=360, window_type=None):
    n_segments = len(data) // window_size
    spectra = []
    
    for i in range(n_segments):
        segment = data[i*window_size : (i+1)*window_size]
        if window_type == 'hann':
            win = np.hanning(len(segment))
            segment = segment * win
        fft = np.fft.fft(segment)
        psd = np.abs(fft)**2 / (2*np.pi*len(segment))
        spectra.append(psd[:len(psd)//2])
    
    avg_spectrum = np.mean(spectra, axis=0)
    freqs = np.fft.fftfreq(window_size, d=1/12)[:window_size//2]
    return freqs, avg_spectrum

# 5. 红噪声
def red_noise_test(rho1, n=1000, length=360):
    ar = np.array([1, -rho1])
    ma = np.array([1])
    ar_process = ArmaProcess(ar, ma)
    
    spectra = []
    for _ in range(n):
        red = ar_process.generate_sample(nsample=length)
        f, pxx = signal.periodogram(red, fs=12)
        spectra.append(pxx)
    
    mean_spectrum = np.mean(spectra, axis=0)
    upper95 = np.percentile(spectra, 95, axis=0)
    return f, mean_spectrum, upper95

# 6. Welch方法
def welch_spectrum(data):
    f, pxx = signal.welch(
        data, 
        fs=12, 
        nperseg=120,
        noverlap=60,
        window='hann',
        scaling='spectrum'
    )
    return f, pxx

def main():
    df = load_and_preprocess()
    
    # 计算各月平均值
    monthly_mean = df.groupby('MonthNum')['Anomaly'].mean().reset_index()
    monthly_mean.columns = ['MonthNum', 'MonthlyMean']
    
    df_merged = df.merge(monthly_mean, on='MonthNum', how='left')
    
    # 计算异常值
    df_merged['Anomaly_Value'] = df_merged['Anomaly'] - df_merged['MonthlyMean']
    
    # 转换为宽格式
    months_order = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    anomaly_wide = df_merged.pivot(index='Year', columns='MonthNum', values='Anomaly_Value')
    anomaly_wide.columns = [months_order[col-1] for col in anomaly_wide.columns]
    anomaly_wide = anomaly_wide.reindex(columns=months_order)
    
    output_path = r'C:\Users\Chen Yong\Desktop\气象统计预报上机作业\221830211_陈勇_作业四\nino3_anomaly.csv'
    anomaly_wide.to_csv(output_path)
    
    sst = df['Anomaly'].values
    
    # 1
    monthly_mean = df.groupby(df.index.month).agg({'Anomaly': 'mean'})
    monthly_mean.columns = ['MonthlyMean']
    print(monthly_mean)
    
    # 2
    autocorr = calculate_autocorrelation(sst)
    rho1 = autocorr[1]
    print('\nautocorr[1] = ', autocorr[1])
    
    plt.figure(figsize=(10,4))
    plt.bar(range(41), autocorr)
    plt.title(f'Autocorrelation (ρ1={rho1:.3f})')
    plt.xlabel('Lag (months)')
    plt.ylabel('Correlation')
    plt.show()
    
    # 3/4
    f1, pxx1 = segment_spectrum(sst)
    f2, pxx2 = segment_spectrum(sst, window_type='hann')
    
    plt.figure(figsize=(10,5))
    plt.semilogy(1/f1[1:], pxx1[1:], label='Raw')
    plt.semilogy(1/f2[1:], pxx2[1:], label='Hanning')
    plt.xlim(0, 20)
    plt.xlabel('Period (years)')
    plt.ylabel('Power Spectral Density')
    plt.legend()
    plt.title('Power Spectrum Comparison')
    
    # 5
    f_red, mean_red, upper_red = red_noise_test(rho1)
    plt.semilogy(1/f_red[1:], mean_red[1:], '--', label='Red Noise Mean')
    plt.semilogy(1/f_red[1:], upper_red[1:], ':', label='95% Threshold')
    plt.legend()
    
    # 6
    f_welch, pxx_welch = welch_spectrum(sst)
    plt.figure(figsize=(10,5))
    plt.semilogy(1/f_welch[1:], pxx_welch[1:])
    plt.xlim(0, 20)
    plt.xlabel('Period (years)')
    plt.ylabel('Power Spectral Density')
    plt.title('Welch Power Spectrum')
    
    plt.show()

if __name__ == '__main__':
    main()