# -*- coding: utf-8 -*-
"""
Created on Tue Jul 15 15:29:16 2025
@author: Dell
Updated to handle ERA5 data dimensions correctly
"""

import numpy as np
import netCDF4 as nc
import os
from datetime import datetime, timedelta
import calendar
import time
import gc

# 配置路径
input_dir = "E:/ERA5_dv_q_uv_200901_202312"
output_dir = "E:/u_v_anomaly"
os.makedirs(output_dir, exist_ok=True)
output_file = os.path.join(output_dir, "u_v_anomaly_20230101_20230331.nc")

# 时间参数
start_date = datetime(2023, 1, 1)
end_date = datetime(2023, 3, 31)
climatology_years = list(range(2009, 2024))  # 2009-2023年气候态数据

# 网格参数
n_lon = 720
n_lat = 81
n_level = 27
block_size = 50  # 经度分块大小
T = 1460  # 一年中的时间点数 (365天 * 4)

# 1. 时间索引函数 (忽略闰日)
def get_time_index(dt):
    """计算日期时间在一年中的时间索引(0-1459)，忽略闰日"""
    start_of_year = datetime(dt.year, 1, 1)
    doy = (dt - start_of_year).days  # 年日 (0-based)
    
    # 闰年且日期在3月1日之后，年日减1（跳过2月29日）
    if dt.month > 2 and calendar.isleap(dt.year):
        doy -= 1
    
    # 计算时间片索引 (00:00=0, 06:00=1, 12:00=2, 18:00=3)
    time_slot = dt.hour // 6
    return doy * 4 + time_slot

# 2. 预计算谐波基函数和最小二乘矩阵
print("预计算谐波基函数...")
t = np.arange(T)
basis_functions = np.column_stack([
    np.ones(T),
    np.cos(2 * np.pi * t / T),
    np.sin(2 * np.pi * t / T),
    np.cos(4 * np.pi * t / T),
    np.sin(4 * np.pi * t / T),
    np.cos(6 * np.pi * t / T),
    np.sin(6 * np.pi * t / T)
]).astype(np.float32)

# 计算最小二乘矩阵
X = basis_functions
XTX = X.T @ X
XTX_inv = np.linalg.inv(XTX)

# 3. 创建输出文件
print("创建输出文件...")
with nc.Dataset(output_file, 'w', format='NETCDF4') as out_ds:
    # 创建维度
    time_dim = out_ds.createDimension('time', None)
    level_dim = out_ds.createDimension('level', n_level)
    lat_dim = out_ds.createDimension('lat', n_lat)
    lon_dim = out_ds.createDimension('lon', n_lon)
    
    # 创建变量
    time_var = out_ds.createVariable('time', 'f8', ('time',))
    level_var = out_ds.createVariable('level', 'i4', ('level',))
    lat_var = out_ds.createVariable('lat', 'f4', ('lat',))
    lon_var = out_ds.createVariable('lon', 'f4', ('lon',))
    
    u_anom_var = out_ds.createVariable('u_anomaly', 'f4', 
                                      ('time', 'level', 'lat', 'lon'),
                                      fill_value=-9999.9, zlib=True)
    v_anom_var = out_ds.createVariable('v_anomaly', 'f4', 
                                      ('time', 'level', 'lat', 'lon'),
                                      fill_value=-9999.9, zlib=True)
    
    # 添加属性
    time_var.units = 'hours since 2023-01-01 00:00:00'
    time_var.calendar = 'standard'
    level_var.units = 'hPa'
    lat_var.units = 'degrees_north'
    lon_var.units = 'degrees_east'
    u_anom_var.units = 'm s**-1'
    v_anom_var.units = 'm s**-1'
    u_anom_var.long_name = 'Eastward wind anomaly'
    v_anom_var.long_name = 'Northward wind anomaly'
    
    # 写入静态维度数据 (从示例文件获取)
    sample_file = os.path.join(input_dir, "200901_uv.nc")
    with nc.Dataset(sample_file, 'r') as src:
        level_var[:] = src['pressure_level'][:]
        lat_var[:] = src['latitude'][:]
        lon_var[:] = src['longitude'][:]

# 主处理循环 (经度分块)
print("开始处理经度分块...")
num_blocks = (n_lon + block_size - 1) // block_size

for block_idx in range(num_blocks):
    lon_start = block_idx * block_size
    lon_end = min(lon_start + block_size, n_lon)
    num_lons = lon_end - lon_start
    print(f"\n处理经度块: {lon_start}-{lon_end} ({num_lons}个经度点)")
    block_start_time = time.time()
    
    # ==================================================================
    # 第一步: 计算气候态谐波系数 (2009-2023)
    # ==================================================================
    print("计算气候态谐波系数...")
    # 初始化累加器
    u_clim_accum = np.zeros((T, n_level, n_lat, num_lons), dtype=np.float32)
    v_clim_accum = np.zeros((T, n_level, n_lat, num_lons), dtype=np.float32)
    count_accum = np.zeros(T, dtype=np.int32)
    
    # 处理所有年份
    for year in climatology_years:
        for month in range(1, 13):
            # 构建文件名
            filename = f"{year}{month:02d}_uv.nc"
            filepath = os.path.join(input_dir, filename)
            if not os.path.exists(filepath):
                print(f"  文件不存在: {filename}, 跳过")
                continue
                
            print(f"  处理: {filename}")
            with nc.Dataset(filepath, 'r') as ds:
                # 读取时间并转换为datetime
                time_vals = ds['valid_time'][:]
                time_dts = [datetime(1970, 1, 1) + timedelta(seconds=int(t)) for t in time_vals]
                
                # 获取u/v数据的维度顺序
                u_dims = ds['u'].dimensions
                lon_idx = u_dims.index('longitude')
                lat_idx = u_dims.index('latitude')
                lev_idx = u_dims.index('pressure_level')
                time_idx = u_dims.index('valid_time')
                
                # 构建切片对象
                slices = [slice(None)] * len(u_dims)
                slices[lon_idx] = slice(lon_start, lon_end)
                
                # 读取u/v数据 (仅当前经度块)
                u_data = ds['u'][tuple(slices)]
                v_data = ds['v'][tuple(slices)]
                
                # 转置为 (valid_time, pressure_level, latitude, longitude)
                u_data = np.transpose(u_data, (time_idx, lev_idx, lat_idx, lon_idx))
                v_data = np.transpose(v_data, (time_idx, lev_idx, lat_idx, lon_idx))
                
                # 处理每个时间点
                for t_idx, dt in enumerate(time_dts):
                    # 跳过闰年的2月29日
                    if dt.month == 2 and dt.day == 29 and calendar.isleap(dt.year):
                        continue
                    
                    # 计算时间索引
                    clim_idx = get_time_index(dt)
                    
                    # 获取当前时间点的数据
                    current_u = u_data[t_idx]  # 形状: (n_level, n_lat, num_lons)
                    current_v = v_data[t_idx]
                    
                    # 累加数据
                    u_clim_accum[clim_idx] += current_u
                    v_clim_accum[clim_idx] += current_v
                    count_accum[clim_idx] += 1
    
    # 计算气候态平均值
    valid_mask = count_accum > 0
    for i in range(T):
        if valid_mask[i]:
            u_clim_accum[i] /= count_accum[i]
            v_clim_accum[i] /= count_accum[i]
    
    # 用谐波拟合气候态
    print("  谐波拟合气候态...")
    u_clim_fit = np.zeros_like(u_clim_accum)
    v_clim_fit = np.zeros_like(v_clim_accum)
    
    # 重塑为二维矩阵 (时间, 其他维度展平)
    flat_shape = (T, -1)
    u_flat = u_clim_accum.reshape(flat_shape)
    v_flat = v_clim_accum.reshape(flat_shape)
    
    # 矩阵运算: 谐波拟合
    coeff_u = XTX_inv @ (X.T @ u_flat)
    coeff_v = XTX_inv @ (X.T @ v_flat)
    
    # 重建拟合的气候态
    u_fit_flat = X @ coeff_u
    v_fit_flat = X @ coeff_v
    
    # 恢复原始形状
    u_clim_fit = u_fit_flat.reshape(u_clim_accum.shape)
    v_clim_fit = v_fit_flat.reshape(v_clim_accum.shape)
    
    # 释放内存
    del u_clim_accum, v_clim_accum, u_flat, v_flat, coeff_u, coeff_v, u_fit_flat, v_fit_flat
    gc.collect()
    
    # ==================================================================
    # 第二步: 计算2023年异常值
    # ==================================================================
    print("计算2023年异常值...")
    # 生成2023年时间序列
    time_points = []
    current_date = start_date
    while current_date <= end_date:
        # 跳过闰日 (2023年不是闰年，但保留逻辑)
        if current_date.month == 2 and current_date.day == 29:
            current_date += timedelta(days=1)
            continue
        time_points.append(current_date)
        current_date += timedelta(hours=6)
    
    n_time = len(time_points)
    # 初始化异常数组
    u_anomalies = np.zeros((n_time, n_level, n_lat, num_lons), dtype=np.float32)
    v_anomalies = np.zeros((n_time, n_level, n_lat, num_lons), dtype=np.float32)
    time_hours = []  # 存储小时数 (用于输出)
    
    # 处理2023年每个月
    for month in range(1, 4):  # 1-3月
        filename = f"2023{month:02d}_uv.nc"
        filepath = os.path.join(input_dir, filename)
        if not os.path.exists(filepath):
            print(f"  文件不存在: {filename}, 跳过")
            continue
            
        print(f"  处理: {filename}")
        with nc.Dataset(filepath, 'r') as ds:
            # 读取时间并转换为datetime
            time_vals = ds['valid_time'][:]
            time_dts = [datetime(1970, 1, 1) + timedelta(seconds=int(t)) for t in time_vals]
            
            # 获取u/v数据的维度顺序
            u_dims = ds['u'].dimensions
            lon_idx = u_dims.index('longitude')
            lat_idx = u_dims.index('latitude')
            lev_idx = u_dims.index('pressure_level')
            time_idx = u_dims.index('valid_time')
            
            # 构建切片对象
            slices = [slice(None)] * len(u_dims)
            slices[lon_idx] = slice(lon_start, lon_end)
            
            # 读取u/v数据 (仅当前经度块)
            u_data = ds['u'][tuple(slices)]
            v_data = ds['v'][tuple(slices)]
            
            # 转置为 (valid_time, pressure_level, latitude, longitude)
            u_data = np.transpose(u_data, (time_idx, lev_idx, lat_idx, lon_idx))
            v_data = np.transpose(v_data, (time_idx, lev_idx, lat_idx, lon_idx))
            
            # 处理每个时间点
            for t_idx, dt in enumerate(time_dts):
                # 只处理目标日期范围内的数据
                if dt < start_date or dt > end_date:
                    continue
                
                # 在时间序列中找到位置
                try:
                    global_t_idx = time_points.index(dt)
                except ValueError:
                    continue
                
                # 计算时间偏移量 (小时)
                time_offset = (dt - start_date).total_seconds() / 3600
                if not time_hours or time_hours[-1] != time_offset:
                    time_hours.append(time_offset)
                
                # 计算气候态索引
                clim_idx = get_time_index(dt)
                
                # 获取当前时间点的数据
                current_u = u_data[t_idx]  # 形状: (n_level, n_lat, num_lons)
                current_v = v_data[t_idx]
                
                # 计算异常值
                u_anomalies[global_t_idx] = current_u - u_clim_fit[clim_idx]
                v_anomalies[global_t_idx] = current_v - v_clim_fit[clim_idx]
    
    # ==================================================================
    # 第三步: 写入输出文件
    # ==================================================================
    print("写入输出文件...")
    with nc.Dataset(output_file, 'a') as out_ds:
        # 如果是第一个块，写入时间变量
        if block_idx == 0:
            # 确保时间变量长度正确
            out_ds['time'][:len(time_hours)] = time_hours
        
        # 写入异常值 (经度分块)
        for t_idx in range(n_time):
            if t_idx < len(out_ds['time']):
                out_ds['u_anomaly'][t_idx, :, :, lon_start:lon_end] = u_anomalies[t_idx]
                out_ds['v_anomaly'][t_idx, :, :, lon_start:lon_end] = v_anomalies[t_idx]
    
    # 显示块处理时间
    block_time = time.time() - block_start_time
    print(f"经度块处理完成，耗时: {block_time:.2f}秒")
    
    # 释放内存
    del u_anomalies, v_anomalies, u_clim_fit, v_clim_fit
    gc.collect()

print("处理完成！结果保存在: " + output_file)