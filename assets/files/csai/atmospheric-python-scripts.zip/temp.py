import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature

# 文件路径
file_202302 = r'D:\MATLAB\Freddy\ERA5_data\202302.nc'
file_202303 = r'D:\MATLAB\Freddy\ERA5_data\202303.nc'

# 读取NetCDF数据
ds_202302 = xr.open_dataset(file_202302)
ds_202303 = xr.open_dataset(file_202303)

# 合并数据集，时间维度
ds = xr.concat([ds_202302, ds_202303], dim='time')

# 选择时间范围（2023年2月3日到3月14日）
ds = ds.sel(time=slice('2023-02-03', '2023-03-14'))

# 选择850 hPa高度的比湿q，并按时间求平均
q_mean = ds['q'].sel(level=850).mean(dim='time')

# 修正纬度切片顺序，扩展范围到北纬10度
q_mean = q_mean.sel(longitude=slice(25, 125), latitude=slice(10, -40))

# 绘图
fig, ax = plt.subplots(figsize=(10, 6), subplot_kw={'projection': ccrs.PlateCarree()})

# 画比湿热力图
q_plot = ax.contourf(q_mean['longitude'], q_mean['latitude'], q_mean, levels=20, cmap='coolwarm', transform=ccrs.PlateCarree())

# 添加海岸线和国家边界
ax.coastlines()
ax.add_feature(cfeature.BORDERS, linestyle=':')

# 添加经纬度网格
ax.gridlines(draw_labels=True, linewidth=0.5, color='gray', alpha=0.7, linestyle='--')

# 设置坐标范围和标签
ax.set_extent([25, 125, -40, 10], crs=ccrs.PlateCarree())
ax.set_xlabel('Longitude')
ax.set_ylabel('Latitude')

# 添加颜色条
cbar = plt.colorbar(q_plot, ax=ax, orientation='vertical', pad=0.05)
cbar.set_label('Specific Humidity (kg/kg)')

# 添加标题
plt.title('Mean Specific Humidity at 850 hPa (2023-02-03 to 2023-03-14)')

# 显示图像
plt.show()
