import h5py
from netCDF4 import Dataset
import numpy as np

# 文件路径
mat_file_path = r"D:\MATLAB\Freddy\q_mjo.mat"
nc_file_path = r"D:\MATLAB\Freddy\q_mjo.nc"

# 读取.mat文件（MATLAB v7.3文件）
with h5py.File(mat_file_path, 'r') as mat_file:
    # 创建.nc文件
    with Dataset(nc_file_path, 'w', format='NETCDF4') as nc_file:
        # 遍历.mat文件中的所有变量
        for var_name, data in mat_file.items():
            # 获取变量数据，并将其转为numpy数组
            data_array = np.array(data)

            # 创建维度
            if data_array.ndim == 1:
                dim_name = f"{var_name}_dim"
                nc_file.createDimension(dim_name, data_array.shape[0])
                nc_var = nc_file.createVariable(var_name, data_array.dtype, (dim_name,))
            elif data_array.ndim == 2:
                dim_name_1 = f"{var_name}_dim1"
                dim_name_2 = f"{var_name}_dim2"
                nc_file.createDimension(dim_name_1, data_array.shape[0])
                nc_file.createDimension(dim_name_2, data_array.shape[1])
                nc_var = nc_file.createVariable(var_name, data_array.dtype, (dim_name_1, dim_name_2))
            else:
                # 处理更高维度的数据
                dim_names = [f"{var_name}_dim{i}" for i in range(data_array.ndim)]
                for i, dim_size in enumerate(data_array.shape):
                    nc_file.createDimension(dim_names[i], dim_size)
                nc_var = nc_file.createVariable(var_name, data_array.dtype, tuple(dim_names))

            # 写入数据
            nc_var[:] = data_array

print(f"{nc_file_path} 文件已成功创建！")
