# -*- coding: utf-8 -*-
"""
Created on Fri Dec  6 22:57:48 2024

@author: Chen Yong
"""

import numpy as np
import xarray as xr
import matplotlib.pyplot as plt
from scipy.interpolate import griddata

# 定义文件路径和数据
data_path = r"C:\Users\Chen Yong\Downloads\CMIP6_Datas"
files = [
    "sfcWind_Amon_CanESM5_ssp126_r13i1p2f1_gn_201501-210012.nc",
    "sfcWind_Amon_CanESM5_ssp245_r3i1p1f1_gn_201501-210012.nc",
    "sfcWind_Amon_CanESM5_ssp585_r22i1p1f1_gn_201501-210012.nc",
    "sfcWind_Amon_MIROC6_ssp126_r3i1p1f1_gn_201501-210012.nc",
    "sfcWind_Amon_MIROC6_ssp245_r1i1p1f1_gn_201501-210012.nc",
    "sfcWind_Amon_MIROC6_ssp585_r1i1p1f1_gn_201501-210012.nc",
    "sfcWind_Amon_NESM3_ssp126_r2i1p1f1_gn_201501-210012.nc",
    "sfcWind_Amon_NESM3_ssp245_r2i1p1f1_gn_201501-210012.nc",
    "sfcWind_Amon_NESM3_ssp585_r1i1p1f1_gn_201501-210012.nc",
]

# 目标分辨率
target_lat = np.arange(-90, 90.1, 1)  # 纬度
target_lon = np.arange(0, 360, 1)     # 经度

# 风能密度公式
def wind_power_density(u):
    return 0.5 * 1.225 * (u**3)

# 插值到统一网格
def interpolate_to_target_grid(ds, target_lat, target_lon):
    # 原始网格点
    original_lon, original_lat = np.meshgrid(ds.lon.values, ds.lat.values)
    points = np.column_stack((original_lat.ravel(), original_lon.ravel()))  # 展平为 (n, 2)
    
    # 对应的值
    values = ds.sfcWind.values  # (time, lat, lon)
    values_flat = values.reshape(values.shape[0], -1)  # 展平为 (time, n)
    
    # 新网格点
    lon, lat = np.meshgrid(target_lon, target_lat)
    
    # 插值结果
    interpolated_data = []
    for t in range(values_flat.shape[0]):  # 对每个时间点进行插值
        grid_z = griddata(points, values_flat[t, :], (lat, lon), method="linear")
        interpolated_data.append(grid_z)
    
    return np.array(interpolated_data)  # (time, lat, lon)

# 处理每个情景
scenarios = ["ssp126", "ssp245", "ssp585"]
annual_wind_energy = {scenario: [] for scenario in scenarios}

for scenario in scenarios:
    data_list = []
    for file in files:
        if scenario in file:
            ds = xr.open_dataset(f"{data_path}\\{file}")
            
            # 插值到统一网格
            interpolated_data = interpolate_to_target_grid(ds, target_lat, target_lon)
            
            # 检查插值结果
            if interpolated_data is None or interpolated_data.shape[1:] != (len(target_lat), len(target_lon)):
                raise ValueError("插值结果形状错误，请检查输入数据的维度！")
            
            # 计算风能密度
            wind_density = wind_power_density(interpolated_data)
            
            # 中国区域提取（纬度：20°N~50°N，经度：80°E~130°E）
            lat_mask = (target_lat >= 20) & (target_lat <= 50)
            lon_mask = (target_lon >= 80) & (target_lon <= 130)
            regional_density = wind_density[:, lat_mask, :][:, :, lon_mask]
            
            # 计算每年的风能密度平均
            years = np.arange(2015, 2101)
            year_data = []
            for year_idx in range(86):  # 2015-2100年共有86个年
                year_density = regional_density[year_idx::86, :, :].mean(axis=(1, 2))  # 每年平均
                year_data.append(year_density)
            
            # 将每个情景的年均风能密度存入列表
            data_list.append(np.array(year_data))
    
    # 多模式平均
    data_list = np.array(data_list)
    scenario_mean = data_list.mean(axis=0)  # 对不同模式进行平均
    annual_wind_energy[scenario] = scenario_mean

# 绘图
plt.figure(figsize=(10, 6))
years = np.arange(2015, 2101)

# 绘制每个情景的风能数据
for scenario, color in zip(scenarios, ["blue", "green", "red"]):
    plt.plot(years, annual_wind_energy[scenario], label=scenario.upper(), color=color)

# 添加标题和标签
plt.title("2015-2100年中国风能资源年际变化", fontsize=14)
plt.xlabel("年份", fontsize=12)
plt.ylabel("年均风能资源 (W/m²)", fontsize=12)

# 显示图例
plt.legend()

# 显示网格
plt.grid()

# 显示图像
plt.show()
