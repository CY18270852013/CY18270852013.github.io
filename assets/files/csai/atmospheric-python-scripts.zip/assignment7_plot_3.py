# -*- coding: utf-8 -*-
"""
Created on Tue Dec 17 23:59:26 2024

@author: Chen Yong
"""

import matplotlib.pyplot as plt
import numpy as np

# 对数化后的数据（h, Romberg Error, Gauss-Legendre Error）
log_data = np.array([
    [-2.10720997, -1.80731486, -1.30103035],
    [-2.40823997,  0.10852793, -1.60206008],
    [-2.70926996,  0.33469914, -1.90309001],
    [-3.01029996,  0.42228001, -2.20411999],
    [-3.31132995,  0.46118476, -2.50514998],
    [-3.61235995,  0.4795224 , -2.80617997],
    [-3.91338994,  0.48842347, -3.10720997],
    [-4.21441994,  0.49280833, -3.40823997],
    [-4.51544993,  0.4949845 , -3.70926996],
    [-4.81647993,  0.49606854, -4.01029996]
 ])

# 提取 h 值、Romberg 错误和 Gauss-Legendre 错误
h_values = log_data[:, 0]
romberg_errors = log_data[:, 1]
legendre_errors = log_data[:, 2]

# 绘制误差随 h 变化的折线图
plt.figure(figsize=(10, 6))

# 绘制 Romberg 方法误差的折线图
plt.plot(h_values, romberg_errors, label='Romberg Error', color='blue', marker='o')

# 绘制 Gauss-Legendre 方法误差的折线图
plt.plot(h_values, legendre_errors, label='Gauss-Legendre Error', color='red', marker='x')

# 设置图表标题和标签（英文）
plt.title('Error vs Step Size (h)', fontsize=14)
plt.xlabel('Step Size h (log scale)', fontsize=12)
plt.ylabel('Logarithmic Error (log scale)', fontsize=12)

# 使用对数坐标轴
plt.xscale('linear')  # 使用线性坐标轴
plt.yscale('linear')  # 使用线性坐标轴

# 添加图例
plt.legend()

# 显示图形
plt.grid(True)
plt.show()
