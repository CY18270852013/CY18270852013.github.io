# -*- coding: utf-8 -*-
"""
Created on Sun Oct 13 23:55:25 2024

@author: Dell
"""

import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import os

# 文件路径
file_path = r'D:\MATLAB\Freddy\ERA5_data\500hPa_U_V_wind.nc'
output_dir = r'C:\Users\Dell\Desktop\500hPa_U_V_wind'

# 如果输出目录不存在，则创建
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# 读取数据
ds = xr.open_dataset(file_path)

# 提取变量
u = ds['u']  # zonal wind (东西风)
v = ds['v']  # meridional wind (南北风)
lon = ds['longitude']  # 经度
lat = ds['latitude']  # 纬度
time = ds['valid_time']  # 时间

# 遍历每一个小时的数据并绘制
for t in range(len(time)):
    # 获取当前时刻的 u 和 v 分量
    u_wind = u[t, 0, :, :]
    v_wind = v[t, 0, :, :]
    
    # 创建图形
    plt.figure(figsize=(12, 8))
    ax = plt.axes(projection=ccrs.PlateCarree())
    
    # 绘制风场矢量图
    ax.quiver(lon, lat, u_wind, v_wind, transform=ccrs.PlateCarree())
    
    # 添加海岸线、国界线和经纬度网格
    ax.coastlines()
    ax.add_feature(cfeature.BORDERS, linestyle=':')
    ax.gridlines(draw_labels=True, linewidth=1, color='gray', alpha=0.5, linestyle='--')
    
    # 设置标题和轴标签
    plt.title(f'500 hPa Wind Field on {str(time[t].values)[:13]}', fontsize=14)
    plt.xlabel('Longitude (°E)')
    plt.ylabel('Latitude (°N)')
    
    # 保存图片到指定文件夹
    output_file = os.path.join(output_dir, f'wind_{t}.png')
    plt.savefig(output_file, dpi=300)
    
    # 关闭图形，避免内存占用过多
    plt.close()

print("All wind field plots have been saved.")
