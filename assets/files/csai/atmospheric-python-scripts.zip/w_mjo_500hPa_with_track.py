# -*- coding: utf-8 -*-
"""
Created on Tue Mar 11 19:07:48 2025

@author: Dell
"""

import h5py
import numpy as np
import matplotlib.pyplot as plt
import os
from datetime import datetime, timedelta
import cartopy.crs as ccrs
import cartopy.feature as cfeature

# 文件路径和保存路径
mat_file_path = r"D:\MATLAB\Freddy\w_mjo.mat"
output_dir = r"C:\Users\Dell\Desktop\w_mjo_500hPa_with_track"

# 确保输出目录存在
os.makedirs(output_dir, exist_ok=True)

# 加载 w_mjo 数据
with h5py.File(mat_file_path, 'r') as f:
    w_mjo = np.array(f['w_mjo'])  # 读取变量 w_mjo

# 单位转换：Pa/s -> 10^-2 m/s
rho = 0.736  # 空气密度 (kg/m^3) 在 500 hPa
g = 9.81     # 重力加速度 (m/s^2)
w_mjo = -w_mjo / (rho * g) * 100  # 转换为 10^-2 m/s

# 目标范围
start_date = datetime(2023, 2, 1)
end_date = datetime(2023, 3, 31)
dates = [start_date + timedelta(days=i) for i in range((end_date - start_date).days + 1)]

pressure_index = 13  # 对应 500 hPa
latitudes = np.linspace(0, -40, 81)  # 纬度范围：0° 到 -40°
longitudes = np.linspace(0, 180, 360)  # 经度范围：0° 到 180°
lon_mask = (longitudes >= 25) & (longitudes <= 130)  # 经度掩膜
lat_mask = (latitudes <= 0) & (latitudes >= -40)  # 纬度掩膜

# 筛选目标范围的数据
lat_indices = np.where(lat_mask)[0]
lon_indices = np.where(lon_mask)[0]

# 提取所需时间范围的数据
start_index = (start_date - datetime(2001, 1, 1)).days
end_index = (end_date - datetime(2001, 1, 1)).days + 1
w_subset = w_mjo[start_index:end_index, pressure_index, lat_indices[:, None], lon_indices]

# 绘图
levels = np.linspace(-5, 5, 21)  # 色阶范围
cmap = "coolwarm"  # 色彩映射

for i, (date, data) in enumerate(zip(dates, w_subset)):
    plt.figure(figsize=(12, 8))
    ax = plt.axes(projection=ccrs.PlateCarree())
    
    # 绘制填色图
    contour = ax.contourf(
        longitudes[lon_indices],
        latitudes[lat_indices],
        data,
        levels=levels,
        cmap=cmap,
        extend="both",
        transform=ccrs.PlateCarree()  # 数据的投影
    )
    
    # 添加海陆线、国界线
    ax.coastlines(resolution='50m', linewidth=1)
    ax.add_feature(cfeature.BORDERS, linewidth=0.8)
    ax.add_feature(cfeature.LAND, facecolor='lightgray', edgecolor='black', alpha=0.5)
    ax.add_feature(cfeature.LAKES, facecolor='lightblue', edgecolor='black', alpha=0.5)

    # 添加网格和坐标轴标签
    ax.gridlines(draw_labels=True, linewidth=0.5, linestyle='--', alpha=0.7)
    plt.colorbar(contour, ax=ax, orientation='vertical', label="Vertical Velocity (10^-2 m/s)")
    
    # 标题
    plt.title(f"500 hPa Vertical Velocity\n{date.strftime('%Y-%m-%d')}", fontsize=14)
    
    # 保存图像
    output_path = os.path.join(output_dir, f"w_500hPa_{i:02d}.png")
    plt.savefig(output_path, dpi=400, bbox_inches="tight")  # 提高清晰度
    plt.close()

print(f"完成绘图并保存到：{output_dir}")