import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature

# Load the data
file_path = r"C:\Users\Chen Yong\Downloads\ERA5 data\ERA5 data\2000-2021_Q_1000-100hPa_monthly.nc"
ds = xr.open_dataset(file_path)

# Calculate multi-year mean for each selected pressure level
mean_q_1000 = ds.q.sel(pressure_level=1000).mean(dim='date')
mean_q_850 = ds.q.sel(pressure_level=850).mean(dim='date')
mean_q_500 = ds.q.sel(pressure_level=500).mean(dim='date')

# Set up color map and consistent color bar limits
cmap = 'coolwarm'
vmin, vmax = min(mean_q_500.min(), mean_q_850.min(), mean_q_1000.min()), max(mean_q_500.max(), mean_q_850.max(), mean_q_1000.max())

# Define a function to create each plot with its own color bar, coastlines, and grid lines
def plot_specific_humidity(data, level):
    fig, ax = plt.subplots(figsize=(10, 6), subplot_kw={'projection': ccrs.PlateCarree()})
    im = ax.contourf(ds.longitude, ds.latitude, data, levels=20, cmap=cmap, transform=ccrs.PlateCarree(), vmin=vmin, vmax=vmax)
    ax.coastlines()
    ax.add_feature(cfeature.BORDERS, linestyle=':')
    ax.gridlines(draw_labels=True, linewidth=0.5, color='gray', alpha=0.5, linestyle='--')
    plt.colorbar(im, ax=ax, orientation='vertical', pad=0.05, label='Specific Humidity (g/kg)')
    ax.set_title(f'{level} hPa Specific Humidity (2000-2021 Mean)')
    plt.show()

# Plot each pressure level separately
plot_specific_humidity(mean_q_1000, 1000)
plot_specific_humidity(mean_q_850, 850)
plot_specific_humidity(mean_q_500, 500)
