import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
import sys

# === 1. 数据路径 ===
file_paths = {
    'olr_anomaly': r'E:\olr_daily\olr_anomaly_daily_20230101_20230331.nc',
    'olr_mjo': r'E:\olr_daily\olr_anomaly_for_MJO_daily_20230101_20230331.nc',
    'olr_kelvin': r'E:\olr_daily\olr_anomaly_for_Kelvin_daily_20230101_20230331.nc',
    'olr_mrg': r'E:\olr_daily\olr_anomaly_for_MRG_daily_20230101_20230331.nc',
    'olr_er': r'E:\olr_daily\olr_anomaly_for_ER_daily_20230101_20230331.nc'
}

# === 2. 加载数据 ===
print("加载数据...")
try:
    olr_anomaly = xr.open_dataset(file_paths['olr_anomaly'])['olr_anomaly']
    olr_mjo = xr.open_dataset(file_paths['olr_mjo'])['mjo']
    olr_kelvin = xr.open_dataset(file_paths['olr_kelvin'])['olr_kelvin']
    olr_mrg = xr.open_dataset(file_paths['olr_mrg'])['olr_mrg']
    olr_er = xr.open_dataset(file_paths['olr_er'])['olr_er']
except Exception as e:
    print(f"加载数据失败: {e}")
    sys.exit()

# === 3. 设置时间与空间范围 ===
start_date = datetime(2023, 2, 1)
end_date = datetime(2023, 3, 15)
lon_range = slice(110, 120)  # 110°E ~ 120°E
lat_range = slice(-20.5, -9.5)  # 10°S ~ 20°S

# === 4. 切片与空间平均 ===
print("\n切片与空间平均...")
def process_data(ds):
    # 选择时间范围
    ds_slice = ds.sel(time=slice(start_date, end_date))
    print(f"时间切片后数据维度: {ds_slice.shape}")

    # **关键修正**：不再反转纬度，保留原始纬度方向
    # print("纬度值:", ds_slice.lat.values)  # 可选：调试纬度方向
    # print(f"纬度范围: {ds_slice.lat.min()} ~ {ds_slice.lat.max()}")

    # 选择空间范围
    ds_slice = ds_slice.sel(lon=lon_range, lat=lat_range)
    print(f"空间切片后数据维度: {ds_slice.shape}")

    # 检查纬度是否正确选中
    if ds_slice.sizes['lat'] == 0:
        raise ValueError(f"纬度范围未选中数据，检查 lat_range: {lat_range}")

    # 空间平均（经度和纬度）
    avg_data = ds_slice.mean(dim=['lat', 'lon'], skipna=True)
    print(f"空间平均后数据: {avg_data.values[:5]}")  # 打印前5个值
    return avg_data

# 处理每个数据集
try:
    olr_anomaly_avg = process_data(olr_anomaly)
    olr_mjo_avg = process_data(olr_mjo)
    olr_kelvin_avg = process_data(olr_kelvin)
    olr_mrg_avg = process_data(olr_mrg)
    olr_er_avg = process_data(olr_er)
except ValueError as e:
    print(e)
    sys.exit()

# 波动总和
sum_waves = olr_mjo_avg + olr_kelvin_avg + olr_mrg_avg + olr_er_avg

# === 5. 绘图 ===
print("开始绘图...")
fig, ax = plt.subplots(figsize=(12, 6), dpi=300)

# 绘制各波动贡献
ax.plot(olr_anomaly_avg.time.values, olr_anomaly_avg.values, color='green', label='Anomaly', linewidth=1.5)
ax.plot(olr_mjo_avg.time.values, olr_mjo_avg.values, color='black', label='MJO', linewidth=1.5)
ax.plot(olr_kelvin_avg.time.values, olr_kelvin_avg.values, color='blue', label='Kelvin', linewidth=1.5)
ax.plot(olr_mrg_avg.time.values, olr_mrg_avg.values, color='gray', label='MRG', linewidth=1.5)
ax.plot(olr_er_avg.time.values, olr_er_avg.values, color='red', label='ER ', linewidth=1.5)
ax.plot(sum_waves.time.values, sum_waves.values, color='purple', label='Sum of Waves', linewidth=2, linestyle='--')

# 设置横轴时间格式
ax.xaxis.set_major_locator(mdates.DayLocator(interval=2))  # 每2天一个刻度
ax.xaxis.set_major_formatter(mdates.DateFormatter('%b-%d'))  # 格式: Feb-01
plt.xticks(rotation=45)

# 自动计算 y 轴范围（避开 NaN）
y_min = min(np.nanmin(olr_anomaly_avg), np.nanmin(sum_waves))
y_max = max(np.nanmax(olr_anomaly_avg), np.nanmax(sum_waves))
ax.set_ylim(y_min - 0.1 * abs(y_min), y_max + 0.1 * abs(y_max))

# 添加标题和标签
ax.set_title('OLR Anomalies and Wave Contributions (110°E–120°E, 10°S–20°S)', fontsize=14)
ax.set_xlim([datetime(2023, 2, 1), datetime(2023, 3, 15)])
ax.set_xlabel('Date', fontsize=12)
ax.set_ylabel('OLR Anomaly (W/m²)', fontsize=12)

# 添加图例
legend = ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.2), ncol=6, fontsize=10, frameon=False)
for line in legend.get_lines():
    line.set_linewidth(2.5)

# **关键修正**：更新图像保存路径
plt.tight_layout()
plt.savefig(r'D:\Freddy_ChenYong\Plot_ChenYong\Figure5_Freddy_Genesis_Box\olr_Freddy_Genesis_Box.png', bbox_inches='tight', dpi=300)
print("图像已保存！")
plt.show()