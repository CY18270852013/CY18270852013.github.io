import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
import sys

# === 1. 数据路径 ===
file_paths = {
    'precip': r'E:\GPM_anomaly_6hours_accumulated\GPM_anomaly_20230101_20230331.nc',
    'mjo': r'E:\GPM_anomaly_6hours_accumulated\GPM_anomaly_for_MJO_20230101_20230331.nc',
    'kelvin': r'E:\GPM_anomaly_6hours_accumulated\GPM_anomaly_for_Kelvin_20230101_20230331.nc',
    'mrg': r'E:\GPM_anomaly_6hours_accumulated\GPM_anomaly_for_MRG_20230101_20230331.nc',
    'er': r'E:\GPM_anomaly_6hours_accumulated\GPM_anomaly_for_ER_20230101_20230331.nc'
}

# === 2. 加载数据 ===
print("加载数据...")
try:
    precip_data = xr.open_dataset(file_paths['precip'])['precipitation_anomaly']
    mjo_data = xr.open_dataset(file_paths['mjo'])['mjo']
    kelvin_data = xr.open_dataset(file_paths['kelvin'])['kelvin']
    mrg_data = xr.open_dataset(file_paths['mrg'])['mrg']
    er_data = xr.open_dataset(file_paths['er'])['er']
except Exception as e:
    print(f"加载数据失败: {e}")
    sys.exit()

# === 3. 打印数据基本信息 ===
print("\n数据基本信息：")
print("precipitation_anomaly:\n", precip_data)
print("mjo:\n", mjo_data)
print("kelvin:\n", kelvin_data)
print("mrg:\n", mrg_data)
print("er:\n", er_data)

# === 4. 设置时间与空间范围 ===
start_date = datetime(2023, 2, 1)
end_date = datetime(2023, 3, 15)
lon_range = slice(110, 120)  # 110°E ~ 120°E
lat_range = slice(-10, -20)  # 修正后的纬度范围（降序）

# === 5. 切片与空间平均 ===
print("\n切片与空间平均...")
def process_data(ds):
    # 选择时间范围
    ds_slice = ds.sel(time=slice(start_date, end_date))
    print(f"时间切片后数据维度: {ds_slice.shape}")
    
    # 选择空间范围
    ds_slice = ds_slice.sel(lon=lon_range, lat=lat_range)
    print(f"空间切片后数据维度: {ds_slice.shape}")
    
    # 检查纬度是否正确选中
    if ds_slice.sizes['lat'] == 0:
        raise ValueError(f"纬度范围未选中数据，检查 lat_range: {lat_range}")
    
    # 空间平均（经度和纬度）
    avg_data = ds_slice.mean(dim=['lat', 'lon'], skipna=True)
    print(f"空间平均后数据: {avg_data.values[:5]}")  # 打印前5个值
    return avg_data

# 处理每个数据集
try:
    precip_avg = process_data(precip_data)
    mjo_avg = process_data(mjo_data)
    kelvin_avg = process_data(kelvin_data)
    mrg_avg = process_data(mrg_data)
    er_avg = process_data(er_data)
except ValueError as e:
    print(e)
    sys.exit()

# 波动总和
sum_waves = mjo_avg + kelvin_avg + mrg_avg + er_avg

# === 6. 绘图 ===
print("开始绘图...")
fig, ax = plt.subplots(figsize=(12, 6), dpi=300)

# 绘制各波动贡献
ax.plot(precip_avg.time.values, precip_avg.values, color='green', label='Anomaly', linewidth=1.5)
ax.plot(mjo_avg.time.values, mjo_avg.values, color='black', label='MJO', linewidth=1.5)
ax.plot(kelvin_avg.time.values, kelvin_avg.values, color='blue', label='Kelvin', linewidth=1.5)
ax.plot(mrg_avg.time.values, mrg_avg.values, color='gray', label='MRG', linewidth=1.5)
ax.plot(er_avg.time.values, er_avg.values, color='red', label='ER', linewidth=1.5)
ax.plot(sum_waves.time.values, sum_waves.values, color='purple', label='Sum of Waves', linewidth=2, linestyle='--')

# 设置横轴时间格式
ax.xaxis.set_major_locator(mdates.DayLocator(interval=2))  # 每2天一个刻度
ax.xaxis.set_major_formatter(mdates.DateFormatter('%b-%d'))  # 格式: Feb-01
plt.xticks(rotation=45)

# 自动计算 y 轴范围（避开 NaN）
y_min = min(np.nanmin(precip_avg), np.nanmin(sum_waves))
# y_max = max(np.nanmax(precip_avg), np.nanmax(sum_waves))
y_max = 1.5
ax.set_ylim(y_min - 0.1 * abs(y_min), y_max + 0.1 * abs(y_max))

# 添加标题和标签
ax.set_title('Precipitation Anomalies and Wave Contributions (110°E–120°E, 10°S–20°S)', fontsize=14)
ax.set_xlim([datetime(2023, 2, 1), datetime(2023, 3, 15)])
ax.set_xlabel('Date', fontsize=12)
ax.set_ylim(-2.3, 1.5)
ax.set_ylabel('Precipitation Anomaly (mm)', fontsize=12)

# 添加图例
legend = ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.2), ncol=6, fontsize=10, frameon=False)
for line in legend.get_lines():
    line.set_linewidth(2.5)

# 保存图像
plt.tight_layout()
plt.savefig(r'D:\Freddy_ChenYong\Plot_ChenYong\Figure5_Freddy_Genesis_Box\precipitation_Freddy_Genesis_Box.png', bbox_inches='tight', dpi=300)
print("图像已保存！")
plt.show()