import xarray as xr
import numpy as np
import os
import dask
from dask.diagnostics import ProgressBar

def fit_harmonics(dayofyear, data):
    """拟合前三阶谐波到气候态数据"""
    t = 2 * np.pi * dayofyear / 365.25
    harmonics = np.zeros((len(dayofyear), 7))
    harmonics[:, 0] = 1  # 常数项
    for k in range(1, 4):  # 前三阶谐波
        harmonics[:, 2*k-1] = np.cos(k * t)
        harmonics[:, 2*k] = np.sin(k * t)
    coeffs = np.linalg.lstsq(harmonics, data, rcond=None)[0]
    return harmonics @ coeffs

# 配置路径
input_dir = "D:/Freddy_ChenYong/Data/OLR_daily_19800101_20231231"
output_dir = "E:/olr_daily"
os.makedirs(output_dir, exist_ok=True)

# 1. 读取15年数据 (2009-2023)
years = range(2009, 2024)
files = [os.path.join(input_dir, f"olr-daily_v01r02_{y}0101_{y}1231.nc") for y in years]

# 使用dask分块读取
ds = xr.open_mfdataset(files, chunks={'time': 365, 'lat': 45, 'lon': 90}, combine='nested', concat_dim='time')
olr = ds['olr']

# 2. 计算气候态
print("计算气候态...")
with ProgressBar():
    clim = olr.groupby('time.dayofyear').mean(dim='time').compute()

# 3. 谐波拟合
print("进行谐波拟合...")
dayofyear = clim.dayofyear.values
harmonics_clim = xr.apply_ufunc(
    fit_harmonics,
    dayofyear,
    clim,
    input_core_dims=[['dayofyear'], ['dayofyear']],
    output_core_dims=[['dayofyear']],
    vectorize=True,
    dask='parallelized',
    output_dtypes=[np.float32]
).rename('harmonics_clim')

# 4. 读取2023年数据 (1月1日-3月31日)
print("处理2023年数据...")
ds_2023 = xr.open_dataset(os.path.join(input_dir, "olr-daily_v01r02_20230101_20231231.nc"))
olr_2023 = ds_2023['olr'].sel(time=slice('2023-01-01', '2023-03-31'))

# 5. 计算异常值
harmonics_vals = harmonics_clim.sel(dayofyear=olr_2023.time.dt.dayofyear)
anomaly = olr_2023 - harmonics_vals

# 6. 保存结果
print("保存结果...")
anomaly_ds = xr.Dataset({'olr_anomaly_daily': anomaly})
anomaly_ds.attrs['description'] = 'OLR anomaly calculated with first three harmonics of climatology (2009-2023)'

output_path = os.path.join(output_dir, "olr_anomaly_daily_20230101_20230331_2.nc")
anomaly_ds.to_netcdf(output_path)

print(f"处理完成! 结果保存至: {output_path}")