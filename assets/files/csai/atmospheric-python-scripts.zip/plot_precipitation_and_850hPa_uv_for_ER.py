# -*- coding: utf-8 -*-
"""
Created on Mon Jul 21 22:05:21 2025

@author: Dell
"""

import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER
import os
from datetime import datetime, timedelta
from matplotlib.colors import LinearSegmentedColormap

# 设置绘图参数
plt.rcParams['font.family'] = 'Arial'
plt.rcParams['font.size'] = 12

# 定义地图范围和日期范围
lon_range = [80, 150]  # 80°E~150°E
lat_range = [-30, 10]   # 30°S~10°N
start_date = datetime(2023, 2, 1)
end_date = datetime(2023, 2, 10)
date_list = [start_date + timedelta(days=x) for x in range(0, (end_date-start_date).days+1)]

# 创建输出目录
output_dir = r"D:\Freddy_ChenYong\Plot_ChenYong\plot_precipitation_and_850hPa_uv_for_ER"
os.makedirs(output_dir, exist_ok=True)

# 加载GPM降水异常数据
gpm_path = r"E:\GPM_anomaly_daily\GPM_anomaly_daily_for_ER_20230101_20230331.nc"
ds_gpm = xr.open_dataset(gpm_path)

# 加载风场异常数据
wind_path = r"E:\u_v_daily\u_v_anomaly_for_ER_daily_20230101_20230331.nc"
ds_wind = xr.open_dataset(wind_path)

# 修正纬度方向（降序→升序）
if ds_gpm.lat.values[0] > ds_gpm.lat.values[-1]:
    ds_gpm = ds_gpm.sortby('lat', ascending=True)
if ds_wind.latitude.values[0] > ds_wind.latitude.values[-1]:
    ds_wind = ds_wind.sortby('latitude', ascending=True)

# 筛选数据
ds_gpm = ds_gpm.sel(
    lon=slice(lon_range[0], lon_range[1]),
    lat=slice(lat_range[0], lat_range[1])
)

ds_wind = ds_wind.sel(
    pressure_level=850.0,
    longitude=slice(lon_range[0], lon_range[1]),
    latitude=slice(lat_range[0], lat_range[1])
)

# 统一设置最大降水量和最大风速
precip_max = 8.0  # 统一设置为8mm
wind_max = 5.5    # 统一设置为5.5m/s

print(f"固定最大降水异常值: {precip_max} mm")
print(f"固定最大风速: {wind_max} m/s")

# 创建自定义颜色映射（白色到深蓝色）
colors = [
    '#FFFFFF',  # 白色 (0 mm)
    '#D4EBFF',  # 极浅蓝
    '#99CCFF',  # 浅蓝
    '#66B2FF',  # 中等蓝
    '#3399FF',  # 标准蓝
    '#0066CC'   # 深蓝
]
cmap_custom = LinearSegmentedColormap.from_list('custom_blue', colors, N=256)

# 循环处理每个日期
for target_date in date_list:
    print(f"\n处理日期: {target_date.strftime('%Y-%m-%d')}")
    
    # 创建绘图画布
    fig = plt.figure(figsize=(12, 8))
    ax = fig.add_subplot(1, 1, 1, projection=ccrs.PlateCarree())
    
    # 添加地理要素
    ax.add_feature(cfeature.LAND, facecolor='white', zorder=1)
    ax.add_feature(cfeature.COASTLINE, linewidth=0.5, zorder=2)
    ax.add_feature(cfeature.BORDERS, linestyle=':', linewidth=0.5, zorder=2)
    gl = ax.gridlines(draw_labels=True, linestyle='--', alpha=0.5, zorder=3)
    gl.top_labels = False
    gl.right_labels = False
    gl.xformatter = LONGITUDE_FORMATTER
    gl.yformatter = LATITUDE_FORMATTER
    
    # 提取当前日期的GPM降水异常数据
    gpm_day = ds_gpm['er'].sel(time=target_date, method='nearest')
    
    # 检查降水数据是否有效
    if gpm_day.size == 0 or np.isnan(gpm_day.values).all():
        print(f"警告: {target_date} 没有降水异常数据，跳过绘图")
        plt.close()
        continue
    
    # 绘制降水异常填色图（只显示正值）
    precip_plot = ax.pcolormesh(
        gpm_day.lon.values,
        gpm_day.lat.values,
        gpm_day.values,
        cmap=cmap_custom,
        vmin=0,
        vmax=precip_max,
        transform=ccrs.PlateCarree(),
        zorder=1,
        shading='auto'
    )
    
    # 提取当前日期的风场异常数据
    u_day = ds_wind['u_er'].sel(time=target_date, method='nearest')
    v_day = ds_wind['v_er'].sel(time=target_date, method='nearest')
    
    # 检查风场数据是否有效
    if u_day.size == 0 or v_day.size == 0 or np.isnan(u_day.values).all() or np.isnan(v_day.values).all():
        print(f"警告: {target_date} 没有风场数据，跳过风矢量绘制")
    else:
        # 稀疏化处理 - 每2个数据点取一个（增加密度）
        skip = 5
        u_sub = u_day.isel(longitude=slice(None, None, skip), 
                           latitude=slice(None, None, skip))
        v_sub = v_day.isel(longitude=slice(None, None, skip), 
                           latitude=slice(None, None, skip))
        lon_sub = u_day.longitude.isel(longitude=slice(None, None, skip)).values
        lat_sub = u_day.latitude.isel(latitude=slice(None, None, skip)).values
        
        # 确保有足够的数据点
        if u_sub.size > 0 and v_sub.size > 0:
            # 固定scale值，确保所有图比例尺一致
            scale_factor = 10 * (5.5 / wind_max)  # 使用固定比例
            
            # 绘制风矢量
            q = ax.quiver(
                lon_sub, 
                lat_sub, 
                u_sub.values,
                v_sub.values,
                scale=scale_factor,
                scale_units='inches',
                color='black',
                pivot='middle',
                width=0.002,
                headwidth=3,
                headlength=4,
                transform=ccrs.PlateCarree(),
                zorder=4
            )
            
            # 添加矢量比例尺（使用固定风速）
            ax.quiverkey(q, X=0.7, Y=0.8, U=wind_max,
                         label=f'{wind_max} m/s', labelpos='E', 
                         coordinates='figure', fontproperties={'size': 10})
    
    # 设置标题和范围
    ax.set_title(f"ER-filtered Daily Precipitation Anomaly and 850hPa Wind Anomaly\n{target_date.strftime('%Y-%m-%d')}", 
                 fontsize=14, pad=20)
    ax.set_extent([lon_range[0], lon_range[1], lat_range[0], lat_range[1]])
    ax.set_ylim(lat_range)
    
    # 添加色标
    cbar = plt.colorbar(precip_plot, ax=ax, shrink=0.8, extend='max')
    cbar.set_label('Precipitation Anomaly (mm)', fontsize=12)
    
    # 保存图形
    output_path = os.path.join(output_dir, f"ER_Anomaly_{target_date.strftime('%Y%m%d')}.png")
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.show()
    plt.close()
    print(f"已保存: {output_path}")

print("\n绘图完成！所有结果已保存至:", output_dir)

# 关闭数据集
ds_gpm.close()
ds_wind.close()