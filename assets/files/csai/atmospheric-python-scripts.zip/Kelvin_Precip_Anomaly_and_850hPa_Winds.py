# -*- coding: utf-8 -*-
"""
Created on Sun Jun 22 20:06:08 2025

@author: Dell
"""

import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import os
import pandas as pd
from datetime import datetime, timedelta
from matplotlib.colors import LinearSegmentedColormap
import matplotlib as mpl

# 设置绘图参数
plt.rcParams['font.family'] = 'Arial'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.titlepad'] = 15

# 定义地图范围
lon_range = [80, 150]  # 80°E ~ 150°E
lat_range = [-30, 10]   # 30°S ~ 10°N

# 自定义颜色映射 - 蓝色渐变 (只显示正值)
colors = [
    '#FFFFFF',  # 0 mm (白)
    '#D4EBFF',  # 极浅蓝
    '#99CCFF',  # 浅蓝
    '#66B2FF',  # 中等蓝
    '#3399FF',  # 标准蓝
    '#0066CC'   # 深蓝
]
cmap_precip = LinearSegmentedColormap.from_list('precip_anomaly', colors, N=256)
cmap_precip.set_under('white')  # 负值设为透明

# 加载数据
print("Loading data...")
# 1. 加载风场U分量实际值
ds_u = xr.open_dataset(r"D:\Freddy_ChenYong\Codes_Matlab\New_codes\ERA5_U_Kelvin_850hPa_20230101_20230331.nc")
# 2. 加载风场V分量实际值
ds_v = xr.open_dataset(r"D:\Freddy_ChenYong\Codes_Matlab\New_codes\ERA5_V_Kelvin_850hPa_20230101_20230331.nc")
# 3. 加载降水异常值
ds_precip = xr.open_dataset(r"D:\Freddy_ChenYong\Codes_Matlab\New_codes\GPM_Kelvin_20230101_20230331_merged.nc4")

# 修正时间坐标问题
print("Correcting time coordinates...")
# 创建正确的时间坐标: 2023-01-01 到 2023-03-31, 每小时一次
start_date = np.datetime64('2023-01-01T00:00:00')
end_date = np.datetime64('2023-03-31T23:00:00')
num_hours = int((end_date - start_date) / np.timedelta64(1, 'h')) + 1
correct_times = pd.date_range(start='2023-01-01', periods=num_hours, freq='H')

# 为ERA5数据分配正确的时间坐标
ds_u = ds_u.assign_coords(time=correct_times)
ds_v = ds_v.assign_coords(time=correct_times)

# 重新采样为日平均
print("Resampling to daily mean...")
u_daily = ds_u['kelvin'].resample(time='1D').mean()
v_daily = ds_v['kelvin'].resample(time='1D').mean()

# 选择时间段: 2023-02-01 到 2023-02-10
start_date_str = '2023-02-01'
end_date_str = '2023-02-10'
u_sub = u_daily.sel(time=slice(start_date_str, end_date_str))
v_sub = v_daily.sel(time=slice(start_date_str, end_date_str))
precip_sub = ds_precip['kelvin'].sel(time=slice(start_date_str, end_date_str))

# 确保所有数据集的时间坐标一致
u_sub = u_sub.assign_coords(time=precip_sub.time.values)
v_sub = v_sub.assign_coords(time=precip_sub.time.values)

# 确定降水异常的统一色标范围 (只考虑正值)
precip_positive = precip_sub.where(precip_sub > 0)
vmax = 20  # 获取最大正值
if vmax < 10:
    vmax = 10  # 确保最小值

# 创建输出目录
output_dir = r"D:\Freddy_ChenYong\Plot_ChenYong\Figures_Kelvin_Precip_Anomaly_and_850hPa_Winds"
os.makedirs(output_dir, exist_ok=True)
print(f"Output directory: {output_dir}")

# 循环处理每一天
for i, target_date in enumerate(precip_sub.time):
    date_str = pd.to_datetime(str(target_date.values)).strftime('%Y-%m-%d')
    print(f"Processing {date_str}...")
    
    # 获取当天数据
    precip_day = precip_sub.sel(time=target_date, method='nearest')  # 降水异常
    u_day = u_sub.sel(time=target_date, method='nearest')  # 风场实际值
    v_day = v_sub.sel(time=target_date, method='nearest')  # 风场实际值
    
    # 只保留降水正值 (负值设为NaN)
    precip_positive = precip_day.where(precip_day > 0)
    
    # 创建图形
    fig = plt.figure(figsize=(12, 8))
    ax = fig.add_subplot(1, 1, 1, projection=ccrs.PlateCarree())
    
    # 添加地理要素
    ax.add_feature(cfeature.COASTLINE, linewidth=0.8, edgecolor='dimgray')
    ax.add_feature(cfeature.BORDERS, linestyle=':', linewidth=0.5, edgecolor='dimgray')
    ax.add_feature(cfeature.LAND, facecolor='lightgray', alpha=0.5)
    
    # 添加网格线
    gl = ax.gridlines(draw_labels=True, linewidth=0.5, color='gray', alpha=0.5, linestyle='--')
    gl.top_labels = False
    gl.right_labels = False
    gl.xlabel_style = {'size': 9}
    gl.ylabel_style = {'size': 9}
    
    # 绘制降水异常 (只显示正值)
    precip_plot = ax.pcolormesh(
        precip_day.lon, precip_day.lat, precip_positive,
        cmap=cmap_precip,
        vmin=0,
        vmax=vmax,
        transform=ccrs.PlateCarree(),
        shading='auto'
    )
    
    # 绘制风场实际值 (稀疏处理)
    # 使用正确的坐标名称：ERA5数据使用'longitude'和'latitude'
    skip = 8  # 每4个点取一个 (0.25°分辨率 -> 2°间隔)
    
    # 检查坐标名称并选择正确的坐标
    u_lon = u_day.longitude if 'longitude' in u_day.coords else u_day.lon
    u_lat = u_day.latitude if 'latitude' in u_day.coords else u_day.lat
    
    # 计算风速大小用于缩放
    wind_speed = np.sqrt(u_day.values**2 + v_day.values**2)
    
    # 关键修改：调整比例尺使箭头更长更清晰
    # 减小scale值使箭头变长，同时减小width使箭头更细
    q = ax.quiver(
        u_lon[::skip], 
        u_lat[::skip],
        u_day.values[::skip, ::skip],
        v_day.values[::skip, ::skip],
        scale=25,  # 减小此值使箭头更长（原为150）
        scale_units='inches',
        color='black',
        transform=ccrs.PlateCarree(),
        width=0.002,  # 减小宽度使箭头更细（原为0.003）
        headwidth=3,
        headlength=4,
        headaxislength=3.5
    )
    
    # 添加矢量比例尺 (5.5 m/s)
    ax.quiverkey(q, X=0.85, Y=1.05, U=5.5, 
                 label='5.5 m/s', labelpos='E', coordinates='axes',
                 fontproperties={'size': 9}, labelsep=0.05)
    
    # 设置标题
    ax.set_title(f"Precipitation Anomalies and 850hPa Winds(Kelvin)\n{date_str}", 
                 fontsize=12, fontweight='bold')
    
    # 设置地图范围
    ax.set_extent([lon_range[0], lon_range[1], lat_range[0], lat_range[1]], crs=ccrs.PlateCarree())
    
    # 添加色标
    cbar = plt.colorbar(precip_plot, ax=ax, shrink=0.7, pad=0.05, extend='max')
    cbar.set_label('Precipitation Anomaly (mm/day)', fontsize=10)
    cbar.ax.tick_params(labelsize=9)
    
    # 保存图形
    output_path = os.path.join(output_dir, f"Kelvin_PrecipAnomaly_Winds_{date_str.replace('-', '')}.png")
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close(fig)

# 关闭数据集
ds_u.close()
ds_v.close()
ds_precip.close()

print("Processing completed! All figures saved to:", output_dir)