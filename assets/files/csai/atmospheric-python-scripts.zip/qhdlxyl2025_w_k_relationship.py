# -*- coding: utf-8 -*-
"""
Created on Mon Mar 10 14:53:23 2025

@author: Chen Yong
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import fsolve

# 定义方程
def dispersion_relation(omega, k):
    return omega**2 - k**2 - k/omega - 1

# 创建一个k的范围
k_values = np.linspace(0.1, 5, 400)  # 避免k=0，因为方程中有1/omega项

# 用于存储omega的值
omega_values = []

# 对于每个k值，求解对应的omega
for k in k_values:
    # 使用fsolve求解方程，初始猜测为1
    omega = fsolve(dispersion_relation, 1, args=(k,))
    omega_values.append(omega[0])

# 绘制频散关系图
plt.figure(figsize=(8, 6))
plt.plot(k_values, omega_values, label=r'$\omega(k)$')
plt.xlabel('Wave number $k$')
plt.ylabel('Frequency $\omega$')
plt.title('Dispersion Relation')
plt.grid(True)
plt.legend()
plt.show()