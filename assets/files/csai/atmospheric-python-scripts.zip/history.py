# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

## ---(Sat Oct 12 09:40:49 2024)---
runfile('C:/Users/Dell/.spyder-py3/temp.py', wdir='C:/Users/Dell/.spyder-py3')
pip install mapplotter -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com

## ---(Sat Oct 12 23:17:26 2024)---
import xarray as xr
ds = xr.open_dataset('D:\MATLAB\Freddy\ERA5_data\202301.nc')
ds = xr.open_dataset(r'D:\MATLAB\Freddy\ERA5_data\202301.nc')
ds
runfile('C:/Users/Dell/.spyder-py3/temp.py', wdir='C:/Users/Dell/.spyder-py3')
ds[t]
ds.t
ds.z
ds = xr.open_dataset(r'D:\MATLAB\Freddy\ERA5_data\202301.nc')
ds.t
ds.z
ds.q
ds.u
ds.v
ds.w
ds = xr.open_dataset(r'D:\MATLAB\Freddy\ERA5_data\data_stream-oper.nc')
ds
runfile('C:/Users/Dell/.spyder-py3/temp.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名0.py', wdir='C:/Users/Dell/.spyder-py3')

## ---(Sun Oct 13 16:47:00 2024)---
runfile('C:/Users/Dell/.spyder-py3/未命名0.py', wdir='C:/Users/Dell/.spyder-py3')
ds = .xr.open_dataset(r'D:\MATLAB\Freddy\ERA5_data\500hPa_geopotential_20230203_20230314.nc')
runfile('C:/Users/Dell/.spyder-py3/未命名0.py', wdir='C:/Users/Dell/.spyder-py3')
ds = .xr.open_dataset('D:\MATLAB\Freddy\ERA5_data\500hPa_geopotential_20230203_20230314.nc')
ds = xr.open_dataset(r'D:\MATLAB\Freddy\ERA5_data\500hPa_geopotential_20230203_20230314.nc')
ds
runfile('C:/Users/Dell/.spyder-py3/未命名0.py', wdir='C:/Users/Dell/.spyder-py3')
pip install Pillow
runfile('C:/Users/Dell/.spyder-py3/未命名1.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名0.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/gif_convert.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名2.py', wdir='C:/Users/Dell/.spyder-py3')

## ---(Sun Oct 13 21:48:29 2024)---
runfile('C:/Users/Dell/.spyder-py3/equipotential_height.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名0.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/gif_convert.py', wdir='C:/Users/Dell/.spyder-py3')
ds = xr.open_dataset(r'D:\MATLAB\Freddy\ERA5_data\sea_surface_temperature.nc')
ds
runfile('C:/Users/Dell/.spyder-py3/未命名1.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/file_rename.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名2.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/gif_convert.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名3.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/sst_and_sstanomaly.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/gif_convert.py', wdir='C:/Users/Dell/.spyder-py3')

## ---(Sun Oct 13 23:47:19 2024)---
ds = xr.open_dataset(r'D:\MATLAB\Freddy\ERA5_data\500hPa_U_V_wind.nc')
import xrray as xr
import xarray as xr
ds = xr.open_dataset(r'D:\MATLAB\Freddy\ERA5_data\500hPa_U_V_wind.nc')
ds
runfile('C:/Users/Dell/.spyder-py3/未命名0.py', wdir='C:/Users/Dell/.spyder-py3')

## ---(Wed Nov 13 19:37:17 2024)---
pip install scipy

## ---(Wed Nov 13 19:38:55 2024)---
runfile('C:/Users/Dell/.spyder-py3/未命名1.py', wdir='C:/Users/Dell/.spyder-py3')
pip install h5py

## ---(Wed Nov 13 19:55:01 2024)---
runfile('C:/Users/Dell/.spyder-py3/未命名0.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/transfer_mat_to_nc.py', wdir='C:/Users/Dell/.spyder-py3')
import xarray as xr
ds = xr.open_dataset(r"D:\MATLAB\Freddy\q_mjo.nc")
ds
runfile('C:/Users/Dell/.spyder-py3/read_mat.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名4.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名5.py', wdir='C:/Users/Dell/.spyder-py3')

## ---(Thu Nov 28 16:12:23 2024)---
runfile('C:/Users/Dell/.spyder-py3/未命名5.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/information_of_q_mjo_mat.py', wdir='C:/Users/Dell/.spyder-py3')

## ---(Tue Dec  3 22:27:07 2024)---
runfile('C:/Users/Dell/.spyder-py3/information_of_q_mjo_mat.py', wdir='C:/Users/Dell/.spyder-py3')

## ---(Wed Dec  4 08:56:47 2024)---
runfile('C:/Users/Dell/.spyder-py3/information_of_q_mjo_mat.py', wdir='C:/Users/Dell/.spyder-py3')

## ---(Wed Dec  4 09:45:33 2024)---
runfile('C:/Users/Dell/.spyder-py3/information_of_q_mjo_mat.py', wdir='C:/Users/Dell/.spyder-py3')
import xarray
import xarray as xr
ds = xr.open_dataset("D:\MATLAB\Freddy\q_mjo.nc")
ds = xr.open_dataset(r"D:\MATLAB\Freddy\q_mjo.nc")
ds
ds.q_mjo.q_mjo_dim0
ds.q_mjo.q_mjo_dim1
runfile('C:/Users/Dell/.spyder-py3/未命名6.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名5.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/q_mjo_500hPa.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名8.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/q_mjo_850hPa.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/q_mjo_500hPa.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/q_mjo_200hPa.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/information_of_q_mjo_mat.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名9.py', wdir='C:/Users/Dell/.spyder-py3')
pip install Basemap
runfile('C:/Users/Dell/.spyder-py3/未命名9.py', wdir='C:/Users/Dell/.spyder-py3')
pip install Basemap
runfile('C:/Users/Dell/.spyder-py3/未命名9.py', wdir='C:/Users/Dell/.spyder-py3')

## ---(Wed Dec  4 18:14:10 2024)---
runfile('C:/Users/Dell/.spyder-py3/w_mjo_500hPa.py', wdir='C:/Users/Dell/.spyder-py3')
pip install mpl_toolkits

## ---(Wed Dec  4 18:15:19 2024)---
runfile('C:/Users/Dell/.spyder-py3/w_mjo_500hPa.py', wdir='C:/Users/Dell/.spyder-py3')
pip install basemap

## ---(Wed Dec  4 18:16:35 2024)---
runfile('C:/Users/Dell/.spyder-py3/w_mjo_500hPa.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/information_of_q_mjo_mat.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/w_mjo_500hPa.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/information_of_q_mjo_mat.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/w_mjo_500hPa.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名1.py', wdir='C:/Users/Dell/.spyder-py3')
help(pcolormesh)
runfile('C:/Users/Dell/.spyder-py3/未命名1.py', wdir='C:/Users/Dell/.spyder-py3')

## ---(Thu Dec  5 02:01:20 2024)---
runfile('C:/Users/Dell/.spyder-py3/w_mjo_500hPa.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/information_of_q_mjo_mat.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名1.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名2.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/w_mjo_850hPa.py', wdir='C:/Users/Dell/.spyder-py3')

## ---(Mon Mar 10 21:32:59 2025)---
runfile('C:/Users/Dell/.spyder-py3/q_mjo_850hPa.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/gif_convert.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/file_rename.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/gif_convert.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/file_rename.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名1.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/gif_convert.py', wdir='C:/Users/Dell/.spyder-py3')

## ---(Tue Mar 11 08:39:10 2025)---
import xarray as xr
ds = xr.open_dataset(r'D:\MATLAB\Freddy\IBTrACS.since1980.v04r01.nc')
ds
runfile('C:/Users/Dell/.spyder-py3/未命名0.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/track_of_Freddy_everyday.py', wdir='C:/Users/Dell/.spyder-py3')
data['sid' = '2023061S22036']
runfile('C:/Users/Dell/.spyder-py3/track_of_Freddy_everyday.py', wdir='C:/Users/Dell/.spyder-py3')
print(data['sid'].values)
print(freddy_data)
print(times)
print(lats)
print(lons)
print(start_date)
print(times)
data
runfile('C:/Users/Dell/.spyder-py3/track_of_Freddy_everyday.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名1.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/q_850hPa_with_track.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/file_rename2.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/gif_convert.py', wdir='C:/Users/Dell/.spyder-py3')

## ---(Tue Mar 11 15:46:29 2025)---
q_mjo = np.array(f['w_mjo'])  # 读取变量 q_mjo
runcell(0, 'C:/Users/Dell/.spyder-py3/w_mjo_500hPa.py')
runfile('C:/Users/Dell/.spyder-py3/w_mjo_500hPa.py', wdir='C:/Users/Dell/.spyder-py3')
q_mjo
python -V
import scipy.io
data = scipy.io.loadmat(r"D:\MATLAB\Freddy\w_mjo.mat")
import h5py
runfile('C:/Users/Dell/.spyder-py3/未命名1.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名2.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名3.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/file_rename2.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/gif_convert.py', wdir='C:/Users/Dell/.spyder-py3')

## ---(Wed Mar 12 00:22:15 2025)---
runfile('C:/Users/Dell/.spyder-py3/未命名0.py', wdir='C:/Users/Dell/.spyder-py3')
data
runfile('C:/Users/Dell/.spyder-py3/未命名0.py', wdir='C:/Users/Dell/.spyder-py3')

## ---(Wed Mar 12 20:44:19 2025)---
runfile('C:/Users/Dell/.spyder-py3/Initial_phase_environmental_field_uv.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名0.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/Initial_phase_environmental_field_uv.py', wdir='C:/Users/Dell/.spyder-py3')

## ---(Wed Mar 12 21:41:14 2025)---
runfile('C:/Users/Dell/.spyder-py3/Initial_phase_environmental_field_uv.py', wdir='C:/Users/Dell/.spyder-py3')
ds
data = xr.open_dataset(r'D:/MATLAB/Freddy/IBTrACS.SI.v04r01.nc')
data
runfile('C:/Users/Dell/.spyder-py3/未命名0.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名2.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/未命名1.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/q_r_850hPa_500hPa.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/q_r_850hPa_500hPa_with_track.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/q_r_850hPa_500hPa.py', wdir='C:/Users/Dell/.spyder-py3')
runfile('C:/Users/Dell/.spyder-py3/q_r_850hPa_500hPa_with_track.py', wdir='C:/Users/Dell/.spyder-py3')

## ---(Thu Mar 13 09:31:22 2025)---
runfile('C:/Users/Dell/.spyder-py3/q_r_850hPa_500hPa_with_track.py', wdir='C:/Users/Dell/.spyder-py3')