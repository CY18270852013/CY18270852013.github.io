import numpy as np
import matplotlib.pyplot as plt

# 文件路径
file_path = r'C:\Users\Chen Yong\Desktop\Temperature_distribution_2.txt'

# 初始化变量
cases = []
current_case = None
temperature_data = []

# 解析文件内容
with open(file_path, 'r') as f:
    lines = f.readlines()
    for line in lines:
        line = line.strip()
        if line.startswith("Case:"):
            # 保存上一个 case 的数据
            if current_case:
                current_case["temperature"] = np.array(temperature_data)
                cases.append(current_case)
            # 解析新的 case
            parts = line.split()
            case_number = int(parts[1])
            nx = int(parts[3])
            dx = float(parts[5])
            dt = float(parts[7])
            r = float(parts[9])
            current_case = {
                "label": f"Case {case_number}: nx={nx}, dx={dx:.3e}, dt={dt:.3e}, r={r:.2f}",
                "nx": nx,
                "dx": dx,
                "dt": dt,
                "temperature": None
            }
            temperature_data = []
        elif line.startswith("Temperature distribution at"):
            # 跳过该行，不处理
            continue
        elif line:  # 处理数值行
            try:
                temperature_data.append(float(line))
            except ValueError:
                print(f"Skipping invalid line: {line}")
    # 保存最后一个 case 的数据
    if current_case:
        current_case["temperature"] = np.array(temperature_data)
        cases.append(current_case)

# 绘制温度分布
plt.figure(figsize=(12, 8))
for case in cases:
    x = np.linspace(0, 1, case["nx"])
    plt.plot(x, case["temperature"], label=case["label"])

# 设置图例、标签和标题
plt.title("Temperature Distribution After 5000 Seconds for Different Grid Resolutions")
plt.xlabel("Position (m)")
plt.ylabel("Temperature (°C)")
plt.legend(loc="upper right", fontsize=8)
plt.grid(True)

# 显示图形
plt.show()
