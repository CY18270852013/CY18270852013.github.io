import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import linregress
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import pandas as pd

# 加载数据
file_path = r"C:\Users\Chen Yong\Downloads\ERA5 data\ERA5 data\2000-2021_Q_1000-100hPa_monthly.nc"
ds = xr.open_dataset(file_path)

# 将 'date' 转换为 datetime 格式
ds['date'] = pd.to_datetime(ds.date, format='%Y%m%d')

# 定义气压层和年份
pressure_levels = [1000, 850, 500]

# 计算逐年平均比湿
annual_mean = ds.q.groupby("date.year").mean(dim="date")

# 定义颜色范围
cmap = 'coolwarm'

# 函数：绘制逐年平均比湿变化趋势图
def plot_trend(data, level):
    # 初始化趋势数组
    trend = np.zeros((data.latitude.size, data.longitude.size))

    # 获取年份序列
    years = data.year.values

    # 遍历每个纬度和经度点，计算趋势
    for i in range(data.latitude.size):
        for j in range(data.longitude.size):
            # 获取逐年比湿值序列
            y = data[:, i, j]
            # 对每个网格点计算线性回归的斜率
            slope, _, _, _, _ = linregress(years, y)
            trend[i, j] = slope  # 存储斜率
    
    # 设置颜色柱范围，根据trend的最小值和最大值进行适配
    vmin, vmax = np.percentile(trend, 2), np.percentile(trend, 98)  # 排除极值影响，使用2%~98%的范围

    # 绘制趋势图
    fig, ax = plt.subplots(figsize=(10, 6), subplot_kw={'projection': ccrs.PlateCarree()})
    im = ax.contourf(data.longitude, data.latitude, trend, levels=20, cmap=cmap, transform=ccrs.PlateCarree(), vmin=vmin, vmax=vmax)
    ax.coastlines()
    ax.add_feature(cfeature.BORDERS, linestyle=':')
    ax.gridlines(draw_labels=True, linewidth=0.5, color='gray', alpha=0.5, linestyle='--')
    plt.colorbar(im, ax=ax, orientation='vertical', pad=0.05, label='Trend (g/kg per year)')
    ax.set_title(f'{level} hPa Specific Humidity Trend (2000-2021)')
    plt.show()

# 对每个气压层绘制逐年比湿变化趋势
for level in pressure_levels:
    plot_trend(annual_mean.sel(pressure_level=level), level)
