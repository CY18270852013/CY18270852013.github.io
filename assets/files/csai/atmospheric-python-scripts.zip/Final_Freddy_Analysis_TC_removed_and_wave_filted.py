# -*- coding: utf-8 -*-
"""
Created on Tue May  6 00:42:49 2025

@author: Dell
"""

import numpy as np
import xarray as xr
import cartopy.crs as ccrs
import matplotlib.pyplot as plt
import pandas as pd

# ====================
# 1. 增强型数据预处理
# ====================
def enhanced_preprocess(ds):
    """维度感知型预处理函数"""
    # 自动识别标准坐标
    coord_map = {
        'latitude': ['lat', 'latitude', 'lats'],
        'longitude': ['lon', 'longitude', 'lons'],
        'time': ['time', 'valid_time', 'date_time']
    }
    
    # 动态重命名坐标
    for std_name, variants in coord_map.items():
        for var in variants:
            if var in ds.coords:
                if var != std_name:
                    ds = ds.rename({var: std_name})
                break
    
    # 经度标准化
    if 'longitude' in ds.coords and ds.longitude.max() > 180:
        ds = ds.assign_coords(longitude=(ds.longitude + 180) % 360 - 180)
        ds = ds.sortby('longitude')
    
    # 智能维度排序（保留原始维度结构）
    required_dims = ['time', 'latitude', 'longitude']
    existing_dims = [dim for dim in required_dims if dim in ds.dims]
    extra_dims = [dim for dim in ds.dims if dim not in required_dims]
    
    # 重新排列维度顺序
    new_order = existing_dims + extra_dims
    return ds.transpose(*new_order)

# ====================
# 2. 数据加载与处理
# ====================
# 处理TC数据
ibtracs = xr.open_dataset(r"D:\Freddy_ChenYong\Data\IBTrACS.SI.v04r01.nc")
ibtracs = enhanced_preprocess(ibtracs)
freddy = ibtracs.where(ibtracs.sid == b'2023036S12117', drop=True).squeeze('storm', drop=True)

# 处理ERA5数据（解决多维度问题）
era5 = xr.open_dataset(
    r"D:\Freddy_ChenYong\Data\ERA5_Initial_phase_environmental_field_hourly.nc",
    decode_times=True
).pipe(enhanced_preprocess)

# 正确提取850hPa风场（保持维度兼容性）
u850 = era5['u'].sel(pressure_level=850, method='nearest').squeeze('pressure_level', drop=True)
v850 = era5['v'].sel(pressure_level=850, method='nearest').squeeze('pressure_level', drop=True)

# 处理GPM数据
gpm_files = [
    rf"D:\Freddy_ChenYong\Data\GPM_3IMERGDF_07-20230201_20230331\3B-DAY.MS.MRG.3IMERG.{d.strftime('%Y%m%d')}-S000000-E235959.V07B.nc4" 
    for d in pd.date_range("2023-02-01", "2023-03-31")
]
gpm = xr.open_mfdataset(gpm_files, combine='by_coords', preprocess=enhanced_preprocess)
gpm = gpm.rename({'precipitation': 'prcp'})

# ====================
# 3. 维度安全TC移除函数
# ====================
def dimension_safe_tc_remove(var_data, tc_data, radius=1000):
    """
    多维兼容版信号移除核心算法
    关键改进：
    1. 自动处理多维度数据
    2. 动态网格生成
    3. 智能维度广播
    """
    # 验证输入维度
    if 'time' not in var_data.dims:
        raise ValueError("输入数据必须包含时间维度")
    
    # 自动识别空间维度
    lat_dim = next((dim for dim in ['latitude', 'lat'] if dim in var_data.dims), None)
    lon_dim = next((dim for dim in ['longitude', 'lon'] if dim in var_data.dims), None)
    
    # 生成动态网格
    lon = var_data[lon_dim].values
    lat = var_data[lat_dim].values
    glon, glat = np.meshgrid(lon, lat, indexing='xy')  # 地理坐标索引
    
    # 初始化权重场（保持原始维度结构）
    weights = xr.ones_like(var_data)
    
    # 处理每个TC时次
    for t in range(len(tc_data.date_time)):
        # 提取TC信息
        tc_time = tc_data.time.isel(date_time=t).item()
        tc_lon = float(tc_data.longitude.isel(date_time=t))
        tc_lat = float(tc_data.latitude.isel(date_time=t))
        
        # 计算距离场
        dx = (glon - tc_lon) * np.cos(np.deg2rad(tc_lat)) * 111
        dy = (glat - tc_lat) * 111
        dist_km = np.sqrt(dx**2 + dy**2)
        
        # 创建高斯权重模板
        bell = np.exp(-(dist_km**2)/(2*(radius**2)))
        
        # 动态构建DataArray
        bell_da = xr.DataArray(
            bell,
            dims=(lat_dim, lon_dim),
            coords={lat_dim: var_data[lat_dim], lon_dim: var_data[lon_dim]}
        )
        
        # 时间对齐
        try:
            time_idx = var_data.time.get_index('time').get_loc(pd.Timestamp(tc_time), method='nearest')
        except KeyError:
            continue
        
        # 应用权重（智能广播机制）
        weights.loc[{lat_dim: slice(None), lon_dim: slice(None), 'time': time_idx}] *= (1 - bell_da)
    
    return var_data * weights

# ====================
# 4. 数据对齐与处理
# ====================
# 统一时间轴
common_time = xr.DataArray(
    pd.date_range("2023-02-01", "2023-03-31"),
    dims=['time'],
    name='time'
)

# 数据重采样与对齐
era5_daily = era5.resample(time='1D').mean().transpose('time', 'latitude', 'longitude')
gpm_regrid = gpm['prcp'].interp(
    longitude=era5_daily.longitude,
    latitude=era5_daily.latitude,
    method='nearest'
).pipe(enhanced_preprocess)

# 计算气候异常
gpm_clim = gpm_regrid.groupby('time.dayofyear').mean(dim='time', skipna=False)
gpm_anom = gpm_regrid.groupby('time.dayofyear') - gpm_clim

# 执行信号移除
print("正在执行安全信号移除...")
gpm_clean = dimension_safe_tc_remove(
    gpm_anom.sel(time=common_time, method='nearest').transpose('time', 'latitude', 'longitude'), 
    freddy, 
    radius=500
)

u850_clean = dimension_safe_tc_remove(
    u850.sel(time=common_time, method='nearest').transpose('time', 'latitude', 'longitude'),
    freddy,
    radius=1000
)

v850_clean = dimension_safe_tc_remove(
    v850.sel(time=common_time, method='nearest').transpose('time', 'latitude', 'longitude'),
    freddy,
    radius=1000
)

# ====================
# 5. 维度安全可视化
# ====================
def safe_visualization(data_dict, output_path):
    """多维兼容可视化函数"""
    plt.figure(figsize=(18, 12))
    
    configs = {
        'mjo': {'pos': 1, 'title': 'MJO滤波异常场'},
        'ccerw': {'pos': 2, 'title': '赤道Rossby波'},
        'mrg': {'pos': 3, 'title': '混合Rossby重力波'}
    }
    
    for wave_type, cfg in configs.items():
        ax = plt.subplot(3, 1, cfg['pos'], projection=ccrs.PlateCarree())
        ax.set_extent([30, 100, -40, 0], crs=ccrs.PlateCarree())
        
        # 处理降水数据
        prcp = data_dict[wave_type]['prcp'].mean(dim='time')
        prcp.plot(
            ax=ax,
            x='longitude', y='latitude',
            cmap='RdBu_r', vmin=-15, vmax=15,
            transform=ccrs.PlateCarree(),
            add_colorbar=False
        )
        
        # 处理风场数据
        u_mean = data_dict[wave_type]['u'].mean(dim='time')
        v_mean = data_dict[wave_type]['v'].mean(dim='time')
        
        stride = 6
        q = ax.quiver(
            u_mean.longitude[::stride],
            u_mean.latitude[::stride],
            u_mean[::stride, ::stride],
            v_mean[::stride, ::stride],
            scale=250,
            color='k',
            transform=ccrs.PlateCarree()
        )
        
        ax.coastlines()
        ax.set_title(cfg['title'], fontsize=12)
        
        if wave_type == 'mjo':
            cbar = plt.colorbar(ax.collections[0], ax=ax, orientation='horizontal', pad=0.05)
            cbar.set_label('降水异常 (mm/day)', fontsize=10)
        
        plt.quiverkey(q, 0.85, 0.15, 5, '5 m/s', labelpos='E', fontproperties={'size': 10})
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    print(f"结果已保存至：{output_path}")

# 执行可视化
plot_data = {
    'mjo': {'prcp': gpm_clean, 'u': u850_clean, 'v': v850_clean}
}
safe_visualization(plot_data, 'Final_Freddy_Analysis.png')