import numpy as np
import netCDF4 as nc
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from datetime import datetime, timedelta

# 设置文件路径
anomaly_file = "E:/u_v_anomaly/u_v_anomaly_20230101_20230331.nc"

# 选择验证点 (南印度洋热带气旋活动区域)
val_lon = 60.0  # 东经60度
val_lat = -15.0  # 南纬15度
val_level = 850  # 850 hPa (热带气旋关键层次)

# 选择验证时间 (热带气旋Freddy活动期间)
val_time = datetime(2023, 2, 20, 12)  # 2023年2月20日12UTC

# 1. 读取异常值数据
ds_anom = nc.Dataset(anomaly_file)

# 获取维度和变量
times = ds_anom['time'][:]
levels = ds_anom['level'][:]
lats = ds_anom['lat'][:]
lons = ds_anom['lon'][:]
u_anom = ds_anom['u_anomaly'][:]
v_anom = ds_anom['v_anomaly'][:]

# 打印文件维度信息
print("异常值文件维度信息:")
print(f"经度数量: {len(lons)}, 纬度数量: {len(lats)}, 层次数量: {len(levels)}, 时间数量: {len(times)}")

# 转换时间为datetime对象
base_time = datetime(2023, 1, 1)
time_dts = [base_time + timedelta(hours=float(t)) for t in times]

# 2. 时间序列验证 - 特定位置和高度
# 查找验证点的索引
lon_idx = np.abs(lons - val_lon).argmin()
lat_idx = np.abs(lats - val_lat).argmin()
level_idx = np.abs(levels - val_level).argmin()

print(f"验证点索引: lon={lon_idx}({lons[lon_idx]}), lat={lat_idx}({lats[lat_idx]}), level={level_idx}({levels[level_idx]}hPa)")

# 提取该点的异常值时间序列
u_anom_ts = u_anom[:, level_idx, lat_idx, lon_idx]
v_anom_ts = v_anom[:, level_idx, lat_idx, lon_idx]

# 3. 统计验证
# 创建掩码排除填充值
u_anom_mask = np.where(u_anom > -9999, u_anom, np.nan)
v_anom_mask = np.where(v_anom > -9999, v_anom, np.nan)

u_anom_mean = np.nanmean(u_anom_mask)
u_anom_std = np.nanstd(u_anom_mask)
v_anom_mean = np.nanmean(v_anom_mask)
v_anom_std = np.nanstd(v_anom_mask)

# 4. 验证特定时间点的异常值
# 查找验证时间的索引
time_diff = np.abs([(t - val_time).total_seconds() for t in time_dts])
time_idx = np.argmin(time_diff)
actual_time = time_dts[time_idx]
print(f"验证时间: {val_time}, 最接近的文件时间: {actual_time}, 时间差: {time_diff[time_idx]}秒")

# 提取验证时间的异常值
u_anom_val = u_anom[time_idx]  # 形状: (level, lat, lon)
v_anom_val = v_anom[time_idx]  # 形状: (level, lat, lon)

# 结果可视化
plt.figure(figsize=(15, 10))

# 时间序列图
plt.subplot(2, 2, 1)
plt.plot(time_dts, u_anom_ts, 'r-', label='Anomaly U')
plt.axhline(0, color='k', linestyle='--', alpha=0.5)
plt.title(f'U Anomaly at {val_lon}E, {val_lat}N, {val_level}hPa')
plt.ylabel('m/s')
plt.legend()
plt.grid(True)
plt.xticks(rotation=45)

plt.subplot(2, 2, 2)
plt.plot(time_dts, v_anom_ts, 'r-', label='Anomaly V')
plt.axhline(0, color='k', linestyle='--', alpha=0.5)
plt.title(f'V Anomaly at {val_lon}E, {val_lat}N, {val_level}hPa')
plt.ylabel('m/s')
plt.legend()
plt.grid(True)
plt.xticks(rotation=45)

# 异常值统计直方图
plt.subplot(2, 2, 3)
plt.hist(u_anom_mask.flatten(), bins=100, alpha=0.7, color='blue', range=(-15, 15))
plt.axvline(u_anom_mean, color='r', linestyle='--', label=f'Mean: {u_anom_mean:.2f}')
plt.axvline(u_anom_mean + u_anom_std, color='k', linestyle=':', label=f'±1 STD: {u_anom_std:.2f}')
plt.axvline(u_anom_mean - u_anom_std, color='k', linestyle=':')
plt.title('U Anomaly Distribution')
plt.xlabel('m/s')
plt.ylabel('Frequency')
plt.legend()
plt.grid(True)

plt.subplot(2, 2, 4)
plt.hist(v_anom_mask.flatten(), bins=100, alpha=0.7, color='green', range=(-15, 15))
plt.axvline(v_anom_mean, color='r', linestyle='--', label=f'Mean: {v_anom_mean:.2f}')
plt.axvline(v_anom_mean + v_anom_std, color='k', linestyle=':', label=f'±1 STD: {v_anom_std:.2f}')
plt.axvline(v_anom_mean - v_anom_std, color='k', linestyle=':')
plt.title('V Anomaly Distribution')
plt.xlabel('m/s')
plt.ylabel('Frequency')
plt.legend()
plt.grid(True)

plt.tight_layout()
plt.savefig('anomaly_validation_part1.png', dpi=300, bbox_inches='tight')
plt.show()

# 空间分布图 - 850 hPa
plt.figure(figsize=(12, 10))

# 创建地图投影
proj = ccrs.PlateCarree()

# U异常空间分布
ax = plt.subplot(2, 1, 1, projection=proj)
ax.set_title(f'U Anomaly at 850 hPa - {actual_time.strftime("%Y-%m-%d %H:%M")}')
ax.add_feature(cfeature.COASTLINE)
ax.add_feature(cfeature.BORDERS, linestyle=':')
ax.gridlines(draw_labels=True, dms=True, x_inline=False, y_inline=False)

# 设置地图范围 (南印度洋)
ax.set_extent([30, 120, -35, 10], crs=proj)

# 绘制异常值
level_idx_850 = np.abs(levels - 850).argmin()
cf = ax.contourf(lons, lats, u_anom_val[level_idx_850], 
                levels=np.linspace(-10, 10, 21), cmap='coolwarm', extend='both')
plt.colorbar(cf, ax=ax, orientation='horizontal', label='m/s', pad=0.05)

# 标记验证点
ax.plot(val_lon, val_lat, 'ko', markersize=8, transform=proj)
ax.text(val_lon+2, val_lat, 'Validation Point', transform=proj, fontsize=10)

# V异常空间分布
ax = plt.subplot(2, 1, 2, projection=proj)
ax.set_title(f'V Anomaly at 850 hPa - {actual_time.strftime("%Y-%m-%d %H:%M")}')
ax.add_feature(cfeature.COASTLINE)
ax.add_feature(cfeature.BORDERS, linestyle=':')
ax.gridlines(draw_labels=True, dms=True, x_inline=False, y_inline=False)
ax.set_extent([30, 120, -35, 10], crs=proj)

cf = ax.contourf(lons, lats, v_anom_val[level_idx_850], 
                levels=np.linspace(-10, 10, 21), cmap='coolwarm', extend='both')
plt.colorbar(cf, ax=ax, orientation='horizontal', label='m/s', pad=0.05)
ax.plot(val_lon, val_lat, 'ko', markersize=8, transform=proj)
ax.text(val_lon+2, val_lat, 'Validation Point', transform=proj, fontsize=10)

plt.tight_layout()
plt.savefig('anomaly_validation_part2.png', dpi=300, bbox_inches='tight')
plt.show()

# 打印验证点详细数据
print("\n验证点详细数据:")
print(f"位置: 经度 {lons[lon_idx]}°E, 纬度 {lats[lat_idx]}°N, 层次 {levels[level_idx]}hPa")
print(f"时间: {actual_time}")
print(f"异常 U: {u_anom_ts[time_idx]:.2f} m/s")
print(f"异常 V: {v_anom_ts[time_idx]:.2f} m/s")

print("\n全局统计:")
print(f"U异常平均值: {u_anom_mean:.4f} m/s")
print(f"U异常标准差: {u_anom_std:.4f} m/s")
print(f"V异常平均值: {v_anom_mean:.4f} m/s")
print(f"V异常标准差: {v_anom_std:.4f} m/s")

# 关闭文件
ds_anom.close()