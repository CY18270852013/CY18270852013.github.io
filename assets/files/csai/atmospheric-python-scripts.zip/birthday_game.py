# -*- coding: utf-8 -*-
"""
Created on Sat Oct 18 22:44:04 2025

@author: Chen Yong
"""

import pygame
import sys
import random
import time
from pygame import mixer
import math
import os

# 初始化
pygame.init()
mixer.init()

# 屏幕设置
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("给小谢的特别生日惊喜")

# 颜色定义
BACKGROUND = (25, 25, 50)
TEXT_COLOR = (255, 215, 0)
HIGHLIGHT = (255, 105, 180)
BUTTON_COLOR = (70, 130, 180)
BUTTON_HOVER = (100, 160, 210)
CORRECT_COLOR = (100, 200, 100)
WRONG_COLOR = (220, 100, 100)

# 字体
title_font = pygame.font.SysFont("simhei", 44, bold=True)
main_font = pygame.font.SysFont("simhei", 20)
small_font = pygame.font.SysFont("simhei", 20)

# 加载资源
try:
    # 背景音乐 - 准备一首她喜欢的浪漫歌曲
    mixer.music.load(r"C:\Users\Chen Yong\Downloads\romanticMusic.mp3")  # 替换为实际文件路径
    mixer.music.set_volume(0.5)
    
    # 音效
    correct_sound = mixer.Sound("correct.wav")  # 正确回答音效
    heart_sound = mixer.Sound("heartbeat.wav")  # 心跳音效
except:
    print("音频文件加载失败，游戏将继续但没有声音")

# 游戏数据 - 根据你们的真实经历自定义
personal_questions = [
    {
        "question": "我跟你表白是在哪里？",
        "options": ["长江边", "明长城", "南大鼓楼校区", "南大仙林校区"],
        "correct": 0,
        "memory": "那天是2023年2月25号，看到江豚我们都很惊喜，从此各自生活出现一个重要的ta...",
        "hint": "那里有江水和可爱的江豚"
    },
    {
        "question": "我们一起去西湖停车费多少钱？",
        "options": ["120~130", "130~140", "140~150", "150~160"],
        "correct": 3,
        "memory": "进西湖前我们躺在车里午睡，看着你，我感到前所未有的幸福...",
        "hint": "数字有点高，但值得"
    },
    {
        "question": "下面哪个不是我对你叫过的称呼？",
        "options": ["小屁儿", "晶晶", "美晶", "sogei"],
        "correct": 2,
        "memory": "跟你说各种俏皮可爱的话是我最开心的事，喜欢跟你聊天...",
        "hint": "这个称呼有点太正式了"
    },
    {
        "question": "请选出下列4项中非只有我们知道的事情：",
        "options": ["酷根", "谁提分手先请吃饭", "ftx不举", "3个锦囊妙计"],
        "correct": 2,
        "memory": "未来我希望跟你拥有更多秘密，长相厮守...",
        "hint": "这个跟投资有关"
    },
    {
        "question": "打乒乓球我对你说过最多的话是什么？",
        "options": ["引拍", "你这打的啥呀", "呼~", "反手呢"],
        "correct": 0,
        "memory": "最最开心的瞬间就是我跟你打球你打出漂亮球的时候，爽！以后要跟你开发更多爱好...",
        "hint": "这是技术动作提醒"
    },
    {
        "question": "以下哪本书不是我大学期间看的且跟你分享过的？",
        "options": ["《小米创业思考》", "《硅谷钢铁侠》", "《少年的你，如此美丽》", "《薛兆丰经济学讲义》"],
        "correct": 2,
        "memory": "我要把每一本看过的好书都分享给你，一起实现认知飞跃...",
        "hint": "这是一本青春小说"
    },
]

# 添加一个隐藏关卡
hidden_level = {
    "type": "puzzle",
    "question": "拼出我们的秘密代码",
    "hint": "将以下字母重新排列成对我们有特殊意义的词",
    "scrambled": "BRCEU",
    "answer": "CUBER",
    "memory": "这是我们之间的秘密暗号，每次听到都让我心动..."
}

# 绘制按钮函数
def draw_button(text, x, y, width, height, hover=False, color=None):
    if color is None:
        color = BUTTON_HOVER if hover else BUTTON_COLOR
    pygame.draw.rect(screen, color, (x, y, width, height), border_radius=15)
    pygame.draw.rect(screen, TEXT_COLOR, (x, y, width, height), 3, border_radius=15)
    
    text_surf = main_font.render(text, True, TEXT_COLOR)
    text_rect = text_surf.get_rect(center=(x + width/2, y + height/2))
    screen.blit(text_surf, text_rect)
    
    return pygame.Rect(x, y, width, height)

# 绘制文字函数
def draw_text(text, font, color, x, y, centered=True):
    text_surf = font.render(text, True, color)
    if centered:
        text_rect = text_surf.get_rect(center=(x, y))
    else:
        text_rect = text_surf.get_rect(topleft=(x, y))
    screen.blit(text_surf, text_rect)
    return text_rect

# 绘制心形
def draw_heart(x, y, size, color, filled=True):
    points = []
    for angle in range(0, 360, 5):
        rad = math.radians(angle)
        px = x + size * 16 * math.sin(rad)**3
        py = y - size * (13 * math.cos(rad) - 5*math.cos(2*rad) - 2*math.cos(3*rad) - math.cos(4*rad))
        points.append((px, py))
    if len(points) > 2:
        if filled:
            pygame.draw.polygon(screen, color, points)
        else:
            pygame.draw.polygon(screen, color, points, 2)

# 绘制星星
def draw_star(x, y, size, color):
    points = []
    for i in range(5):
        # 外角
        outer_x = x + size * math.cos(math.pi/2 + 2*math.pi*i/5)
        outer_y = y - size * math.sin(math.pi/2 + 2*math.pi*i/5)
        points.append((outer_x, outer_y))
        
        # 内角
        inner_x = x + size/2 * math.cos(math.pi/2 + 2*math.pi*i/5 + math.pi/5)
        inner_y = y - size/2 * math.sin(math.pi/2 + 2*math.pi*i/5 + math.pi/5)
        points.append((inner_x, inner_y))
    
    pygame.draw.polygon(screen, color, points)

# 绘制烟花
def draw_firework(x, y, radius, color, time):
    # 烟花中心
    pygame.draw.circle(screen, color, (x, y), radius)
    
    # 烟花粒子
    for i in range(20):
        angle = random.uniform(0, 2*math.pi)
        distance = radius + random.uniform(5, 30) * (time % 1)
        px = x + distance * math.cos(angle)
        py = y + distance * math.sin(angle)
        particle_size = max(1, 3 - (time % 1) * 2)
        pygame.draw.circle(screen, color, (px, py), particle_size)

# 绘制进度条
def draw_progress_bar(progress, x, y, width, height):
    # 背景
    pygame.draw.rect(screen, (50, 50, 80), (x, y, width, height), border_radius=10)
    # 进度
    fill_width = int(width * progress)
    if fill_width > 0:
        pygame.draw.rect(screen, HIGHLIGHT, (x, y, fill_width, height), border_radius=10)
    # 边框
    pygame.draw.rect(screen, TEXT_COLOR, (x, y, width, height), 2, border_radius=10)

# 开场动画
def opening_animation():
    screen.fill(BACKGROUND)
    
    # 播放背景音乐
    try:
        mixer.music.play(-1)  # 循环播放
    except:
        pass
    
    # 显示标题
    title = "亲爱的小谢，请开启你的生日闯关挑战"
    subtitle = "回忆我们的点点滴滴，解锁特别惊喜"
    
    # 显示心形和星星动画
    hearts = []
    stars = []
    for _ in range(25):
        hearts.append({
            'x': random.randint(0, WIDTH),
            'y': random.randint(HEIGHT, HEIGHT+200),
            'size': random.uniform(0.1, 0.4),
            'speed': random.uniform(1, 3),
            'color': (random.randint(200, 255), random.randint(100, 180), random.randint(150, 220))
        })
    
    for _ in range(15):
        stars.append({
            'x': random.randint(0, WIDTH),
            'y': random.randint(0, HEIGHT),
            'size': random.uniform(0.5, 1.5),
            'twinkle_speed': random.uniform(0.05, 0.2),
            'brightness': random.uniform(0.3, 1.0)
        })
    
    start_time = time.time()
    while time.time() - start_time < 6:  # 6秒开场动画
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        
        screen.fill(BACKGROUND)
        
        # 绘制标题
        alpha = min(1.0, (time.time() - start_time) / 2)  # 渐入效果
        title_color = (TEXT_COLOR[0], TEXT_COLOR[1], TEXT_COLOR[2], int(255 * alpha))
        draw_text(title, title_font, title_color, WIDTH//2, HEIGHT//3)
        draw_text(subtitle, main_font, title_color, WIDTH//2, HEIGHT//3 + 60)
        
        # 绘制闪烁的星星
        for star in stars:
            brightness = star['brightness'] + math.sin(time.time() * star['twinkle_speed']) * 0.3
            brightness = max(0.3, min(1.0, brightness))
            color = (int(255 * brightness), int(255 * brightness), int(200 * brightness))
            draw_star(star['x'], star['y'], star['size'], color)
        
        # 绘制飘落的心形
        for heart in hearts:
            draw_heart(heart['x'], heart['y'], heart['size'], heart['color'])
            heart['y'] -= heart['speed']
            if heart['y'] < -20:
                heart['y'] = HEIGHT + 20
                heart['x'] = random.randint(0, WIDTH)
        
        # 显示开始提示
        if int((time.time() - start_time) * 2) % 2 == 0:  # 闪烁效果
            draw_text("点击任意位置开始", main_font, TEXT_COLOR, WIDTH//2, HEIGHT*2//3)
        
        pygame.display.flip()
        pygame.time.delay(30)
    
    # 等待点击
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN or event.type == pygame.KEYDOWN:
                waiting = False
        
        screen.fill(BACKGROUND)
        
        # 绘制星星
        for star in stars:
            brightness = star['brightness'] + math.sin(time.time() * star['twinkle_speed']) * 0.3
            brightness = max(0.3, min(1.0, brightness))
            color = (int(255 * brightness), int(255 * brightness), int(200 * brightness))
            draw_star(star['x'], star['y'], star['size'], color)
        
        draw_text(title, title_font, TEXT_COLOR, WIDTH//2, HEIGHT//3)
        draw_text(subtitle, main_font, TEXT_COLOR, WIDTH//2, HEIGHT//3 + 60)
        draw_text("点击任意位置开始", main_font, TEXT_COLOR, WIDTH//2, HEIGHT*2//3)
        pygame.display.flip()

# 记忆问答环节
def memory_quiz():
    current_question = 0
    score = 0
    combo = 0
    max_combo = 0
    
    # 计时功能
    time_per_question = 20  # 每题20秒
    question_start_time = time.time()
    
    while current_question < len(personal_questions):
        q = personal_questions[current_question]
        question_start_time = time.time()
        
        # 显示问题
        screen.fill(BACKGROUND)
        draw_text(f"问题 {current_question + 1}/{len(personal_questions)}", main_font, TEXT_COLOR, WIDTH//2, 50)
        
        # 显示连击和分数
        draw_text(f"分数: {score}", small_font, TEXT_COLOR, 100, 30)
        if combo > 1:
            draw_text(f"连击: {combo}!", small_font, HIGHLIGHT, WIDTH - 100, 30)
        
        # 显示提示按钮
        hint_button = draw_button("提示", WIDTH - 100, 80, 80, 40)
        
        draw_text(q["question"], main_font, TEXT_COLOR, WIDTH//2, 150)
        
        # 显示选项
        option_rects = []
        for i, option in enumerate(q["options"]):
            rect = draw_button(option, WIDTH//2 - 150, 200 + i*70, 300, 50)
            option_rects.append(rect)
        
        # 显示计时条
        draw_progress_bar(1.0, WIDTH//2 - 150, 130, 300, 10)
        
        pygame.display.flip()
        
        # 等待选择
        waiting = True
        selected = -1
        hint_shown = False
        
        while waiting:
            elapsed_time = time.time() - question_start_time
            time_left = max(0, time_per_question - elapsed_time)
            progress = time_left / time_per_question
            
            # 检查是否超时
            if time_left <= 0:
                selected = -1  # 超时
                waiting = False
            
            mouse_pos = pygame.mouse.get_pos()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    for i, rect in enumerate(option_rects):
                        if rect.collidepoint(mouse_pos):
                            selected = i
                            waiting = False
                    
                    if hint_button.collidepoint(mouse_pos) and not hint_shown:
                        hint_shown = True
            
            # 更新界面
            screen.fill(BACKGROUND)
            draw_text(f"问题 {current_question + 1}/{len(personal_questions)}", main_font, TEXT_COLOR, WIDTH//2, 50)
            
            # 显示连击和分数
            draw_text(f"分数: {score}", small_font, TEXT_COLOR, 100, 30)
            if combo > 1:
                draw_text(f"连击: {combo}!", small_font, HIGHLIGHT, WIDTH - 100, 30)
            
            # 显示提示按钮
            hint_color = BUTTON_HOVER if hint_button.collidepoint(mouse_pos) else BUTTON_COLOR
            hint_button = draw_button("提示", WIDTH - 100, 80, 80, 40, color=hint_color)
            
            draw_text(q["question"], main_font, TEXT_COLOR, WIDTH//2, 150)
            
            # 显示计时条
            time_color = HIGHLIGHT if progress > 0.3 else WRONG_COLOR
            pygame.draw.rect(screen, (50, 50, 80), (WIDTH//2 - 150, 130, 300, 10), border_radius=5)
            if progress > 0:
                pygame.draw.rect(screen, time_color, (WIDTH//2 - 150, 130, 300 * progress, 10), border_radius=5)
            pygame.draw.rect(screen, TEXT_COLOR, (WIDTH//2 - 150, 130, 300, 10), 2, border_radius=5)
            
            # 显示剩余时间
            draw_text(f"{int(time_left)}秒", small_font, TEXT_COLOR, WIDTH//2, 115)
            
            # 显示选项
            for i, rect in enumerate(option_rects):
                hover = rect.collidepoint(mouse_pos)
                draw_button(q["options"][i], rect.x, rect.y, rect.width, rect.height, hover)
            
            # 显示提示
            if hint_shown:
                hint_rect = pygame.Rect(WIDTH//2 - 200, HEIGHT - 100, 400, 60)
                pygame.draw.rect(screen, (40, 40, 70), hint_rect, border_radius=10)
                pygame.draw.rect(screen, TEXT_COLOR, hint_rect, 2, border_radius=10)
                draw_text(f"提示: {q['hint']}", small_font, TEXT_COLOR, WIDTH//2, HEIGHT - 70)
            
            pygame.display.flip()
        
        # 检查答案
        if selected == q["correct"]:
            score += 10 + combo * 2  # 基础分10分，连击加分
            combo += 1
            max_combo = max(max_combo, combo)
            try:
                correct_sound.play()
            except:
                pass
            
            # 显示正确答案和回忆
            screen.fill(BACKGROUND)
            draw_text("正确答案!", main_font, CORRECT_COLOR, WIDTH//2, 150)
            draw_text(q["memory"], main_font, TEXT_COLOR, WIDTH//2, 220)
            
            # 绘制庆祝效果
            for i in range(15):
                x = random.randint(100, WIDTH-100)
                y = random.randint(300, HEIGHT-100)
                size = random.uniform(0.1, 0.3)
                draw_heart(x, y, size, HIGHLIGHT)
            
            # 显示得分和连击
            draw_text(f"+{10 + combo * 2}分!", main_font, CORRECT_COLOR, WIDTH//2, 280)
            if combo > 2:
                draw_text(f"{combo}连击! 太棒了!", small_font, HIGHLIGHT, WIDTH//2, 320)
            
            draw_text("点击继续", main_font, TEXT_COLOR, WIDTH//2, HEIGHT-100)
            pygame.display.flip()
            
            # 等待点击
            waiting = True
            while waiting:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.MOUSEBUTTONDOWN or event.type == pygame.KEYDOWN:
                        waiting = False
        else:
            combo = 0  # 连击中断
            
            # 显示错误答案
            screen.fill(BACKGROUND)
            if selected == -1:
                draw_text("时间到!", main_font, WRONG_COLOR, WIDTH//2, 150)
            else:
                draw_text("答案不对哦，再想想~", main_font, WRONG_COLOR, WIDTH//2, 150)
            
            draw_text(f"正确答案是: {q['options'][q['correct']]}", main_font, TEXT_COLOR, WIDTH//2, 220)
            draw_text(q["memory"], main_font, TEXT_COLOR, WIDTH//2, 290)
            draw_text("点击继续", main_font, TEXT_COLOR, WIDTH//2, HEIGHT-100)
            pygame.display.flip()
            
            # 等待点击
            waiting = True
            while waiting:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.MOUSEBUTTONDOWN or event.type == pygame.KEYDOWN:
                        waiting = False
        
        current_question += 1
    
    return score, max_combo

# 隐藏关卡 - 拼图游戏
def hidden_puzzle():
    screen.fill(BACKGROUND)
    
    draw_text("隐藏关卡: 拼出我们的秘密", title_font, HIGHLIGHT, WIDTH//2, 100)
    draw_text(hidden_level["hint"], main_font, TEXT_COLOR, WIDTH//2, 150)
    
    # 显示打乱的字母
    draw_text("打乱的字母:", main_font, TEXT_COLOR, WIDTH//2, 220)
    draw_text(hidden_level["scrambled"], title_font, TEXT_COLOR, WIDTH//2, 270)
    
    # 输入框
    input_rect = pygame.Rect(WIDTH//2 - 150, 350, 300, 50)
    pygame.draw.rect(screen, (40, 40, 70), input_rect, border_radius=10)
    pygame.draw.rect(screen, TEXT_COLOR, input_rect, 2, border_radius=10)
    
    user_input = ""
    draw_text("在下方输入答案:", main_font, TEXT_COLOR, WIDTH//2, 320)
    
    submit_button = draw_button("提交", WIDTH//2 - 50, 420, 100, 40)
    
    pygame.display.flip()
    
    # 处理输入
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    # 检查答案
                    if user_input.upper() == hidden_level["answer"]:
                        return True, hidden_level["memory"]
                    else:
                        user_input = ""
                        draw_text("不对，再试试!", main_font, WRONG_COLOR, WIDTH//2, 480)
                        pygame.display.flip()
                        pygame.time.delay(1000)
                elif event.key == pygame.K_BACKSPACE:
                    user_input = user_input[:-1]
                else:
                    if len(user_input) < 10:  # 限制输入长度
                        user_input += event.unicode
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                if submit_button.collidepoint(mouse_pos):
                    # 检查答案
                    if user_input.upper() == hidden_level["answer"]:
                        return True, hidden_level["memory"]
                    else:
                        user_input = ""
                        draw_text("不对，再试试!", main_font, WRONG_COLOR, WIDTH//2, 480)
                        pygame.display.flip()
                        pygame.time.delay(1000)
        
        # 更新界面
        screen.fill(BACKGROUND)
        draw_text("隐藏关卡: 拼出我们的秘密", title_font, HIGHLIGHT, WIDTH//2, 100)
        draw_text(hidden_level["hint"], main_font, TEXT_COLOR, WIDTH//2, 150)
        
        # 显示打乱的字母
        draw_text("打乱的字母:", main_font, TEXT_COLOR, WIDTH//2, 220)
        draw_text(hidden_level["scrambled"], title_font, TEXT_COLOR, WIDTH//2, 270)
        
        # 输入框
        input_rect = pygame.Rect(WIDTH//2 - 150, 350, 300, 50)
        pygame.draw.rect(screen, (40, 40, 70), input_rect, border_radius=10)
        pygame.draw.rect(screen, TEXT_COLOR, input_rect, 2, border_radius=10)
        
        # 显示用户输入
        draw_text(user_input.upper(), main_font, TEXT_COLOR, WIDTH//2, 375)
        draw_text("在下方输入答案:", main_font, TEXT_COLOR, WIDTH//2, 320)
        
        submit_button = draw_button("提交", WIDTH//2 - 50, 420, 100, 40)
        
        pygame.display.flip()
    
    return False, ""

# 最终惊喜
def final_surprise(score, max_combo, puzzle_solved, puzzle_memory):
    screen.fill(BACKGROUND)
    
    # 烟花效果
    fireworks = []
    for _ in range(5):
        fireworks.append({
            'x': random.randint(100, WIDTH-100),
            'y': random.randint(100, HEIGHT-200),
            'color': (random.randint(200, 255), random.randint(100, 200), random.randint(100, 200)),
            'start_time': time.time() + random.uniform(0, 2),
            'duration': random.uniform(1, 3)
        })
    
    # 根据得分显示不同消息
    if score >= len(personal_questions) * 10 * 0.8:
        message = "你记得我们之间的每一个珍贵瞬间！"
        color = HIGHLIGHT
        rating = "记忆大师"
    elif score >= len(personal_questions) * 10 * 0.6:
        message = "你记得我们之间的大部分美好回忆！"
        color = TEXT_COLOR
        rating = "回忆达人"
    else:
        message = "看来我需要帮你重温一下我们的美好时光了！"
        color = (255, 100, 100)
        rating = "需要更多回忆"
    
    # 连击奖励
    if max_combo >= 5:
        combo_message = f"惊人的{max_combo}连击！你太了解我们了！"
    elif max_combo >= 3:
        combo_message = f"不错的{max_combo}连击！我们的默契很棒！"
    else:
        combo_message = "再接再厉，创造更多连击记录！"
    
    start_time = time.time()
    display_time = 200  # 显示15秒
    
    while time.time() - start_time < display_time:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        
        screen.fill(BACKGROUND)
        
        # 绘制烟花
        current_time = time.time()
        for firework in fireworks:
            if current_time >= firework['start_time'] and current_time <= firework['start_time'] + firework['duration']:
                elapsed = current_time - firework['start_time']
                draw_firework(firework['x'], firework['y'], 10, firework['color'], elapsed)
        
        # 绘制大量心形和星星
        for _ in range(30):
            x = random.randint(50, WIDTH-50)
            y = random.randint(300, HEIGHT-50)
            size = random.uniform(0.1, 0.4)
            draw_heart(x, y, size, HIGHLIGHT)
        
        for _ in range(20):
            x = random.randint(50, WIDTH-50)
            y = random.randint(50, 250)
            size = random.uniform(0.5, 1.5)
            draw_star(x, y, size, TEXT_COLOR)
        
        draw_text("我最爱的小谢，生日快乐，祝我们越来越好！", title_font, HIGHLIGHT, WIDTH//2, 80)
        draw_text(f"最终得分: {score}", main_font, TEXT_COLOR, WIDTH//2, 140)
        draw_text(f"评级: {rating}", main_font, color, WIDTH//2, 180)
        draw_text(combo_message, small_font, TEXT_COLOR, WIDTH//2, 220)
        
        # 显示最终惊喜消息
        surprise_message = [
            "亲爱的小谢，未来每天斗志满满劈波斩浪噢！",
            "感谢你出现在我的生命中，",
            "让我的每一天都充满阳光。",
            "这个粗糙的小游戏是我为你准备的特别礼物。。。",
            "",
            "真正的惊喜是...",
            "我会一直爱你，宠你，陪你度过每一个生日!",
            "",
            f"倒计时 {int(display_time - (time.time() - start_time))} 秒后关闭"
        ]
        
        for i, line in enumerate(surprise_message):
            draw_text(line, main_font, TEXT_COLOR, WIDTH//2, 280 + i*30)
        
        # 如果解开了隐藏关卡
        if puzzle_solved:
            draw_text("隐藏关卡解锁!", main_font, HIGHLIGHT, WIDTH//2, 500)
            draw_text(puzzle_memory, small_font, TEXT_COLOR, WIDTH//2, 530)
        
        pygame.display.flip()
        pygame.time.delay(50)
    
    pygame.quit()
    sys.exit()

# 主游戏循环
def main():
    opening_animation()
    score, max_combo = memory_quiz()
    
    # 根据得分决定是否解锁隐藏关卡
    puzzle_solved = False
    puzzle_memory = ""
    if score >= len(personal_questions) * 10 * 0.7:  # 得分超过70%解锁隐藏关卡
        puzzle_solved, puzzle_memory = hidden_puzzle()
    
    final_surprise(score, max_combo, puzzle_solved, puzzle_memory)

if __name__ == "__main__":
    main()