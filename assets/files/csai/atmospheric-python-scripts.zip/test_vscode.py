from ast import main


print('Hello, World!')