# -*- coding: utf-8 -*-
"""
Created on Fri May 30 21:34:15 2025

@author: Chen Yong
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import lognorm
from matplotlib.ticker import ScalarFormatter

# Raw data
intervals = [(0.1, 0.2), (0.2, 0.4), (0.4, 0.7), (0.7, 1.0),
            (1.0, 2.0), (2.0, 4.0), (4.0, 7.0), (7.0, 10.0), (10.0, 20.0)]
D_geo = np.array([0.1414, 0.2828, 0.5292, 0.8367, 1.414, 2.828, 5.292, 8.637, 14.14])  # Geometric mean diameter (μm)
N = np.array([50, 460, 1055, 980, 1705, 680, 102, 10, 2])  # Particle count

# 1. Calculate logarithmic width for each bin ΔlogD_p (base 10)
d_logDp = [np.log10(upper) - np.log10(lower) for lower, upper in intervals]

# 2. Calculate three distributions
dN_dlogDp = N / d_logDp
dS_dlogDp = N * np.pi * D_geo**2 / d_logDp
dV_dlogDp = N * (np.pi/6) * D_geo**3 / d_logDp

# 3. Calculate geometric mean diameter and geometric standard deviation
# Total particle count
N_total = np.sum(N)

# Calculate weighted mean of log10(D_geo)
weighted_mean_log10 = np.sum(N * np.log10(D_geo)) / N_total

# Geometric mean diameter D_g
D_g = 10**weighted_mean_log10

# Calculate geometric standard deviation σ_g
weighted_variance = np.sum(N * (np.log10(D_geo) - weighted_mean_log10)**2) / N_total
sigma_g = 10**np.sqrt(weighted_variance)

# 打印计算结果
print("="*60)
print("对数正态分布参数计算结果:")
print("="*60)
print(f"总粒子数 N_total = {N_total}")
print(f"加权平均 log10(D_geo) = {weighted_mean_log10:.6f}")
print(f"几何平均直径 D_g = 10^{weighted_mean_log10:.6f} = {D_g:.4f} μm")
print(f"加权方差 = {weighted_variance:.6f}")
print(f"几何标准差 σ_g = 10^{np.sqrt(weighted_variance):.6f} = {sigma_g:.4f}")
print("="*60)

# 4. Prepare continuous distribution functions
# Generate diameter range (logarithmically spaced)
D_p = np.logspace(np.log10(0.1), np.log10(20), 500)  # 500 points between 0.1 and 20 μm

# Convert parameters for lognormal distribution
# scipy lognorm: s = σ (standard deviation in natural log) = ln(σ_g)
s = np.log(sigma_g)  # standard deviation in natural log
scale = D_g

# Calculate probability density function (PDF)
pdf = lognorm.pdf(D_p, s, scale=scale)

# Calculate number concentration distribution (dN/dlogD_p)
dN_dlogDp_cont = N_total * pdf * np.log(10)

# Calculate surface area distribution (dS/dlogD_p)
dS_dlogDp_cont = np.pi * D_p**2 * dN_dlogDp_cont

# Calculate volume distribution (dV/dlogD_p)
dV_dlogDp_cont = (np.pi/6) * D_p**3 * dN_dlogDp_cont

# 5. Plot histograms and continuous distribution functions
# Calculate bin edges (log scale)
bin_edges = [0.1, 0.2, 0.4, 0.7, 1.0, 2.0, 4.0, 7.0, 10.0, 20.0]
bin_edges_log = np.log10(bin_edges)

# Create figure with three subplots
fig, axes = plt.subplots(3, 1, figsize=(10, 14), sharex=True)
plt.subplots_adjust(hspace=0.15)

# Color settings
hist_color = 'skyblue'
line_color = 'darkred'

# 1. Plot number concentration distribution
ax = axes[0]
# Histogram
ax.bar(bin_edges_log[:-1], dN_dlogDp, width=np.diff(bin_edges_log), 
       align='edge', edgecolor='k', alpha=0.7, color=hist_color, label='Histogram')
# Continuous distribution
ax.plot(np.log10(D_p), dN_dlogDp_cont, color=line_color, linewidth=2.5, label='Continuous Distribution')
ax.set_ylabel(r'$\Delta N / \Delta \log D_p$', fontsize=12)
ax.set_title('Aerosol Number Concentration Distribution', fontsize=13)
ax.grid(True, linestyle='--', alpha=0.6)
ax.legend()
ax.set_ylim(0, max(max(dN_dlogDp), max(dN_dlogDp_cont)) * 1.1)

# 2. Plot surface area distribution
ax = axes[1]
# Histogram
ax.bar(bin_edges_log[:-1], dS_dlogDp, width=np.diff(bin_edges_log), 
       align='edge', edgecolor='k', alpha=0.7, color=hist_color, label='Histogram')
# Continuous distribution
ax.plot(np.log10(D_p), dS_dlogDp_cont, color=line_color, linewidth=2.5, label='Continuous Distribution')
ax.set_ylabel(r'$\Delta S / \Delta \log D_p$ ($\mu$m$^2$)', fontsize=12)
ax.set_title('Aerosol Surface Area Distribution', fontsize=13)
ax.grid(True, linestyle='--', alpha=0.6)
ax.legend()
ax.set_ylim(0, max(max(dS_dlogDp), max(dS_dlogDp_cont)) * 1.1)

# 3. Plot volume distribution
ax = axes[2]
# Histogram
ax.bar(bin_edges_log[:-1], dV_dlogDp, width=np.diff(bin_edges_log), 
       align='edge', edgecolor='k', alpha=0.7, color=hist_color, label='Histogram')
# Continuous distribution
ax.plot(np.log10(D_p), dV_dlogDp_cont, color=line_color, linewidth=2.5, label='Continuous Distribution')
ax.set_ylabel(r'$\Delta V / \Delta \log D_p$ ($\mu$m$^3$)', fontsize=12)
ax.set_title('Aerosol Volume Distribution', fontsize=13)
ax.grid(True, linestyle='--', alpha=0.6)
ax.legend()
ax.set_ylim(0, max(max(dV_dlogDp), max(dV_dlogDp_cont)) * 1.1)

# Set common X-axis
ax.set_xlabel('Particle Diameter $D_p$ ($\mu$m) [Log Scale]', fontsize=12)
ax.set_xlim(bin_edges_log[0], bin_edges_log[-1])

# Set X-axis ticks and labels
tick_positions = np.log10(bin_edges)
tick_labels = [f'{x:.1f}' for x in bin_edges]
plt.xticks(tick_positions, tick_labels)

# Add parameter information box
param_text = f'Log-normal Distribution Parameters:\n$D_g = {D_g:.4f}\, \mu m$\n$\sigma_g = {sigma_g:.4f}$'
fig.text(0.78, 0.92, param_text, fontsize=12, bbox=dict(facecolor='white', alpha=0.8, edgecolor='gray'))

plt.suptitle('Aerosol Size Distribution Functions with Log-normal Fit', fontsize=16, y=0.97)
plt.tight_layout()
plt.subplots_adjust(top=0.93)
plt.show()